global filesystem
global browser_ext
import copy
import random
try:
    import webbrowser
    browser_ext=True
except NotImplementedError:
    browser_ext=False
try:
    import os
    filesystem=os.path.dirname(__file__)
except NotImplementedError:
    filesystem=False
    print("This copy of PyChess is not a full copy. Some features such as the User's Guide and Settings saving may not be availible.")
def savegame(variant,*params):
    global gameboard
    global blackToMove
    global fiftymoves
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    board=""
    for i in gameboard:
        board+=','.join(i)+';'
    board=board[:-1]
    print("Here is your save ‘file’:\n"+variant+"~"+board+"~"+('B'if blackToMove else'W')+"~"+str(fiftymoves)+"~"+hex((1 if WQcastle else 0)+(2 if WKcastle else 0)+(4 if BQcastle else 0)+(8 if BKcastle else 0))[2:]+"~"+str(eval("whiteScore"+variant))+"~"+str(eval("blackScore"+variant))+"~"+(str(eP[0])+','+str(eP[1])if eP!=False else"X")+("~"+params[0]if len(params)==1 else"")+"\nPress enter to return to the game.")
    blackToMove=not blackToMove
    input("")
def loadgame(savedgame):
    global gameboard
    global blackToMove
    global fiftymoves
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global WKingPos
    global BKingPos
    gamesplit=savedgame.split('~')
    blackToMove=gamesplit[2]=='B'
    fiftymoves=int(gamesplit[3])
    WQcastle=int(gamesplit[4],base=16)%2==1
    WKcastle=int(gamesplit[4],base=16)%4//2==1
    BQcastle=int(gamesplit[4],base=16)%8//4==1
    BKcastle=int(gamesplit[4],base=16)//8==1
    gameboard=gamesplit[1].split(';')
    WKingPos=(4,7)
    BKingPos=(4,0)
    for i in range(len(gameboard)):
        gameboard[i]=gameboard[i].split(',')
        if 'K'in gameboard[i]:
            WKingPos=(i,gameboard[i].index('K'))
        if 'k'in gameboard[i]:
            BKingPos=(i,gameboard[i].index('k'))
    eP=(False if gamesplit[7]=='X'else(int(gamesplit[7].split(',')[0]),int(gamesplit[7].split(',')[1])))
    eval(gamesplit[0]+('("'+savedgame.split('~',8)[8]+'")'if len(gamesplit)>8 else"(False)"))
def multireplace(text,replacements):
    string=str(text)
    for i,j in replacements.items():
        string=string.replace(i,j)
    return string
def arraytonotation(array):
    return chr(array[0]+97)+str(8-array[1])
def notationtoarray(notation):
    return[int(notation[0],base=20)-10,8-int(notation[1])]
def arraytonotationSHOGI(array):
    return str(array[0]+1)+chr(105-array[1])
def notationtoarraySHOGI(notation):
    return[int(notation[0])-1,18-int(notation[1],base=19)]
def drawboard(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','M','m','A','a','K','k','P','p')
    piecelist=((('♜','♖','♞','♘','♝','♗','♛','♕','ｍ','Ｍ','ａ','Ａ','♚','♔','♟','♙')if playerCase else('♜','♖','♞','♘','♝','♗','♛','♕','Ｍ','ｍ','Ａ','ａ','♚','♔','♟','♙'))if darkMode else(('♖','♜','♘','♞','♗','♝','♕','♛','ｍ','Ｍ','ａ','Ａ','♔','♚','♙','♟')if playerCase else('♖','♜','♘','♞','♗','♝','♕','♛','Ｍ','ｍ','Ａ','ａ','♔','♚','♙','♟')))
    if game=="CHESS":
        global whiteScoreCHESS
        global blackScoreCHESS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreCHESS+=2
                    print("White wins by checkmate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                else:
                    blackScoreCHESS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            else:
                whiteScoreCHESS+=1
                blackScoreCHESS+=1
                print("Draw by stalemate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCHESS+=1
            blackScoreCHESS+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="DEATHMATCH":
        global whiteScoreDEATHMATCH
        global blackScoreDEATHMATCH
        if 'r'not in[j for i in board for j in i]and'n'not in[j for i in board for j in i] and'b'not in[j for i in board for j in i] and'q'not in[j for i in board for j in i] and'k'not in[j for i in board for j in i]:
            whiteScoreDEATHMATCH+=2
            print("Black is eliminated. White wins. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif 'R'not in[j for i in board for j in i] and'N'not in[j for i in board for j in i] and'B'not in[j for i in board for j in i] and'Q'not in[j for i in board for j in i] and'K'not in[j for i in board for j in i]:
            blackScoreDEATHMATCH+=2
            print("White is eliminated. Black wins. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif stalemate(blackToMove,list(board),False,4,0,7):
            whiteScoreDEATHMATCH+=1
            blackScoreDEATHMATCH+=1
            print("Draw by stalemate. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif fiftymoves>=100:
            whiteScoreDEATHMATCH+=1
            blackScoreDEATHMATCH+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            gameOver=True
    elif game=="CHESS960":
        global whiteScoreCHESS960
        global blackScoreCHESS960
        if stalemate(blackToMove,list(board),True,gameparams[0],gameparams[1],gameparams[2]):
            if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2]):
                if blackToMove:
                    whiteScoreCHESS960+=2
                    print("White wins by checkmate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+(((" 1/2"if whiteScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHESS960%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+(((" 1/2"if blackScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHESS960%2==1 else""))
                else:
                    blackScoreCHESS960+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+(((" 1/2"if whiteScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHESS960%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+(((" 1/2"if blackScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHESS960%2==1 else""))
            else:
                whiteScoreCHESS960+=1
                blackScoreCHESS960+=1
                print("Draw by stalemate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+(((" 1/2"if whiteScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHESS960%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+(((" 1/2"if blackScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHESS960%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCHESS960+=1
            blackScoreCHESS960+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+(((" 1/2"if whiteScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHESS960%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+(((" 1/2"if blackScoreCHESS960>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHESS960%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2]):
            print("Check!")
    elif game=="ROOKS":
        global whiteScoreROOKS
        global blackScoreROOKS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreROOKS+=2
                    print("White wins by checkmate. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+(((" 1/2"if whiteScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+(((" 1/2"if blackScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS%2==1 else""))
                else:
                    blackScoreROOKS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+(((" 1/2"if whiteScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+(((" 1/2"if blackScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS%2==1 else""))
            else:
                whiteScoreROOKS+=1
                blackScoreROOKS+=1
                print("Draw by stalemate. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+(((" 1/2"if whiteScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+(((" 1/2"if blackScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreROOKS+=1
            blackScoreROOKS+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+(((" 1/2"if whiteScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+(((" 1/2"if blackScoreROOKS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="KNIGHTS":
        global whiteScoreKNIGHTS
        global blackScoreKNIGHTS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreKNIGHTS+=2
                    print("White wins by checkmate. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+(((" 1/2"if whiteScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreKNIGHTS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+(((" 1/2"if blackScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreKNIGHTS%2==1 else""))
                else:
                    blackScoreKNIGHTS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+(((" 1/2"if whiteScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreKNIGHTS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+(((" 1/2"if blackScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreKNIGHTS%2==1 else""))
            else:
                whiteScoreKNIGHTS+=1
                blackScoreKNIGHTS+=1
                print("Draw by stalemate. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+(((" 1/2"if whiteScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreKNIGHTS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+(((" 1/2"if blackScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreKNIGHTS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreKNIGHTS+=1
            blackScoreKNIGHTS+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+(((" 1/2"if whiteScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreKNIGHTS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+(((" 1/2"if blackScoreKNIGHTS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreKNIGHTS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="BISHOPS":
        global whiteScoreBISHOPS
        global blackScoreBISHOPS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreBISHOPS+=2
                    print("White wins by checkmate. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+(((" 1/2"if whiteScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreBISHOPS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+(((" 1/2"if blackScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreBISHOPS%2==1 else""))
                else:
                    blackScoreBISHOPS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+(((" 1/2"if whiteScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreBISHOPS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+(((" 1/2"if blackScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreBISHOPS%2==1 else""))
            else:
                whiteScoreBISHOPS+=1
                blackScoreBISHOPS+=1
                print("Draw by stalemate. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+(((" 1/2"if whiteScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreBISHOPS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+(((" 1/2"if blackScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreBISHOPS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreBISHOPS+=1
            blackScoreBISHOPS+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+(((" 1/2"if whiteScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreBISHOPS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+(((" 1/2"if blackScoreBISHOPS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreBISHOPS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="QUEENS":
        global whiteScoreQUEENS
        global blackScoreQUEENS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreQUEENS+=2
                    print("White wins by checkmate. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+(((" 1/2"if whiteScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreQUEENS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+(((" 1/2"if blackScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreQUEENS%2==1 else""))
                else:
                    blackScoreQUEENS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+(((" 1/2"if whiteScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreQUEENS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+(((" 1/2"if blackScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreQUEENS%2==1 else""))
            else:
                whiteScoreQUEENS+=1
                blackScoreQUEENS+=1
                print("Draw by stalemate. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+(((" 1/2"if whiteScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreQUEENS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+(((" 1/2"if blackScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreQUEENS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreQUEENS+=1
            blackScoreQUEENS+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+(((" 1/2"if whiteScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreQUEENS%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+(((" 1/2"if blackScoreQUEENS>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreQUEENS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="ROOKS_CASTLING":
        global whiteScoreROOKS_CASTLING
        global blackScoreROOKS_CASTLING
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreROOKS_CASTLING+=2
                    print("White wins by checkmate. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if whiteScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if blackScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS_CASTLING%2==1 else""))
                else:
                    blackScoreROOKS_CASTLING+=2
                    print("Black wins by checkmate. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if whiteScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if blackScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS_CASTLING%2==1 else""))
            else:
                whiteScoreROOKS_CASTLING+=1
                blackScoreROOKS_CASTLING+=1
                print("Draw by stalemate. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if whiteScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if blackScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS_CASTLING%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreROOKS_CASTLING+=1
            blackScoreROOKS_CASTLING+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if whiteScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreROOKS_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+(((" 1/2"if blackScoreROOKS_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreROOKS_CASTLING%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="NO_CASTLING":
        global whiteScoreNO_CASTLING
        global blackScoreNO_CASTLING
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreNO_CASTLING+=2
                    print("White wins by checkmate. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+(((" 1/2"if whiteScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreNO_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+(((" 1/2"if blackScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreNO_CASTLING%2==1 else""))
                else:
                    blackScoreNO_CASTLING+=2
                    print("Black wins by checkmate. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+(((" 1/2"if whiteScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreNO_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+(((" 1/2"if blackScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreNO_CASTLING%2==1 else""))
            else:
                whiteScoreNO_CASTLING+=1
                blackScoreNO_CASTLING+=1
                print("Draw by stalemate. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+(((" 1/2"if whiteScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreNO_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+(((" 1/2"if blackScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreNO_CASTLING%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreNO_CASTLING+=1
            blackScoreNO_CASTLING+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+(((" 1/2"if whiteScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreNO_CASTLING%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+(((" 1/2"if blackScoreNO_CASTLING>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreNO_CASTLING%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="THREECHECK":
        global whiteScoreTHREECHECK
        global blackScoreTHREECHECK
        global whiteCheckCount
        global blackCheckCount
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreTHREECHECK+=2
                    print("White wins by checkmate. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
                else:
                    blackScoreTHREECHECK+=2
                    print("Black wins by checkmate. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
            else:
                whiteScoreTHREECHECK+=1
                blackScoreTHREECHECK+=1
                print("Draw by stalemate. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreTHREECHECK+=1
            blackScoreTHREECHECK+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            if blackToMove and blackCheckCount>=2:
                whiteScoreTHREECHECK+=2
                print("White wins by triple check. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
                blackCheckCount+=1
                gameover=True
            elif not blackToMove and whiteCheckCount>=2:
                blackScoreTHREECHECK+=2
                print("Black wins by triple check. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+(((" 1/2"if whiteScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreTHREECHECK%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+(((" 1/2"if blackScoreTHREECHECK>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreTHREECHECK%2==1 else""))
                whiteCheckCount+=1
            else:
                print("Check!")
                if(blackToMove):
                    blackCheckCount+=1
                else:
                    whiteCheckCount+=1
    elif game=="CHOSECOMPOUND":
        global whiteScoreCHOOSECOMPOUND
        global blackScoreCHOOSECOMPOUND
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreCHOOSECOMPOUND+=2
                    print("White wins by checkmate. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if whiteScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHOOSECOMPOUND%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if blackScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHOOSECOMPOUND%2==1 else""))
                else:
                    blackScoreCHOOSECOMPOUND+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if whiteScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHOOSECOMPOUND%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if blackScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHOOSECOMPOUND%2==1 else""))
            else:
                whiteScoreCHOOSECOMPOUND+=1
                blackScoreCHOOSECOMPOUND+=1
                print("Draw by stalemate. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if whiteScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHOOSECOMPOUND%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if blackScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHOOSECOMPOUND%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCHOOSECOMPOUND+=1
            blackScoreCHOOSECOMPOUND+=1
            print(("Draw by ﬁfty-move rule. "if ASCIIart==2 else"Draw by fifty-move rule. ")+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if whiteScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if whiteScoreCHOOSECOMPOUND%2==1 else"")+("-"if ASCIIart==0 else"‐")+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+(((" 1/2"if blackScoreCHOOSECOMPOUND>=2 else"1/2")if ASCIIart==0 else"½")if blackScoreCHOOSECOMPOUND%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    if boardFlip and blackToMove:
        if game=="THREECHECK":
            for i in range(blackCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("\n\n")
        print("  hgfedcba\n  --------"if ASCIIart==0 else"  ｈｇｆｅｄｃｂａ\n  －－－－－－－－")
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('▇',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  hgfedcba"if ASCIIart==0 else"  －－－－－－－－\n  ｈｇｆｅｄｃｂａ")
        if game=="THREECHECK":
            print("\n")
            for i in range(whiteCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("")
    else:
        if game=="THREECHECK":
            for i in range(whiteCheckCount):
                print("+"if ASCIIare else"＋",end="")
            print("\n\n")
        print("  abcdefgh\n  --------"if ASCIIart==0 else"  ａｂｃｄｅｆｇｈ\n  －－－－－－－－")
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file+darkMode)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('▇',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  abcdefgh\n"if ASCIIart==0 else"  －－－－－－－－\n  ａｂｃｄｅｆｇｈ\n")
        if game=="THREECHECK":
            print("\n")
            for i in range(blackCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboardCRAZYHOUSE(board,whiteHold,blackHold):
    global ASCIIart
    global boardFlip
    global playerCase
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','K','k','P','p')
    piecelist=(('♜','♖','♞','♘','♝','♗','♛','♕','♚','♔','♟','♙')if darkMode else('♖','♜','♘','♞','♗','♝','♕','♛','♔','♚','♙','♟'))
    global whiteScoreCRAZYHOUSE
    global blackScoreCRAZYHOUSE
    if stalemateCRAZYHOUSE(blackToMove,list(board),True,4,0,7,whiteHold,blackHold):
        if check(list(board),blackToMove,False,4,0,7):
            if blackToMove:
                whiteScoreCRAZYHOUSE+=2
                print("White wins by checkmate. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
            else:
                blackScoreCRAZYHOUSE+=2
                print("Black wins by checkmate. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
        else:
            whiteScoreCRAZYHOUSE+=1
            blackScoreCRAZYHOUSE+=1
            print("Draw by stalemate. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
        gameOver=True
    elif fiftymoves>=100:
        whiteScoreCRAZYHOUSE+=1
        blackScoreCRAZYHOUSE+=1
        print("Draw by fifty-move rule. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
        gameOver=True
    elif check(list(board),blackToMove,False,4,0,7):
        print("Check!")
    if boardFlip and blackToMove:
        print((("  -----\n |prnbq|\n |"+"".join(list(map(str,whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------")if playerCase else("  -----\n |PRNBQ|\n |"+"".join(list(map(str,whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------"))if ASCIIart==0 else("  －－－－－\n ｜♙♖♘♗♕｜\n ｜"+"".join(list(map(lambda x:chr(65296+x),whiteHold)))+"｜\n  －－－－－\n\n  ｈｇｆｅｄｃｂａ\n  －－－－－－－－"))
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  hgfedcba\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(str,blackHold)))+"|\n  -----")if playerCase else("  --------\n  hgfedcba\n\n  -----\n |prnbq|\n |"+"".join(list(map(str,blackHold)))+"|\n  -----"))if ASCIIart==0 else("  －－－－－－－－\n  ｈｇｆｅｄｃｂａ\n\n  －－－－－\n ｜♟♜♞♝♛｜\n ｜"+"".join(list(map(lambda x:chr(65296+x),blackHold)))+"｜\n  －－－－－"))
    else:
        print((("  -----\n |PRNBQ|\n |"+"".join(list(map(str,blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------")if playerCase else("  -----\n |prnbq|\n |"+"".join(list(map(str,blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------"))if ASCIIart==0 else("  －－－－－\n ｜♟♜♞♝♛｜\n ｜"+"".join(list(map(lambda x:chr(65296+x),blackHold)))+"｜\n  －－－－－\n\n  ａｂｃｄｅｆｇｈ\n  －－－－－－－－"))
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('▇',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  abcdefgh\n\n  -----\n |prnbq|\n |"+"".join(list(map(str,whiteHold)))+"|\n  -----")if playerCase else("  --------\n  abcdefgh\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(str,whiteHold)))+"|\n  -----"))if ASCIIart==0 else("  －－－－－－－－\n  ａｂｃｄｅｆｇｈ\n\n  －－－－－\n ｜♙♖♘♗♕｜\n ｜"+"".join(list(map(lambda x:chr(65296+x),whiteHold)))+"｜\n  －－－－－"))
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboard10x8(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','M','m','A','a','K','k','P','p')
    piecelist=((('♜','♖','♞','♘','♝','♗','♛','♕','ｍ','Ｍ','ａ','Ａ','♚','♔','♟','♙')if playerCase else('♜','♖','♞','♘','♝','♗','♛','♕','Ｍ','ｍ','Ａ','ａ','♚','♔','♟','♙'))if darkMode else(('♖','♜','♘','♞','♗','♝','♕','♛','ｍ','Ｍ','ａ','Ａ','♔','♚','♙','♟')if playerCase else('♖','♜','♘','♞','♗','♝','♕','♛','Ｍ','ｍ','Ａ','ａ','♔','♚','♙','♟')))
    if game=="CAPABLANCA":
        global whiteScoreCAPABLANCA
        global blackScoreCAPABLANCA
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreCAPABLANCA+=2
                    print("White wins by checkmate. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
                else:
                    blackScoreCAPABLANCA+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
            else:
                whiteScoreCAPABLANCA+=1
                blackScoreCAPABLANCA+=1
                print("Draw by stalemate. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCAPABLANCA+=1
            blackScoreCAPABLANCA+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
        if boardFlip and blackToMove:
            print("  jihgfedcba\n  ----------"if ASCIIart==0 else"  ｊｉｈｇｆｅｄｃｂａ\n  －－－－－－－－－－")
            for rank in range(7,-1,-1):
                print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
                for file in range(9,-1,-1):
                    if board[file][rank]==' ':
                        if(rank+file+darkMode)%2==0:
                            if ASCIIart==0:
                                print('.',end="")
                            else:
                                print(' ',end="")
                        else:
                            if ASCIIart==0:
                                print('#',end="")
                            else:
                                print('▇',end="")
                    else:
                        if ASCIIart==0:
                            print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                        else:
                            print(piecelist[notationlist.index(board[file][rank])],end="")
                print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
            print("  ----------\n  jihgfedcba"if ASCIIart==0 else"  －－－－－－－－－－\n  ｊｉｈｇｆｅｄｃｂａ")
        else:
            print("  abcdefghij\n  ----------"if ASCIIart==0 else"  ａｂｃｄｅｆｇｈｉｊ\n  －－－－－－－－－－")
            for rank in range(8):
                print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
                for file in range(10):
                    if board[file][rank]==' ':
                        if(rank+file)%2==0:
                            if ASCIIart==0:
                                print('.',end="")
                            else:
                                print('．',end="")
                        else:
                            if ASCIIart==0:
                                print('#',end="")
                            else:
                                print('＃',end="")
                    else:
                        if ASCIIart==0:
                            print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                        else:
                            print(piecelist[notationlist.index(board[file][rank])],end="")
                print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
            print("  ----------\n  abcdefghij"if ASCIIart==0 else"  －－－－－－－－－－\n  ａｂｃｄｅｆｇｈｉｊ")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboardSHOGI():
    global blackToMove
    global SHOGIchecksWhite
    global SHOGIchecksBlack
    global gameboard
    global ASCIIart
    global playerCase
    global boardFlip
    global WKingPos
    global BKingPos
    global whiteHold
    global blackHold
    gameOver=False
    notationlist=('K','k','R','r','D','d','B','b','H','h','G','g','S','s','E','e','N','n','C','c','L','l','I','i','P','p','T','t')
    piecelist=('ｋ','Ｋ','ｒ','Ｒ','ｄ','Ｄ','ｂ','Ｂ','ｈ','Ｈ','ｇ','Ｇ','ｓ','Ｓ','ｅ','Ｅ','ｎ','Ｎ','ｃ','Ｃ','ｌ','Ｌ','ｉ','Ｉ','ｐ','Ｐ','ｔ','Ｔ')if playerCase else('Ｋ','ｋ','Ｒ','ｒ','Ｄ','ｄ','Ｂ','ｂ','Ｈ','ｈ','Ｇ','ｇ','Ｓ','ｓ','Ｅ','ｅ','Ｎ','ｎ','Ｃ','ｃ','Ｌ','ｌ','Ｉ','ｉ','Ｐ','ｐ','Ｔ','ｔ')
    global whiteScoreSHOGI
    global blackScoreSHOGI
    if stalemateSHOGI(blackToMove,list(board),True,4,0,7,whiteHold,blackHold):
        if checkSHOGI(list(board),blackToMove,(BKingPos if blackToMove else WKingPos)):
            if blackToMove:
                whiteScoreSHOGI+=2
                print("White wins by checkmate. "+(str(blackScoreSHOGI//2)if blackScoreSHOGI!=1 else"")+("½"if blackScoreSHOGI%2==1 else"")+"-"+(str(whiteScoreSHOGI//2)if whiteScoreSHOGI!=1 else"")+("½"if whiteScoreSHOGI%2==1 else""))
            else:
                blackScoreSHOGI+=2
                print("Black wins by checkmate. "+(str(blackScoreSHOGI//2)if blackScoreSHOGI!=1 else"")+("½"if blackScoreSHOGI%2==1 else"")+"-"+(str(whiteScoreSHOGI//2)if whiteScoreSHOGI!=1 else"")+("½"if whiteScoreSHOGI%2==1 else""))
        else:
            if blackToMove:
                whiteScoreSHOGI+=2
                print("White wins by stalemate. "+(str(whiteScoreSHOGI//2)if whiteScoreSHOGI!=1 else"")+("½"if whiteScoreSHOGI%2==1 else"")+"-"+(str(blackScoreSHOGI//2)if blackScoreSHOGI!=1 else"")+("½"if blackScoreSHOGI%2==1 else""))
            else:
                blackScoreSHOGI+=2
                print("Black wins by stalemate. "+(str(whiteScoreSHOGI//2)if whiteScoreSHOGI!=1 else"")+("½"if whiteScoreSHOGI%2==1 else"")+"-"+(str(blackScoreSHOGI//2)if blackScoreSHOGI!=1 else"")+("½"if blackScoreSHOGI%2==1 else""))
        gameOver=True
    elif checkSHOGI(list(board),blackToMove,(BKingPos if blackToMove else WKingPos)):
        print("Check!")
        if blackToMove:
            SHOGIchecksBlack+=1
        else:
            SHOGIchecksWhite+=1
    else:
        if blackToMove:
            SHOGIchecksWhite=0
        else:
            SHOGIchecksBlack=0
    if boardFlip and not blackToMove:
        if SHOGIchecksBlack>0:
            for i in range(SHOGIchecksBlack):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
        if len(blackHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"  －\n ｜ ｜\n  －\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
                print("\n |"+"".join(blackHold)+"|\n  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
            else:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
                print("\n ｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n  ",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
            print("\n")
        print("  123456789\n  ---------"if ASCIIart==0 else"  １２３４５６７８９\n  －－－－－－－－－")
        for rank in range(9):
            print((chr((105 if ASCIIart==0 else 65353)-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(9):
                if board[file][rank]==' ':
                    print(('.'if ASCIIart==0 else' ')if darkMode else('#'if ASCIIart==0 else'▇'),end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(chr((105 if ASCIIart==0 else 65353)-rank)),end="")
        print("  ---------\n  123456789\n"if ASCIIart==0 else"  －－－－－－－－－\n  １２３４５６７８９\n")
        if len(whiteHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"  －\n ｜ ｜\n  －\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
                print("\n |"+"".join(whiteHold)+"|\n  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
            else:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
                print("\n ｜",end="")
                for i in whiteHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n  ",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
            print("\n")
        if SHOGIchecksWhite>0:
            for i in range(SHOGIchecksWhite):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
    else:
        if SHOGIchecksWhite>0:
            for i in range(SHOGIchecksWhite):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
        if len(whiteHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"  －\n ｜ ｜\n  －\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
                print("\n |"+"".join(whiteHold)+"|\n  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
            else:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
                print("\n ｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n  ",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
            print("\n")
        print("  987654321\n  ---------"if ASCIIart==0 else"  ９８７６５４３２１\n  －－－－－－－－－")
        for rank in range(8,-1,-1):
            print((chr((105 if ASCIIart==0 else 65353)-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8,-1,-1):
                if board[file][rank]==' ':
                    print('.'if ASCIIart==0 else'．',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(chr((105 if ASCIIart==0 else 65353)-rank)),end="")
        print("  ---------\n  987654321\n"if ASCIIart==0 else"  －－－－－－－－－\n  ９８７６５４３２１\n")
        if len(blackHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"  －\n ｜ ｜\n  －\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
                print("\n |"+"".join(blackHold)+"|\n  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
            else:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
                print("\n ｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n  ",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
            print("\n")
        if SHOGIchecksBlack>0:
            for i in range(SHOGIchecksBlack):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
    if blackToMove:
        print("Black to Move")
    else:
        print("White to Move")
    return gameOver
def drawboardSANDBOX():
    global gameboard
    print("  ",end="")
    for i in list(map(lambda x:chr(x+97),range(len(gameboard)))):
        print(i,end="")
    print("\n  ",end="")
    for i in range(len(gameboard)):
        print("-",end="")
    print("")
    for rank in range(len(gameboard[0])):
        print(str(len(gameboard[0])-rank)+"|",end="")
        for file in range(len(gameboard)):
            if gameboard[file][rank]==' ':
                if(rank+file+len(gameboard[0]))%2==0:
                    print('.',end="")
                else:
                    print('#',end="")
            else:
                print(gameboard[file][rank],end="")
        print("|"+(str(len(gameboard[0])-rank)))
    print("  ",end="")
    for i in range(len(gameboard)):
        print("-",end="")
    print("\n  ",end="")
    for i in list(map(lambda x:chr(x+97),range(len(gameboard)))):
        print(i,end="")
    print("")
def makemove(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,**keys):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'Ｍ':'m',
        'Ａ':'a',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'ｍ':'M',
        'ａ':'A'
    })if playerCase else({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'ｍ':'M',
        'ａ':'A',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'Ｍ':'m',
        'Ａ':'a'
    })if darkMode else({
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'ｍ':'m',
        'ａ':'a',
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'Ｍ':'M',
        'Ａ':'A'
    })if playerCase else({
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'Ｍ':'M',
        'Ａ':'A',
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'ｍ':'m',
        'ａ':'a'
    }))
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]==';'):
        if move=="O-O"or move=="O-O-O":
            ""
        elif not(move[0].lower()in(('r','n','b','q','k','p')if"pieces"not in keys else keys["pieces"])or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[5]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')):
            error="Move indexed out of bounds."
            return False
        elif(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not wqcastle):
            error="You may not castle right now."
            return False
        elif(move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif(move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower())or not(move[0].islower()^playerCase==board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=(int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2)
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-8-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemoveCRAZYHOUSE(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global promotions
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p'
    })if darkMode^playerCase else({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P'
    }))
    if len(move)==4 and move[1]=='@':
        if not move[0].lower()in('r','n','b','q','k','p'):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')):
            error="Move indexed out of bounds."
            return False
        elif board[int(move[2],base=20)-10][8-int(move[3])]!=' ':
            error="You may not drop pieces onto occupied spaces."
            return False
        elif move[0].islower()!=blackToMove:
            error="You may not drop your opponent's pieces."
            return False
        elif(blackToMove and blackHold["prnbq".index(move[0])]==0)or(not blackToMove and whiteHold["PRNBQ".index(move[0])]==0):
            error="You do not have any "+(move[0].swapcase()if playerCase else move[0])+"s to drop."
            return False
        elif move[0].lower()=='p'and(move[3]=='1'or move[3]=='8'):
            error="You may not drop pawns on the 1ˢᵗ or 8ᵗʰ rank."
            return False
        if update:
            board[int(move[2],base=20)-10][8-int(move[3])]=move[0]
            if blackToMove:
                blackHold['prnbq'.index(board[int(move[2],base=20)-10][8-8-int(move[3])])]-=1
            else:
                whiteHold['PRNBQ'.index(board[int(move[2],base=20)-10][8-8-int(move[3])])]-=1
            board[int(move[2],base=20)-10][8-int(move[3])]
            return True
    elif move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]==';'):
        if not(move[0].lower()in('r','n','b','q','k','p')or move=="O-O"or move=="O-O-O"):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[5]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')or move=="O-O"or move=="O-O-O"):
            error="Move indexed out of bounds."
            return False
        elif(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not wqcastle):
            error="You may not castle right now."
            return False
        elif (move[0].islower()!=blackToMove and not(move=="O-O"or move=="O-O-O")and not enemyMove)or(move[0].islower()==blackToMove and not(move=="O-O"or move=="O-O-O")and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower():
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        if board[int(move[5],base=20)-10][8-8-int(move[3])]!=' ':
                            if move[5:7]in promotions:
                                promotions.remove(move[5:7])
                                if blackToMove:
                                    blackHold[0]+=1
                                else:
                                    whiteHold[0]+=1
                            else:
                                if blackToMove:
                                    blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[3])])]+=1
                                else:
                                    whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[3])])]+=1
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    if board[int(move[5],base=20)-10][8-8-int(move[6])]!=' ':
                        if move[5:7]in promotions:
                            promotions.remove(move[5:7])
                            promotions.append(move[2:4])
                            if blackToMove:
                                blackHold[0]+=1
                            else:
                                whiteHold[0]+=1
                        else:
                            if blackToMove:
                                blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                            else:
                                whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=(int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2)
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                        promotions.append(move[5:7])
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    if board[int(move[5],base=20)-10][8-8-int(move[6])]!=' ':
                        if move[5:7]in promotions:
                            promotions.remove(move[5:7])
                            promotions.append(move[2:4])
                            if blackToMove:
                                blackHold[0]+=1
                            else:
                                whiteHold[0]+=1
                        else:
                            if blackToMove:
                                blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                            else:
                                whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-8-int(move[3])]=' '
                    if move[2:4]in promotions:
                        promotions[promotions.index(move[2:4])]=move[5:7]
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemove10x8(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,{
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'Ｍ':'M',
        'Ａ':'A',
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'ｍ':'m',
        'ａ':'a'
    })
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]==';'):
        if not(move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"])or move=="O-O"or move=="O-O-O"or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h','i','j')and move[5]in('a','b','c','d','e','f','g','h','i','j')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')or move=="O-O"or move=="O-O-O"):
            error="Move indexed out of bounds."
            return False
        elif(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not wqcastle):
            error="You may not castle right now."
            return False
        elif (move[0].islower()!=blackToMove and not(move=="O-O"or move=="O-O-O")and not enemyMove)or(move[0].islower()==blackToMove and not(move=="O-O"or move=="O-O-O")and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower():
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,6),max(kingRookFile,7)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,7):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(7,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[6][0]='r'
                    board[7][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,6),max(kingRookFile,7)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,7):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(7,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[6][7]='R'
                    board[7][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,4),min(queenRookFile,3),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,3):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(3,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[4][0]='r'
                    board[3][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,4),min(queenRookFile,3),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,3):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(3,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[4][7]='R'
                    board[3][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=(int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2)
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-8-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemoveSHOGI(moveIn,update,checkForCheck,board,enemyMove):
    global error
    global playerCase
    global WKingPos
    global BKingPos
    global whiteHold
    global blackHold
    move=multireplace(moveIn,{
        'Ｋ':'K',
        'Ｒ':'R',
        'Ｄ':'D',
        'Ｂ':'B',
        'Ｈ':'H',
        'Ｇ':'G',
        'Ｓ':'S',
        'Ｅ':'E',
        'Ｎ':'N',
        'Ｃ':'C',
        'Ｌ':'L',
        'Ｉ':'I',
        'Ｐ':'P',
        'Ｔ':'T',
        'ｋ':'k',
        'ｒ':'r',
        'ｄ':'d',
        'ｂ':'b',
        'ｈ':'h',
        'ｇ':'g',
        'ｓ':'s',
        'ｅ':'e',
        'ｎ':'n',
        'ｃ':'c',
        'ｌ':'l',
        'ｉ':'i',
        'ｐ':'p',
        'ｔ':'t'
    })
    if(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==8 and move[1]==' 'and move[4]=='-'and move[7]=='+')or(len(move)==4 and move[1]=='@'):
        if move[0].lower()not in('k','r','d','b','h','g','s','e','n','c','l','i','p','t'):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not((len(move)>=7 and move[2]in('1','2','3','4','5','6','7','8','9')and move[5]in('1','2','3','4','5','6','7','8','9')and move[3]in('a','b','c','d','e','f','g','h','i')and move[6]in('a','b','c','d','e','f','g','h','i'))or(len(move)==4 and move[2]in('1','2','3','4','5','6','7','8','9')and move[3]in('a','b','c','d','e','f','g','h','i'))):
            error="Move indexed out of bounds."
            return False
        elif (move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==8 and move[0].lower()in('k','g','d','h','e','c','i','t'):
            error="You may not promote a King, Gold, or promoted piece."
            return False
        elif len(move)==8 and move[0].lower()not in('k','g','d','h','e','c','i','t')and((move[6]not in('g','h','i')and not blackToMove)or(move[6]not in('a','b','c')and blackToMove)):
            error="You may only promote a piece within the promotion zone."
            return False
        elif len(move)==7 and(move[0].lower()not in('k','r','b','g','d','h','e','c','i','t','n')and(move[6]=='i'and not blackToMove)or(move[6]=='a'and blackToMove)):
            error="You must specify a promotion when moving a piece to the back rank."
            return False
        elif len(move)==8 and move[0].lower()=='n'and(((move[6]=='h'or move[6]=='i')and not blackToMove)or((move[6]=='a'or move[6]=='b')and blackToMove)):
            error="You must specify a promotion when moving a Knight onto the last or second-to-last rank, you must specify a promotion"
        elif move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower():
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif len(move)>=7 and move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        elif len(move)==4 and (blackHold if blackToMove else whiteHold).count(move[0])==0:
            error="You do not have any "+(move[0].swapcase()if playerCase else move[0])+"'s in your hand."
            return False
        if update:
            if len(move)>=7:
                if checkmoveSHOGI(move,checkForCheck,board,enemyMove)==True:
                    if move[0]=='K':
                        WKingPos=notationtoarraySHOGI(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarraySHOGI(move[5:7])
                    if board[int(move[5])-1][18-int(move[6],base=19)]!=' ':
                        if blackToMove:
                            if board[int(move[5])-1][18-int(move[6],base=19)]in('D','H','E','C','I','T'):
                                unpromotions={
                                    'D':'r',
                                    'H':'b',
                                    'E':'s',
                                    'C':'n',
                                    'I':'l',
                                    'T':'p'
                                }
                                blackHold.append(unpromotions[board[int(move[5])-1][18-int(move[6],base=19)]])
                            else:
                                blackHold.append(board[int(move[5])-1][18-int(move[6],base=19)].lower())
                            blackHold.sort(key=sortSHOGI)
                        else:
                            if board[int(move[5])-1][18-int(move[6],base=19)]in('d','h','e','c','i','t'):
                                unpromotions={
                                    'd':'R',
                                    'h':'B',
                                    'e':'S',
                                    'c':'N',
                                    'i':'L',
                                    't':'P'
                                }
                                whiteHold.append(unpromotions[board[int(move[5])-1][18-int(move[6],base=19)]])
                            else:
                                blackHold.append(board[int(move[5])-1][18-int(move[6],base=19)].upper())
                            whiteHold.sort(key=sortSHOGI)
                    board[int(move[5])-1][18-int(move[6],base=19)]=move[0]
                    board[int(move[2])-1][18-int(move[3],base=19)]=' '
                else:
                    error=checkmoveSHOGI(move,checkForCheck,board,enemyMove)
                    return False
                return True
            else:
                if checkmoveSHOGI(move,checkForCheck,board,enemyMove)==True:
                    board[int(move[2])-1][18-int(move[3],base=19)]=move[0]
                    if blackToMove:
                        blackHold.remove(move[0])
                    else:
                        whiteHold.remove(move[0])
                else:
                    error=checkmoveSHOGI(move,checkForCheck,board,enemyMove)
                    return False
                return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def sortSHOGI(piece):
    piecelist=('R','r','B','b','G','g','S','s','N','n','L','l','P','p')
    return piecelist.index(piece)
def checkpawn(move,board):
    global eP
    global playerCase
    if move[0]=='p':
        if move[3]!='7':
            if int(move[3])-int(move[6])==2:
                return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[3])-int(move[6])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][8-int(move[6])].islower():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='7'and int(move[3])-int(move[6])==2 and board[int(move[5],base=20)-10][8-int(move[6])]==' 'and board[int(move[5],base=20)-10][7-int(move[6])]==' ':
            return True
        return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
    else:
        if move[3]!='2':
            if int(move[6])-int(move[3])==2:
                return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[6])-int(move[3])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][8-int(move[6])].isupper():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='2'and int(move[6])-int(move[3])==2 and board[int(move[5],base=20)-10][8-int(move[6])]==' 'and board[int(move[5],base=20)-10][9-int(move[6])]==' ':
            return True
        return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
def checkmove(move,checkForCheck,board,enemyMove):
    global playerCase
    global WKingPos
    global BKingPos
    if move[0].lower()=='r':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='n':
        if (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='b':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='q':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='m':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='a':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='k':
        if abs(int(move[2],base=20)-int(move[5],base=20))>1 or abs(int(move[3])-int(move[6]))>1:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[2],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif checkpawn(move,board)!=True:
            return checkpawn(move,board)
    if checkForCheck:
        checkboard=copy.deepcopy(board)
        checkboard[int(move[5],base=20)-10][8-int(move[6])]=move[0]
        checkboard[int(move[2],base=20)-10][8-int(move[3])]=' '
        oldKings=[WKingPos,BKingPos]
        if move[0]=='K':
            WKingPos=notationtoarray(move[5:7])
        elif move[0]=='k':
            BKingPos=notationtoarray(move[5:7])
        if check(checkboard,blackToMove,enemyMove,4,0,7):
            WKingPos=oldKings[0]
            BKingPos=oldKings[1]
            return"You may not move into check."
        WKingPos=oldKings[0]
        BKingPos=oldKings[1]
    return True
def checkmoveSHOGI(moveIn,checkForCheck,board,enemyMove):
    global playerCase
    global WKingPos
    global BKingPos
    move=((moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-10)+moveIn[4]+chr(int(moveIn[5])+96)+str(int(moveIn[6],base=19)-10)+moveIn[7])if len(moveIn)==8 else((moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-10)+moveIn[4]+chr(int(moveIn[5])+96)+str(int(moveIn[6],base=19)-10))if len(moveIn)==7 else(moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-10))))
    if len(move)>=7:
        if move[0].lower()=='r':
            if move[2]==move[5]:
                if int(move[3])<int(move[6]):
                    for i in range(7-int(move[3]),8-int(move[6])):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(7-int(move[3]),8-int(move[6]),-1):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif move[3]==move[6]:
                if int(move[2],base=20)>int(move[5],base=20):
                    for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(int(move[5],base=20)-9,int(move[2],base=20)-10):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='d':
            if move[2]==move[5]:
                if int(move[3])<int(move[6]):
                    for i in range(7-int(move[3]),8-int(move[6])):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(8-int(move[3]),8-int(move[6])+1,-1):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif move[3]==move[6]:
                if int(move[2],base=20)>int(move[5],base=20):
                    for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(int(move[5],base=20)-9,int(move[2],base=20)-10):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif abs(int(move[2],base=19)-int(move[5],base=19))==1 and abs(int(move[3])-int(move[6]))==1:
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='b':
            if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
                if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='h':
            if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
                if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif not(abs(int(move[2],base=19)-int(move[5],base=19))>1 or abs(int(move[3])-int(move[6]))>1):
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='k':
            if abs(int(move[2],base=20)-int(move[5],base=20))>1 or abs(int(move[3])-int(move[6]))>1:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
            elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[2],base=20)-10][8-int(move[6])]!=' ':
                return"You may not capture your own pieces."
        if checkForCheck:
            checkboard=copy.deepcopy(board)
            checkboard[int(move[5],base=20)-10][8-int(move[6])]=move[0]
            checkboard[int(move[2],base=20)-10][8-int(move[3])]=' '
            if checkSHOGI(checkboard,blackToMove,(notationtoarraySHOGI(moveIn[5:7])if move[0].lower()=='k'else(WKingPos if move[0]=='K'else BKingPos))):
                return"You may not move into check."
    else:
        ""
    return True
def check(board,player,enemyMove,kingFile,queenRookFile,kingRookFile):
    if player:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].isupper()and makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos)+";Q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    else:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].islower()and makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos)+";q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    return False
def stalemate(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    for rankorigin in range(8):
        for fileorigin in range(len(board)):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(len(board)):
                            if player:
                                if makemove("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                            else:
                                if makemove("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                for rankdest in range(8):
                    for filedest in range(len(board)):
                        if makemove(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            return False
    return True
def stalemateCRAZYHOUSE(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
    for rankorigin in range(8):
        for fileorigin in range(8):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]==' ':
                if player:
                    if makemoveCRAZYHOUSE("p@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("r@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("n@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("b@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("q@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                        return False
                else:
                    if makemoveCRAZYHOUSE("P@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("R@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("N@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("B@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("Q@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                        return False
            else:
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(8):
                            if player:
                                if makemoveCRAZYHOUSE("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                                    return False
                            else:
                                if makemoveCRAZYHOUSE("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                                    return False
                for rankdest in range(8):
                    for filedest in range(8):
                        if makemoveCRAZYHOUSE(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                            return False
    return True
def CHESS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreCHESS
    global blackScoreCHESS
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"CHESS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCHESS)
            b=copy.copy(blackScoreCHESS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCHESS+=2
                    print("White wins by resignation. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                    break
                else:
                    blackScoreCHESS+=2
                    print("Black wins by resignation. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHESS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCHESS or b!=blackScoreCHESS:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        CHESS()
    else:
        mainMenu()
def learn():
    print(("How to Play CHESS\n\n    The goal of CHESS is to 'checkmate' your opponent's King. This is when the King is in 'check' and has no legal moves. Check is when your King is under threat of capture. It is illegal to make a move which places your King in check. If you are in check, you must immediately remove the check by doing one of three things:\n 1. Move the King so that it is no longer in check.\n 2. Capture the piece giving check.\n 3. Move a piece inbetween the King and the piece giving check.\nIf it is not possible to do any of these three things, the check is checkmate. Checkmate is not the only way that a game can end, however. The game can end in a draw, in which case each player gains 1/2 of a point. There are four ways for a game to end in a draw. One way that a game can be drawn is by stalemate, which is where a player is not in check but has no legal moves. Another way that a game can be drawn is via the fifty-move rule. This stipulates that if both players go 50 moves without capturing or moving a Pawn, the game ends in a draw. The game can also be drawn is if the same position is repeated three times (This is known as ‘Threefold repetition’, and is not implemented.). The final way a game can end in a draw is a draw by mutual agreement. Unlike resignation, draw offers MUST be accepted by the opposing player. Additionally, it is illegal to capture your own pieces.\n    Chess is played on an 8x8 board with files (columns) labeled a-h and ranks (rows) labeled 1-8. White starts with Pawns on the 2nd rank (a2, b2, c2, d2, e2, f2, g2, and h2), Rooks on a1 and h1, Knights on b1 and g1, Bishops on c1 and f1, a Queen on d1, and a King on e1. Black has pawns on the 7th rank, Rooks on a8 and h8, Knights on b8 and g8, Bishops on c8 and f8, a Queen on d8, and a King on e8. The Rook moves and captures by sliding any number of spaces directly up, down, left, or right. A Rook can be blocked from moving by another piece in its path. A Bishop moves by sliding any number of spaces diagonally, and is subject to the same movement restrictions as the Rook. The Queen has the combined moves of the Rook and the Bishop. The kNight jumps two spaces in one direction, and one space in another direction 90 degrees away from the first. A Knight jump can only be blocked at the destination, not anywhere inbetween. The King moves one space in any direction. The Pawn moves (but doesn't capture) one space forward. It captures by moving one space diagonally forward. A Pawn that has not moved yet may move two spaces forward, given that the two spaces directly in front of it are empty. A Pawn that has moved two spaces may be captured by an enemy Pawn by capturing to the space the Pawn moved over. This is known as 'en passant'. Pawns that reach their owner's 8th rank are promoted to another piece of the same color. Players can also make a special move known as 'castling', where the King moves two spaces towards one of its Rooks, and the Rook moves to the space that the King passed over. Castling is subject to the following restrictions:\n 1. Neither the King nor the Rook castling may have moved yet this game.\n 2. The King is not in check.\n 3. The King may not castle through check. This means that the space that the King moves over may not be attacked by an opponent's piece.\n 4. The King may not castle into check.\n 5. There may not be any pieces of either player inbetween the King and Rook.\n 6. The Rook castling must be on its owner's 1st rank.\n\nPress Enter to Return to Main Menu.\n"if ASCIIart<1 else"How to Play CHESS\n\n    The goal of CHESS is to ‘checkmate’ your opponent's King. This is when the King is in ‘check’ and has no legal moves. Check is when your King is under threat of capture. It is illegal to make a move which places your King in check. If you are in check, you must immediately remove the check by doing one of three things:\n 1. Move the King so that it is no longer in check.\n 2. Capture the piece giving check.\n 3. Move a piece inbetween the King and the piece giving check.\nIf it is not possible to do any of these three things, the check is checkmate. Checkmate is not the only way that a game can end, however. The game can end in a draw, in which case each player gains ½ of a point. There are four ways for a game to end in a draw. One way that a game can be drawn is by stalemate, which is where a player is not in check but has no legal moves. Another way that a game can be drawn is via the fifty-move rule. This stipulates that if both players go 50 moves without capturing or moving a Pawn, the game ends in a draw. The game can also be drawn is if the same position is repeated three times (This is known as ‘Threefold repetition’, and is not implemented.). The final way a game can end in a draw is a draw by mutual agreement. Unlike resignation, draw offers MUST be accepted by the opposing player. Additionally, it is illegal to capture your own pieces.\n    Chess is played on an 8×8 board with files (columns) labeled a-h and ranks (rows) labeled 1-8. White starts with Pawns on the 2ⁿᵈ rank (a2, b2, c2, d2, e2, f2, g2, and h2), Rooks on a1 and h1, kNights on b1 and g1, Bishops on c1 and f1, a Queen on d1, and a King on e1. Black has pawns on the 7ᵗʰ rank, Rooks on a8 and h8, kNights on b8 and g8, Bishops on c8 and f8, a Queen on d8, and a King on e8. The Rook moves and captures by sliding any number of spaces directly up, down, left, or right. A Rook can be blocked from moving by another piece in its path. A Bishop moves by sliding any number of spaces diagonally, and is subject to the same movement restrictions as the Rook. The Queen has the combined moves of the Rook and the Bishop. The kNight jumps two spaces in one direction, and one space in another direction 90° away from the first. A kNight jump can only be blocked at the destination, not anywhere inbetween. The King moves one space in any direction. The Pawn moves (but doesn't capture) one space forward. It captures by moving one space diagonally forward. A Pawn that has not moved yet may move two spaces forward, given that the two spaces directly in front of it are empty. A Pawn that has moved two spaces may be captured by an enemy Pawn by capturing to the space the Pawn moved over. This is known as ‘en passant’. Pawns that reach their owner's 8ᵗʰ rank are promoted to another piece of the same color. Players can also make a special move known as ‘castling’, where the King moves two spaces towards one of its Rooks, and the Rook moves to the space that the King passed over. Castling is subject to the following restrictions:\n 1. Neither the King nor the Rook castling may have moved yet this game.\n 2. The King is not in check.\n 3. The King may not castle through check. This means that the space that the King moves over may not be attacked by an opponent's piece.\n 4. The King may not castle into check.\n 5. There may not be any pieces of either player inbetween the King and Rook.\n 6. The Rook castling must be on its owner's 1st rank.\n\nPress Enter to Return to Main Menu.\n")if ASCIIart<2 else"How to Play CHESS\n\n    The goal of CHESS is to ‘checkmate’ your opponent's King. This is when the King is in ‘check’ and has no legal moves. Check is when your King is under threat of capture. It is illegal to make a move which places your King in check. If you are in check, you must immediately remove the check by doing one of three things:\n ⒈ Move the King so that it is no longer in check.\n ⒉ Capture the piece giving check.\n ⒊ Move a piece inbetween the King and the piece giving check.\nIf it is not possible to do any of these three things, the check is checkmate. Checkmate is not the only way that a game can end, however. The game can end in a draw, in which case each player gains ½ of a point. There are four ways for a game to end in a draw. One way that a game can be drawn is by stalemate, which is where a player is not in check but has no legal moves. Another way that a game can be drawn is via the ﬁfty‐move rule. This stipulates that if both players go 50 moves without capturing or moving a Pawn, the game ends in a draw. The game can also be drawn is if the same position is repeated three times (This is known as ‘Threefold repetition’, and is not implemented.). The final way a game can end in a draw is a draw by mutual agreement. Unlike resignation, draw oﬀers MUST be accepted by the opposing player. Additionally, it is illegal to capture your own pieces.\n    Chess is played on an 8×8 board with files (columns) labeled a‐h and ranks (rows) labeled 1‐8. White starts with Pawns on the 2ⁿᵈ rank (a2, b2, c2, d2, e2, f2, g2, and h2), Rooks on a1 and h1, Knights on b1 and g1, Bishops on c1 and f1, a Queen on d1, and a King on e1. Black has pawns on the 7ᵗʰ rank, Rooks on a8 and h8, Knights on b8 and g8, Bishops on c8 and f8, a Queen on d8, and a King on e8. The Rook moves and captures by sliding any number of spaces directly up, down, left, or right. A Rook can be blocked from moving by another piece in its path. A Bishop moves by sliding any number of spaces diagonally, and is subject to the same movement restrictions as the Rook. The Queen has the combined moves of the Rook and the Bishop. The Knight jumps two spaces in one direction, and one space in another direction 90° away from the ﬁrst. A Knight jump can only be blocked at the destination, not anywhere inbetween. The King moves one space in any direction. The Pawn moves (but doesn't capture) one space forward. It captures by moving one space diagonally forward. A Pawn that has not moved yet may move two spaces forward, given that the two spaces directly in front of it are empty. A Pawn that has moved two spaces may be captured by an enemy Pawn by capturing to the space the Pawn moved over. This is known as ‘en passant’. Pawns that reach their owner's 8ᵗʰ rank are promoted to another piece of the same color. Players can also make a special move known as ‘castling’, where the King moves two spaces towards one of its Rooks, and the Rook moves to the space that the King passed over. Castling is subject to the following restrictions:\n ⒈ Neither the King nor the Rook castling may have moved yet this game.\n ⒉ The King is not in check.\n ⒊ The King may not castle through check. This means that the space that the King moves over may not be attacked by an opponent's piece.\n ⒋ The King may not castle into check.\n ⒌ There may not be any pieces of either player inbetween the King and Rook.\n ⒍ The Rook castling must be on its owner's 1ˢᵗ rank.\n\nPress Enter to Return to Main Menu.\n")
    input("")
    mainMenu()
def settings():
    global ASCIIart
    global boardFlip
    global playerCase
    global darkMode
    print("  SETTINGS\n  --------\n1|Unicode Support: "+("ASCII Only"if ASCIIart==0 else("Basic Unicode"if ASCIIart==1 else"Extended Unicode"))+"\n2|Board Flips: "+("ON"if boardFlip else"OFF")+"\n3|Capital Letters Represent: "+("BLACK"if playerCase else"WHITE")+"\n4|Dark Mode: "+("ON"if darkMode else"OFF")+"\n5|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>5:
        print("Option "+str(selection)+" does not exist.\n\n  SETTINGS\n  --------\n1|Unicode Support :"+("ASCII Only"if ASCIIart==0 else("Basic Unicode"if ASCIIart==1 else"Extended Unicode"))+"\n2|Board Flips: "+("ON"if boardFlip else"OFF")+"\n3|Capital Letters Represent :"+("BLACK"if playerCase else"WHITE")+"\n4|Dark Mode: "+("ON"if darkMode else"OFF")+"\n5|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ASCIIart=(ASCIIart+1)%3
        settings()
    elif selection==2:
        boardFlip=not boardFlip
        settings()
    elif selection==3:
        playerCase=not playerCase
        settings()
    elif selection==4:
        darkMode=not darkMode
        settings()
    else:
        os.remove(os.path.join(filesystem,"Settings_"+versionNumber+".ini"))
        settingsFile=open(os.path.join(filesystem,"Settings_"+versionNumber+".ini"),"w+")
        settingsFile.write("Unicode Support: "+("ASCII Only"if ASCIIart==0 else("Basic Unicode"if ASCIIart==1 else"Extended Unicode"))+"\nBoard Flips: "+("ON"if boardFlip else"OFF")+"\nCapital Letters Represent: "+("BLACK"if playerCase else"WHITE")+"\nDark Mode: "+("ON"if darkMode else"OFF"))
        settingsFile.close()
        mainMenu()
def variantslist():
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        print(str(i+1)+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        variantslistsearch(letter)
    elif selection!=len(variantsList)+2:
        eval(variantsList[selection-1]+"()")
    mainMenu()
def variantslistsearch(letter):
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        if variantsList[i][0]==letter:
            print(str(i+1)+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            if variantsList[i][0]==letter:
                print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        variantslistsearch(letter)
    elif selection<len(variantsList)+1:
        eval(variantsList[selection-1]+"()")
def learnvariant():
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        print(str(i+1)+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        learnvariantsearch(letter)
    elif selection<len(variantsList)+1:
        print("How to Play "+variantsList[selection-1]+"\n\n"+variantsRules[selection-1]+"\n\nPress Enter to Return to Main Menu.\n")
        input("")
    mainMenu()
def learnvariantsearch(letter):
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        if variantsList[i][0]==letter:
            print(str(i+1)+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            if variantsList[i][0]==letter:
                print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        learnvariantsearch(letter)
    elif selection<len(variantsList)+1:
        print("How to Play "+variantsList[selection-1]+"\n\n"+variantsRules[selection-1]+"\n\nPress Enter to Return to Main Menu.\n")
        input("")
    mainMenu()
def DEATHMATCH(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreDEATHMATCH
    global blackScoreDEATHMATCH
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"DEATHMATCH",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreDEATHMATCH)
            b=copy.copy(blackScoreDEATHMATCH)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreDEATHMATCH+=2
                    print("White wins by resignation. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                    break
                else:
                    blackScoreDEATHMATCH+=2
                    print("Black wins by resignation. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreDEATHMATCH+=1
                        blackScoreDEATHMATCH+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreDEATHMATCH+=1
                        blackScoreDEATHMATCH+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("DEATHMATCH")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,False,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,False,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreDEATHMATCH or b!=blackScoreDEATHMATCH:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        DEATHMATCH()
    else:
        mainMenu()
def CHESS960(*setup):
    global gameboard
    global WKingPos
    global BKingPos
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global fiftymoves
    global eP
    global whiteScoreCHESS960
    global blackScoreCHESS960
    global playerCase
    if len(setup)==0:
        while True:
            backrank=['R','N','B','Q','K','B','N','R']
            random.shuffle(backrank)
            if backrank.index('B')%2!="".join(backrank).rindex('B')%2 and backrank.index('R')<backrank.index('K')and backrank.index('K')<"".join(backrank).rindex('R'):
                kingFile=backrank.index('K')
                queenRookFile=backrank.index('R')
                kingRookFile="".join(backrank).rindex('R')
                gameboard=[[backrank[0].lower(),'p',' ',' ',' ',' ','P',backrank[0]],[backrank[1].lower(),'p',' ',' ',' ',' ','P',backrank[1]],[backrank[2].lower(),'p',' ',' ',' ',' ','P',backrank[2]],[backrank[3].lower(),'p',' ',' ',' ',' ','P',backrank[3]],[backrank[4].lower(),'p',' ',' ',' ',' ','P',backrank[4]],[backrank[5].lower(),'p',' ',' ',' ',' ','P',backrank[5]],[backrank[6].lower(),'p',' ',' ',' ',' ','P',backrank[6]],[backrank[7].lower(),'p',' ',' ',' ',' ','P',backrank[7]]]
                break
        WKingPos=(kingFile,7)
        BKingPos=(kingFile,0)
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        fiftymoves=0
        eP=False
    else:
        queenRookFile=setup[0][0]
        kingFile=setup[0][1]
        kingRookFile=setup[0][2]
    while True:
        if drawboard(list(gameboard),"CHESS960",[kingFile,queenRookFile,kingRookFile]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCHESS960)
            b=copy.copy(blackScoreCHESS960)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCHESS960+=2
                    print("White wins by resignation. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                    break
                else:
                    blackScoreCHESS960+=2
                    print("Black wins by resignation. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS960+=1
                        blackScoreCHESS960+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS960+=1
                        blackScoreCHESS960+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHESS960",str(queenRookFile)+str(kingFile)+str(kingRookFile))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,kingFile,queenRookFile,kingRookFile))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,kingFile,queenRookFile,kingRookFile)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCHESS960 or b!=blackScoreCHESS960:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CHESS960()
    else:
        mainMenu()
def ROOKS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreROOKS
    global blackScoreROOKS
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['k','p',' ',' ',' ',' ','P','K'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"ROOKS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreROOKS)
            b=copy.copy(blackScoreROOKS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreROOKS+=2
                    print("White wins by resignation. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+("½"if whiteScoreROOKS%2==1 else"")+"-"+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+("½"if blackScoreROOKS%2==1 else""))
                    break
                else:
                    blackScoreROOKS+=2
                    print("Black wins by resignation. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+("½"if whiteScoreROOKS%2==1 else"")+"-"+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+("½"if blackScoreROOKS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreROOKS+=1
                        blackScoreROOKS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+("½"if whiteScoreROOKS%2==1 else"")+"-"+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+("½"if blackScoreROOKS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreROOKS+=1
                        blackScoreROOKS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreROOKS//2)if whiteScoreROOKS!=1 else"")+("½"if whiteScoreROOKS%2==1 else"")+"-"+(str(blackScoreROOKS//2)if blackScoreROOKS!=1 else"")+("½"if blackScoreROOKS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("ROOKS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreROOKS or b!=blackScoreROOKS:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ROOKS()
    else:
        mainMenu()
def CRAZYHOUSE(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreCRAZYHOUSE
    global blackScoreCRAZYHOUSE
    global playerCase
    global promotions
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
        whiteHold=[0,0,0,0,0]
        blackHold=[0,0,0,0,0]
        promotions=[]
    else:
        whiteHold=list(map(int,setup[0][:9].split("-")))
        blackHold=list(map(int,setup[0][9:18].split("-")))
        promotions=(list(map(tuple,setup[0][18:].split("/")))if len(setup[0])>18 else[])
    while True:
        if drawboardCRAZYHOUSE(list(gameboard),whiteHold,blackHold):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCRAZYHOUSE)
            b=copy.copy(blackScoreCRAZYHOUSE)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCRAZYHOUSE+=2
                    print("White wins by resignation. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
                    break
                else:
                    blackScoreCRAZYHOUSE+=2
                    print("Black wins by resignation. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCRAZYHOUSE+=1
                        blackScoreCRAZYHOUSE+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCRAZYHOUSE+=1
                        blackScoreCRAZYHOUSE+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCRAZYHOUSE//2)if whiteScoreCRAZYHOUSE!=1 else"")+("½"if whiteScoreCRAZYHOUSE%2==1 else"")+"-"+(str(blackScoreCRAZYHOUSE//2)if blackScoreCRAZYHOUSE!=1 else"")+("½"if blackScoreCRAZYHOUSE%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CRAZYHOUSE","-".join(list(map(str,whiteHold)))+"-".join(list(map(str,blackHold)))+"/".join(list(map(lambda x:str(x[0])+str(x[1]),promotions))))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O"and not(len(move)==4 and move[1]=='@'):
                error=("Bad move format.")
            elif(not playerCase and makemoveCRAZYHOUSE(move,True,True,gameboard,False,4,0,7,whiteHold,blackHold))or(playerCase and makemoveCRAZYHOUSE(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,whiteHold,blackHold)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCRAZYHOUSE or b!=blackScoreCRAZYHOUSE:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CRAZYHOUSE()
    else:
        mainMenu()
def KNIGHTS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreKNIGHTS
    global blackScoreKNIGHTS
    global playerCase
    if len(setup)==0:
        gameboard=[['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['k','p',' ',' ',' ',' ','P','K'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"KNIGHTS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreKNIGHTS)
            b=copy.copy(blackScoreKNIGHTS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreKNIGHTS+=2
                    print("White wins by resignation. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+("½"if whiteScoreKNIGHTS%2==1 else"")+"-"+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+("½"if blackScoreKNIGHTS%2==1 else""))
                    break
                else:
                    blackScoreKNIGHTS+=2
                    print("Black wins by resignation. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+("½"if whiteScoreKNIGHTS%2==1 else"")+"-"+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+("½"if blackScoreKNIGHTS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreKNIGHTS+=1
                        blackScoreKNIGHTS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+("½"if whiteScoreKNIGHTS%2==1 else"")+"-"+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+("½"if blackScoreKNIGHTS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreKNIGHTS+=1
                        blackScoreKNIGHTS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreKNIGHTS//2)if whiteScoreKNIGHTS!=1 else"")+("½"if whiteScoreKNIGHTS%2==1 else"")+"-"+(str(blackScoreKNIGHTS//2)if blackScoreKNIGHTS!=1 else"")+("½"if blackScoreKNIGHTS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("KNIGHTS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('n','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('n','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreKNIGHTS or b!=blackScoreKNIGHTS:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        KNIGHTS()
    else:
        mainMenu()
def BISHOPS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreBISHOPS
    global blackScoreBISHOPS
    global playerCase
    if len(setup)==0:
        gameboard=[['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['k','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(3,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"BISHOPS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreBISHOPS)
            b=copy.copy(blackScoreBISHOPS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreBISHOPS+=2
                    print("White wins by resignation. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+("½"if whiteScoreBISHOPS%2==1 else"")+"-"+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+("½"if blackScoreBISHOPS%2==1 else""))
                    break
                else:
                    blackScoreBISHOPS+=2
                    print("Black wins by resignation. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+("½"if whiteScoreBISHOPS%2==1 else"")+"-"+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+("½"if blackScoreBISHOPS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreBISHOPS+=1
                        blackScoreBISHOPS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+("½"if whiteScoreBISHOPS%2==1 else"")+"-"+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+("½"if blackScoreBISHOPS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreBISHOPS+=1
                        blackScoreBISHOPS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreBISHOPS//2)if whiteScoreBISHOPS!=1 else"")+("½"if whiteScoreBISHOPS%2==1 else"")+"-"+(str(blackScoreBISHOPS//2)if blackScoreBISHOPS!=1 else"")+("½"if blackScoreBISHOPS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("BISHOPS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('b','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('b','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreBISHOPS or b!=blackScoreBISHOPS:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        BISHOPS()
    else:
        mainMenu()
def QUEENS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreQUEENS
    global blackScoreQUEENS
    global playerCase
    if len(setup)==0:
        gameboard=[['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"QUEENS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreQUEENS)
            b=copy.copy(blackScoreQUEENS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreQUEENS+=2
                    print("White wins by resignation. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+("½"if whiteScoreQUEENS%2==1 else"")+"-"+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+("½"if blackScoreQUEENS%2==1 else""))
                    break
                else:
                    blackScoreQUEENS+=2
                    print("Black wins by resignation. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+("½"if whiteScoreQUEENS%2==1 else"")+"-"+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+("½"if blackScoreQUEENS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreQUEENS+=1
                        blackScoreQUEENS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+("½"if whiteScoreQUEENS%2==1 else"")+"-"+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+("½"if blackScoreQUEENS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreQUEENS+=1
                        blackScoreQUEENS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreQUEENS//2)if whiteScoreQUEENS!=1 else"")+("½"if whiteScoreQUEENS%2==1 else"")+"-"+(str(blackScoreQUEENS//2)if blackScoreQUEENS!=1 else"")+("½"if blackScoreQUEENS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("QUEENS")
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('q','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('q','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreQUEENS or b!=blackScoreQUEENS:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        QUEENS()
    else:
        mainMenu()
def ROOKS_CASTLING(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreROOKS_CASTLING
    global blackScoreROOKS_CASTLING
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['k','p',' ',' ',' ',' ','P','K'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"ROOKS_CASTLING",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreROOKS_CASTLING)
            b=copy.copy(blackScoreROOKS_CASTLING)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreROOKS_CASTLING+=2
                    print("White wins by resignation. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+("½"if whiteScoreROOKS_CASTLING%2==1 else"")+"-"+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+("½"if blackScoreROOKS_CASTLING%2==1 else""))
                    break
                else:
                    blackScoreROOKS_CASTLING+=2
                    print("Black wins by resignation. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+("½"if whiteScoreROOKS_CASTLING%2==1 else"")+"-"+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+("½"if blackScoreROOKS_CASTLING%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreROOKS_CASTLING+=1
                        blackScoreROOKS_CASTLING+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+("½"if whiteScoreROOKS_CASTLING%2==1 else"")+"-"+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+("½"if blackScoreROOKS_CASTLING%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreROOKS_CASTLING+=1
                        blackScoreROOKS_CASTLING+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreROOKS_CASTLING//2)if whiteScoreROOKS_CASTLING!=1 else"")+("½"if whiteScoreROOKS_CASTLING%2==1 else"")+"-"+(str(blackScoreROOKS_CASTLING//2)if blackScoreROOKS_CASTLING!=1 else"")+("½"if blackScoreROOKS_CASTLING%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("ROOKS_CASTLING")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreROOKS_CASTLING or b!=blackScoreROOKS_CASTLING:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ROOKS_CASTLING()
    else:
        mainMenu()
def NO_CASTLING(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreNO_CASTLING
    global blackScoreNO_CASTLING
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"NO_CASTLING",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreNO_CASTLING)
            b=copy.copy(blackScoreNO_CASTLING)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreNO_CASTLING+=2
                    print("White wins by resignation. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+("½"if whiteScoreNO_CASTLING%2==1 else"")+"-"+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+("½"if blackScoreNO_CASTLING%2==1 else""))
                    break
                else:
                    blackScoreNO_CASTLING+=2
                    print("Black wins by resignation. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+("½"if whiteScoreNO_CASTLING%2==1 else"")+"-"+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+("½"if blackScoreNO_CASTLING%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreNO_CASTLING+=1
                        blackScoreNO_CASTLING+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+("½"if whiteScoreNO_CASTLING%2==1 else"")+"-"+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+("½"if blackScoreNO_CASTLING%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreNO_CASTLING+=1
                        blackScoreNO_CASTLING+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreNO_CASTLING//2)if whiteScoreNO_CASTLING!=1 else"")+("½"if whiteScoreNO_CASTLING%2==1 else"")+"-"+(str(blackScoreNO_CASTLING//2)if blackScoreNO_CASTLING!=1 else"")+("½"if blackScoreNO_CASTLING%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("NO_CASTLING")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreNO_CASTLING or b!=blackScoreNO_CASTLING:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        NO_CASTLING()
    else:
        mainMenu()
def THREECHECK(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreTHREECHECK
    global blackScoreTHREECHECK
    global playerCase
    global whiteCheckCount
    global blackCheckCount
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
        whiteCheckCount=0
        blackCheckCount=0
    else:
        whiteCheckCount=int(setup[0][0])
        blackCheckCount=int(setup[0][1])
    while True:
        if drawboard(list(gameboard),"THREECHECK",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreTHREECHECK)
            b=copy.copy(blackScoreTHREECHECK)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreTHREECHECK+=2
                    print("White wins by resignation. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+("½"if whiteScoreTHREECHECK%2==1 else"")+"-"+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+("½"if blackScoreTHREECHECK%2==1 else""))
                    break
                else:
                    blackScoreTHREECHECK+=2
                    print("Black wins by resignation. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+("½"if whiteScoreTHREECHECK%2==1 else"")+"-"+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+("½"if blackScoreTHREECHECK%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreTHREECHECK+=1
                        blackScoreTHREECHECK+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+("½"if whiteScoreTHREECHECK%2==1 else"")+"-"+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+("½"if blackScoreTHREECHECK%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreTHREECHECK+=1
                        blackScoreTHREECHECK+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreTHREECHECK//2)if whiteScoreTHREECHECK!=1 else"")+("½"if whiteScoreTHREECHECK%2==1 else"")+"-"+(str(blackScoreTHREECHECK//2)if blackScoreTHREECHECK!=1 else"")+("½"if blackScoreTHREECHECK%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("THREECHECK",str(whiteCheckCount)+str(blackCheckCount))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreTHREECHECK or b!=blackScoreTHREECHECK:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        THREECHECK()
    else:
        mainMenu()
def CHOOSECOMPOUND(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreCHOOSECOMPOUND
    global blackScoreCHOOSECOMPOUND
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],[' ','p',' ',' ',' ',' ','P',' '],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']] 
        x=input("White, which piece would you like to have? (‘Q’, ‘M’, or ‘A’)")
        while x not in['Q','M','A']:
            x=input("White, which piece would you like to have? (‘Q’, ‘M’, or ‘A’)")
        gameboard[3][7]=x
        x=input("Black, which piece would you like to have? (‘q’, ‘m’, or ‘a’)")
        while x not in['q','m','a']:
            x=input("Black, which piece would you like to have? (‘q’, ‘m’, or ‘a’)")
        gameboard[3][0]=x
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"CHOOSECOMPOUND",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCHOOSECOMPOUND)
            b=copy.copy(blackScoreCHOOSECOMPOUND)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCHOOSECOMPOUND+=2
                    print("White wins by resignation. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+("½"if whiteScoreCHOOSECOMPOUND%2==1 else"")+"-"+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+("½"if blackScoreCHOOSECOMPOUND%2==1 else""))
                    break
                else:
                    blackScoreCHOOSECOMPOUND+=2
                    print("Black wins by resignation. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+("½"if whiteScoreCHOOSECOMPOUND%2==1 else"")+"-"+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+("½"if blackScoreCHOOSECOMPOUND%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHOOSECOMPOUND+=1
                        blackScoreCHOOSECOMPOUND+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+("½"if whiteScoreCHOOSECOMPOUND%2==1 else"")+"-"+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+("½"if blackScoreCHOOSECOMPOUND%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHOOSECOMPOUND+=1
                        blackScoreCHOOSECOMPOUND+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHOOSECOMPOUND//2)if whiteScoreCHOOSECOMPOUND!=1 else"")+("½"if whiteScoreCHOOSECOMPOUND%2==1 else"")+"-"+(str(blackScoreCHOOSECOMPOUND//2)if blackScoreCHOOSECOMPOUND!=1 else"")+("½"if blackScoreCHOOSECOMPOUND%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHOOSECOMPOUND")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','n','b','q','k','p','m','a')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','n','b','q','k','p','m','a'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCHOOSECOMPOUND or b!=blackScoreCHOOSECOMPOUND:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CHOOSECOMPOUND()
    else:
        mainMenu()
def CAPABLANCA(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global whiteScoreCAPABLANCA
    global blackScoreCAPABLANCA
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['a','p',' ',' ',' ',' ','P','A'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['m','p',' ',' ',' ',' ','P','M'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard10x8(list(gameboard),"CAPABLANCA",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCAPABLANCA)
            b=copy.copy(blackScoreCAPABLANCA)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCAPABLANCA+=2
                    print("White wins by resignation. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
                    break
                else:
                    blackScoreCAPABLANCA+=2
                    print("Black wins by resignation. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCAPABLANCA+=1
                        blackScoreCAPABLANCA+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCAPABLANCA+=1
                        blackScoreCAPABLANCA+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCAPABLANCA//2)if whiteScoreCAPABLANCA!=1 else"")+("½"if whiteScoreCAPABLANCA%2==1 else"")+"-"+(str(blackScoreCAPABLANCA//2)if blackScoreCAPABLANCA!=1 else"")+("½"if blackScoreCAPABLANCA%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CAPABLANCA")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove10x8(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove10x8(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCAPABLANCA or b!=blackScoreCAPABLANCA:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CAPABLANCA()
    else:
        mainMenu()
def mainMenu():
    if filesystem==False:
        print("  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n7|Open SANDBOX\n8|Load Game\n9|Report a Bug\n10|QUIT\n")
        selection=int(input(""))
        while selection<1 or selection>10 or selection==6:
            print("Option "+str(selection)+" does not exist.\n\n  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n7|Open SANDBOX\n8|Load Game\n9|Report a Bug\n10|QUIT\n")
            selection=int(input(""))
        if selection==1:
            CHESS()
        elif selection==2:
            settings()
        elif selection==3:
            variantslist()
        elif selection==4:
            learn()
        elif selection==5:
            learnvariant()
        elif selection==7:
            SANDBOX()
        elif selection==8:
            loadgame(input("Enter the saved game here: "))
        elif selection==9:
            if browser_ext:
                webbrowser.open("https://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            else:
                print("Use this URL:\nhttps://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
    else:
        print("  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n6|User's Guide\n7|Open SANDBOX\n8|Load Game\n9|Report a Bug\n10|QUIT\n")
        selection=int(input(""))
        while selection<1 or selection>10:
            print("Option "+str(selection)+" does not exist.\n\n  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n6|User's Guide\n7|Open SANDBOX\n8|Load Game\n9|Report a Bug\n10|QUIT\n")
            selection=int(input(""))
        if selection==1:
            CHESS()
        elif selection==2:
            settings()
        elif selection==3:
            variantslist()
        elif selection==4:
            learn()
        elif selection==5:
            learnvariant()
        elif selection==6:
            try:
                os.startfile(os.path.join(filesystem,"PyChess User's Guide.docx"))
            except FileNotFoundError:
                print("The PyChess User's Guide couldn't be found. Perhaps it has been deleted or moved?\n")
            mainMenu()
        elif selection==7:
            SANDBOX()
        elif selection==8:
            loadgame(input("Enter the saved game here: "))
        elif selection==9:
            if browser_ext:
                webbrowser.open("https://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            else:
                print("Use this URL:\nhttps://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
def SANDBOX(*setup):
    global gameboard
    global error
    error=""
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
    while True:
        drawboardSANDBOX()
        error=""
        while True:
            exitcommand=False
            breakFlag=False
            moveRaw=input(error)
            for move in list(map(lambda x:x.strip(),moveRaw.split(';'))):
                for i in range(len(move)-3):
                    if move[i:i+2]=="U+":
                        for j in range(min(i+8,len(move)),i+2,-1):
                            try:
                                if int(move[i+2:j],base=16)<=1114111 and int(move[i+2:j],base=16)>0:
                                    move=move.replace(move[i:j],chr(int(move[i+2:j],base=16)))
                                break
                            except ValueError:
                                ""
                if move=="Quit"or move=="Exit":
                    exitcommand=True
                    breakFlag=True
                elif move=="+FileR":
                    fileinsert=[]
                    for i in range(len(gameboard[0])):
                        fileinsert.append(' ')
                    gameboard.append(fileinsert)
                    breakFlag=True
                elif move=="+FileL":
                    fileinsert=[]
                    for i in range(len(gameboard[0])):
                        fileinsert.append(' ')
                    gameboard=[fileinsert,]+gameboard
                    breakFlag=True
                elif move=="+RankU":
                    if len(gameboard[0])>=9:
                        error="Sorry, you cannot have more than 9 ranks."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i]=[' ',]+gameboard[i]
                        breakFlag=True
                elif move=="+RankD":
                    if len(gameboard[0])>=9:
                        error="Sorry, you cannot have more than 9 ranks."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].append(' ')
                        breakFlag=True
                elif move=="-FileR":
                    if len(gameboard)<=1:
                        error="You cannot remove the only file in a board."
                    else:
                        gameboard.pop()
                        breakFlag=True
                elif move=="-FileL":
                    if len(gameboard)<=1:
                        error="You cannot remove the only file in a board."
                    else:
                        gameboard.pop(0)
                        breakFlag=True
                elif move=="-RankU":
                    if len(gameboard[0])<=1:
                        error="You cannot remove the only rank in a board."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].pop(0)
                        breakFlag=True
                elif move=="-RankD":
                    if len(gameboard[0])<=1:
                        error="You cannot remove the only rank in a board."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].pop()
                        breakFlag=True
                elif len(move)==7 and move[1]==' 'and move[4]=='-':
                    if ord(move[2])-97>=len(gameboard)or ord(move[5])-97>=len(gameboard)or ord(move[2])<97 or ord(move[5])<97 or int(move[3])>len(gameboard[0])or int(move[6])>len(gameboard[0])or int(move[3])<1 or int(move[6])<1:
                        error="Coordinate out of bounds."
                    else:
                        if gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]!=move[0]:
                            error="There is not a "+move[0]+" on "+move[2:4]
                        else:
                            gameboard[int(move[5],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[6])]=move[0]
                            gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]=' '
                            breakFlag=True
                elif len(move)==4 and move[1]=='@':
                    if ord(move[2])-97>len(gameboard)or ord(move[2])<97 or int(move[3])>len(gameboard[0])or int(move[3])<1:
                        error="Coordinate out of bounds."
                    else:
                        gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]=move[0]
                        breakFlag=True
                elif len(move)==3 and move[0]=='*':
                    if ord(move[1])-97>len(gameboard)or ord(move[1])<97 or int(move[2])>len(gameboard[0])or int(move[2])<1:
                        error="Coordinate out of bounds."
                    else:
                        gameboard[int(move[1],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[2])]=' '
                        breakFlag=True
                else:
                    error="Invalid Move"
            if breakFlag:
                break
        if exitcommand:
            break
    mainMenu()
global versionNumber
versionNumber="1.2-Dev3"
print("  PyChess "+versionNumber)
global ASCIIart
global boardFlip
global playerCase
global darkMode
if filesystem==False:
    ASCIIart=0
    boardFlip=False
    playerCase=False
    darkMode=False
elif not os.path.isfile(os.path.join(filesystem,"Settings_"+versionNumber+".ini")):
    ASCIIart=0
    boardFlip=False
    playerCase=False
    darkMode=False
    settingsFile=open("Settings_"+versionNumber+".ini","w+")
    settingsFile.write("Unicode Support: ASCII only\nBoard Flips: OFF\nCapital Letters Represent: WHITE\nDark Mode: OFF")
    settingsFile.close()
else:
    settingsFile=open("Settings_"+versionNumber+".ini","r")
    settingsOptions=settingsFile.read().split('\n')
    settingsFile.close()
    if len(settingsOptions)!=4:
        os.remove(os.path.join(filesystem,"Settings_"+versionNumber+".ini"))
        ASCIIart=0
        boardFlip=False
        playerCase=False
        darkMode=False
        settingsFile=open("Settings_"+versionNumber+".ini","w+")
        settingsFile.write("Unicode Support: ASCII only\nBoard Flips: OFF\nCapital Letters Represent: WHITE\nDark Mode: OFF")
        settingsFile.close()
    else:
        ASCIIart=["Unicode Support: ASCII only","Unicode Support: Basic Unicode","Unicode Support: Extended Unicode"].index(settingsOptions[0])
        boardFlip=settingsOptions[1]=="Board Flips: ON"
        playerCase=settingsOptions[2]=="Capital Letters Represent: BLACK"
        darkMode=settingsOptions[3]=="Dark Mode: ON"
global variantsList
global variantsRules
variantsList=["DEATHMATCH","CHESS960","ROOKS","CRAZYHOUSE","KNIGHTS","BISHOPS","QUEENS","ROOKS_CASTLING","NO_CASTLING","THREECHECK","CHOOSECOMPOUND","CAPABLANCA"]
variantsRules=["    Deathmatch Chess is played exactly the same as CHESS, but with a different win condition. The objective of deathmatch chess is not to checkmate your opponent's King, but to capture all of your opponent's pieces, with the exception of pawns.","    Chess960 is played exactly like CHESS, but with a random starting position of the back rank. Starting positions are subject to three restrictions:\n 1. Both bishops may not reside on the same color square.\n 2. The King must be between the two Rooks.\n 3. White and Black must have mirrored starting positions. When castling, both King and Rook move to the spaces that the do in CHESS. (King to c-file and Rook to d-file for Queenside castling, and King to g-file and Rook to f-file for Kingside castling.)","    Rooks is played exactly like CHESS but all of the back rank pieces (Except the King) are replaced with Rooks. Aditionally, castling is removed.","    Crazyhouse is played exactly like CHESS, except that when you capture a piece, you can, on a later turn, drop the captured piece onto an empty space as your own instead of moving. It is illegal to drop pawns on the 1ˢᵗ or 8ᵗʰ rank.","    Same as ROOKS, but with Knights.","    Same as ROOKS, but with Bishops. Aditionally, Black's King starts on d8 rather than e8 to mantain a balance of Bishops on each color space between sides.","    Same as ROOKS, but with Queens.","    Same as ROOKS, but you can castle.","    Same as CHESS, but without castling.","    Same as CHESS, but you can win by checking the opponent 3 times.","    Same as CHESS but at the beginning of the game, you can choose one of three pieces to occupy the Queen's position in the starting position of CHESS. These options are: Queen [Q] (Moves like a Queen in CHESS.), Chancellor [M] (Moves like a CHESS Rook or Knight.), and Cardinal [A] (Moves like a CHESS Bishop or Knight.)","    Played like CHESS, but on a 10×8 board with additional compounds. These are the chancellor[M] and the cArdinal. The chancellor has the combined moves of a CHESS Rook and Knight. The cArdinal has the combined move of a CHESS Bishop and Knight. Castling now involves the Rook moving three spaces instead of two. Each player has two additional Pawns to keep their 2ⁿᵈ rank full. The back rank now has Rooks on a1 and j1, Knights on b1 and i1, Bishops on d1 and g1, a Queen on e1, a King on f1, a chancellor on h1, and a cArdinal on c1. Black has its pieces on the 8ᵗʰ rank, as opposed to the 1ˢᵗ rank."]
global whiteScoreCHESS
global blackScoreCHESS
whiteScoreCHESS=0
blackScoreCHESS=0
global whiteScoreDEATHMATCH
global blackScoreDEATHMATCH
whiteScoreDEATHMATCH=0
blackScoreDEATHMATCH=0
global whiteScoreCHESS960
global blackScoreCHESS960
whiteScoreCHESS960=0
blackScoreCHESS960=0
global whiteScoreROOKS
global blackScoreROOKS
whiteScoreROOKS=0
blackScoreROOKS=0
global whiteScoreCRAZYHOUSE
global blackScoreCRAZYHOUSE
whiteScoreCRAZYHOUSE=0
blackScoreCRAZYHOUSE=0
global whiteScoreKNIGHTS
global blackScoreKNIGHTS
whiteScoreKNIGHTS=0
blackScoreKNIGHTS=0
global whiteScoreBISHOPS
global blackScoreBISHOPS
whiteScoreBISHOPS=0
blackScoreBISHOPS=0
global whiteScoreQUEENS
global blackScoreQUEENS
whiteScoreQUEENS=0
blackScoreQUEENS=0
global whiteScoreROOKS_CASTLING
global blackScoreROOKS_CASTLING
whiteScoreROOKS_CASTLING=0
blackScoreROOKS_CASTLING=0
global whiteScoreNO_CASTLING
global blackScoreNO_CASTLING
whiteScoreNO_CASTLING=0
blackScoreNO_CASTLING=0
global whiteScoreTHREECHECK
global blackScoreTHREECHECK
whiteScoreTHREECHECK=0
blackScoreTHREECHECK=0
global whiteScoreCHOOSECOMPOUND
global blackScoreCHOOSECOMPOUND
whiteScoreCHOOSECOMPOUND=0
blackScoreCHOOSECOMPOUND=0
global whiteScoreCAPABLANCA
global blackScoreCAPABLANCA
whiteScoreCAPABLANCA=0
blackScoreCAPABLANCA=0
global whiteScoreSHOGI
global blackScoreSHOGI
whiteScoreSHOGI=0
blackScoreSHOGI=0
global SHOGIchecksWhite
global SHOGIchecksBlack
mainMenu()