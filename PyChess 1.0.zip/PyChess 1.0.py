import copy
import random
def arraytonotation(array):
    files=('a','b','c','d','e','f','g','h')
    return files[array[0]]+str(8-array[1])
def notationtoarray(notation):
    return(int(notation[0],base=18)-10,8-int(notation[1]))
def drawboard(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    gameOver=False
    notationlist=('r','R','n','N','b','B','q','Q','k','K','p','P')if playerCase else('R','r','N','n','B','b','Q','q','K','k','P','p')
    piecelist=('♖','♜','♘','♞','♗','♝','♕','♛','♔','♚','♙','♟')
    if game=="CHESS":
        global whiteScoreCHESS
        global blackScoreCHESS
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    whiteScoreCHESS+=2
                    print("White wins by checkmate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                else:
                    blackScoreCHESS+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            else:
                whiteScoreCHESS+=1
                blackScoreCHESS+=1
                print("Draw by stalemate. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCHESS+=1
            blackScoreCHESS+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7):
            print("Check!")
    elif game=="DEATHMATCH":
        global whiteScoreDEATHMATCH
        global blackScoreDEATHMATCH
        if 'r'not in[j for i in board for j in i]and'n'not in[j for i in board for j in i] and'b'not in[j for i in board for j in i] and'q'not in[j for i in board for j in i] and'k'not in[j for i in board for j in i]:
            whiteScoreDEATHMATCH+=2
            print("Black is eliminated. White wins. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif 'R'not in[j for i in board for j in i] and'N'not in[j for i in board for j in i] and'B'not in[j for i in board for j in i] and'Q'not in[j for i in board for j in i] and'K'not in[j for i in board for j in i]:
            blackScoreDEATHMATCH+=2
            print("White is eliminated. Black wins. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif stalemate(blackToMove,list(board),False,4,0,7):
            whiteScoreDEATHMATCH+=1
            blackScoreDEATHMATCH+=1
            print("Draw by stalemate. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
        elif fiftymoves>=100:
            whiteScoreDEATHMATCH+=1
            blackScoreDEATHMATCH+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
            gameOver=True
    elif game=="CHESS960":
        global whiteScoreCHESS960
        global blackScoreCHESS960
        if stalemate(blackToMove,list(board),True,gameparams[0],gameparams[1],gameparams[2]):
            if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2]):
                if blackToMove:
                    whiteScoreCHESS960+=2
                    print("White wins by checkmate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                else:
                    blackScoreCHESS960+=2
                    print("Black wins by checkmate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
            else:
                whiteScoreCHESS960+=1
                blackScoreCHESS960+=1
                print("Draw by stalemate. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
            gameOver=True
        if fiftymoves>=100:
            whiteScoreCHESS960+=1
            blackScoreCHESS960+=1
            print("Draw by fifty-move rule. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
            gameOver=True
        if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2]):
            print("Check!")
    if boardFlip and blackToMove:
        print("  hgfedcba\n  --------")
        for rank in range(7,-1,-1):
            print(str(8-rank)+"|",end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file)%2==0:
                        if ASCIIart:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart:
                            print('#',end="")
                        else:
                            print('■',end="")
                else:
                    if ASCIIart:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print("|"+str(8-rank))
        print("  --------\n  hgfedcba\n")
    else:
        print("  abcdefgh\n  --------")
        for rank in range(8):
            print(str(8-rank)+"|",end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file)%2==0:
                        if ASCIIart:
                            print('.',end="")
                        else:
                            print(' ',end="")
                    else:
                        if ASCIIart:
                            print('#',end="")
                        else:
                            print('■',end="")
                else:
                    if ASCIIart:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print("|"+str(8-rank))
        print("  --------\n  abcdefgh\n")
    if blackToMove:
        print("Black to Move")
    else:
        print("White to Move")
    return gameOver
def makemove(move,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile):
    global error
    global WQcastle
    global WKcastle
    global bqcastle
    global bkcastle
    global eP
    global fiftymoves
    global playerCase
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]==';'):
        if not(move[0].lower()in('r','n','b','q','k','p')or move=="O-O"or move=="O-O-O"):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[5]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')or move=="O-O"or move=="O-O-O"):
            error="Move indexed out of bounds."
            return False
        elif(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not bkcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not wqcastle):
            error="You may not castle right now."
            return False
        elif (move[0].islower()!=blackToMove and not(move=="O-O"or move=="O-O-O")and not enemyMove)or(move[0].islower()==blackToMove and not(move=="O-O"or move=="O-O-O")and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower():
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif not(move=="O-O"or move=="O-O-O")and move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        bkingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            bkingPos=(kingFile,0)
                            return False
                    bkingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        bkingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    bqcastle=False
                    bkcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        bkingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        bkingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            bkingPos=(kingFile,0)
                            return False
                    bkingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        bkingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    bqcastle=False
                    bkcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        bkingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=18)-10][8-int(move[3])]=' '
                    board[int(move[5],base=18)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=18)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=(int(move[2],base=18)-10,(16-int(move[6])-int(move[3]))//2)
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=18)-10][8-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                        boardhistory=[]
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        bqcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        bkcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        bqcastle=False
                        bkcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        bkingPos=notationtoarray(move[5:7])
                    board[int(move[5],base=18)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=18)-10][8-8-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def checkpawn(move,board):
    global eP
    global playerCase
    if move[0]=='p':
        if move[3]!='7':
            if int(move[3])-int(move[6])==2:
                return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])>2 or abs(int(move[2],base=18)-int(move[5],base=18))>1:
            return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==2 and int(move[2],base=18)-int(move[5],base=18)!=0:
            return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==1 and move[2]==move[5]:
            if board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[3])-int(move[6])==1 and abs(int(move[2],base=18)-int(move[5],base=18))==1:
            if board[int(move[5],base=18)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=18)-10][8-int(move[6])].islower():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='7'and int(move[3])-int(move[6])==2 and board[int(move[5],base=18)-10][8-int(move[6])]==' 'and board[int(move[5],base=18)-10][7-int(move[6])]==' ':
            return True
        return"You may not move a "+"P"if playerCase else"p"+" from "+move[2:4]+" to "+move[5:7]+"."
    else:
        if move[3]!='2':
            if int(move[6])-int(move[3])==2:
                return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])>2 or abs(int(move[2],base=18)-int(move[5],base=18))>1:
            return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==2 and int(move[2],base=18)-int(move[5],base=18)!=0:
            return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==1 and move[2]==move[5]:
            if board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[6])-int(move[3])==1 and abs(int(move[2],base=18)-int(move[5],base=18))==1:
            if board[int(move[5],base=18)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=18)-10][8-int(move[6])].isupper():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='2'and int(move[6])-int(move[3])==2 and board[int(move[5],base=18)-10][8-int(move[6])]==' 'and board[int(move[5],base=18)-10][7-int(move[6])]==' ':
            return True
        return"You may not move a "+"p"if playerCase else"P"+" from "+move[2:4]+" to "+move[5:7]+"."
def checkmove(move,checkForCheck,board,enemyMove):
    global playerCase
    if move[0].lower()=='r':
        if move[2]==move[5]:
            if int(move[3])<int(move[6]):
                for i in range(7-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=18)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(8-int(move[3]),8-int(move[6])+1,-1):
                    if board[int(move[2],base=18)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=18)>int(move[5],base=18):
                for i in range(int(move[2],base=18)-11,int(move[5],base=18)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[5],base=18)-9,int(move[2],base=18)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='n':
        if (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='b':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=18)-int(move[5],base=18))or abs(int(move[2],base=18)-int(move[3]))==abs(int(move[5],base=18)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=18)>int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=18)<int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=18)>int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='q':
        if move[2]==move[5]:
            if 8-int(move[3])<8-int(move[6]):
                for i in range(8-int(move[3])+1,8-int(move[6])):
                    if board[int(move[2],base=18)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(8-int(move[3]),8-int(move[6])+1,-1):
                    if board[int(move[2],base=18)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=18)>int(move[5],base=18):
                for i in range(int(move[2],base=18)-11,int(move[5],base=18)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[5],base=18)-9,int(move[2],base=18)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif abs(int(move[3])-int(move[6]))==abs(int(move[2],base=18)-int(move[5],base=18))or abs(int(move[2],base=18)-int(move[3]))==abs(int(move[5],base=18)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=18)>int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=18)<int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=18)>int(move[5],base=18):
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))):
                    if board[int(move[2],base=18)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=18)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='k':
        if abs(int(move[2],base=18)-int(move[5],base=18))>1 or abs(int(move[3])-int(move[6]))>1:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=18)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[2],base=18)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif checkpawn(move,board)!=True:
            return checkpawn(move,board)
    if checkForCheck:
        checkboard=copy.deepcopy(board)
        checkboard[int(move[5],base=18)-10][8-int(move[6])]=move[0]
        checkboard[int(move[2],base=18)-10][8-int(move[3])]=' '
        if check(checkboard,blackToMove,enemyMove,4,0,7):
            return"You may not move into check."
    return True
def check(board,player,enemyMove,kingFile,queenRookFile,kingRookFile):
    if player:
        for rank in range(8):
            for file in range(8):
                if board[file][rank].isupper():
                    if makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(bkingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(bkingPos)+";Q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                        return True
    else:
        for rank in range(8):
            for file in range(8):
                if board[file][rank].islower():
                    if makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos)+";q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                        return True
    return False
def stalemate(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    for rankorigin in range(8):
        for fileorigin in range(8):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(8):
                            if player:
                                if makemove("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                            else:
                                if makemove("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                for rankdest in range(8):
                    for filedest in range(8):
                        if makemove(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            return False
    return True
def CHESS():
    global gameboard
    gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
    global blackToMove
    blackToMove=False
    global WQcastle
    global WKcastle
    global bqcastle
    global bkcastle
    WQcastle=True
    WKcastle=True
    bqcastle=True
    bkcastle=True
    global error
    error=""
    global WKingPos
    global bkingPos
    WKingPos=(4,7)
    bkingPos=(4,0)
    global fiftymoves
    fiftymoves=0
    global eP
    eP=False
    global whiteScoreCHESS
    global blackScoreCHESS
    global playerCase
    while True:
        if drawboard(list(gameboard),"CHESS",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCHESS)
            b=copy.copy(blackScoreCHESS)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCHESS+=2
                    print("White wins by resignation. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                    break
                else:
                    blackScoreCHESS+=2
                    print("Black wins by resignation. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS//2)if whiteScoreCHESS!=1 else"")+("½"if whiteScoreCHESS%2==1 else"")+"-"+(str(blackScoreCHESS//2)if blackScoreCHESS!=1 else"")+("½"if blackScoreCHESS%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                    error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCHESS or b!=blackScoreCHESS:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        CHESS()
    else:
        mainMenu()
def learn():
    input("How to Play CHESS\n\n    The goal of CHESS is to ‘checkmate’ your opponent's King. This is when the King is in ‘check’ and has no legal moves. Check is when your King is under threat of capture. It is illegal to make a move which places your King in check. If you are in check, you must immediately remove the check by doing one of three things:\n 1. Move the King so that it is no longer in check.\n 2. Capture the piece giving check.\n 3. Move a piece inbetween the King and the piece giving check.\nIf it is not possible to do any of these three things, the check is checkmate. Checkmate is not the only way that a game can end, however. A player can resign (Type ‘Resign’), which results in instant victory for the opponent. The game can end in a draw, in which case each player gains ½ of a point. There are four ways for a game to end in a draw. One way that a game can be drawn is by stalemate, which is where a player is not in check but has no legal moves. Another way that a game can be drawn is via the fifty-move rule. This stipulates that if both players go 50 moves without capturing or moving a Pawn, the game ends in a draw. The game can also be drawn is if the same position is repeated three times (This is known as ‘Threefold repetition’, and is not implemented.). The final way a game can end in a draw is a draw by mutual agreement. Unlike resignation, draw offers MUST be accepted by the opposing player. (Type ‘Propose Draw’ or ‘Offer Draw’ to offer a draw.) Additionally, it is illegal to capture your own pieces.\n    Chess is played on an 8×8 board with files (columns) labeled a-h and ranks (rows) labeled 1-8. White starts with Pawns on the 2ⁿᵈ rank (a2, b2, c2, d2, e2, f2, g2, and h2), Rooks on a1 and h1, kNights on b1 and g1, Bishops on c1 and f1, a Queen on d1, and a King on e1. Black has pawns on the 7ᵗʰ rank, Rooks on a8 and h8, kNights on b8 and g8, Bishops on c8 and f8, a Queen on d8, and a King on e8. The Rook moves and captures by sliding any number of spaces directly up, down, left, or right. A Rook can be blocked from moving by another piece in its path. A Bishop moves by sliding any number of spaces diagonally, and is subject to the same movement restrictions as the Rook. The Queen has the combined moves of the Rook and the Bishop. The kNight jumps two spaces in one direction, and one space in another direction 90° away from the first. A kNight jump can only be blocked at the destination, not anywhere inbetween. The King moves one space in any direction. The Pawn moves (but doesn't capture) one space forward. It captures by moving one space diagonally forward. A Pawn that has not moved yet may move two spaces forward, given that the two spaces directly in front of it are empty. A Pawn that has moved two spaces may be captured by an enemy Pawn by capturing to the space the Pawn moved over. This is known as ‘en passant’. Pawns that reach their owner's 8ᵗʰ rank are promoted to another piece of the same color. Players can also make a special move known as ‘castling’, where the King moves two spaces towards one of its Rooks, and the Rook moves to the space that the King passed over. Castling is subject to the following restrictions:\n 1. Neither the King nor the Rook castling may have moved yet this game.\n 2. The King is not in check.\n 3. The King may not castle through check. This means that the space that the King moves over may not be attacked by an opponent's piece.\n 4. The King may not castle into check.\n 5. There may not be any pieces of either player inbetween the King and Rook.\n 6. The Rook castling must be on its owner's 1ˢᵗ rank.\nHow to input moves:\n    A move should be formatted in the following way: ‘{Piece letter (Capitalized letter in the name)} {Origin space}-{Destination space}[;{Pawn promotion}(Only include this if a Pawn is promoting.)]’ White pieces get capital letters, and Black pieces get lowercase letters. En passant does not use special notation; simply move the Pawn as if it were a normal capture. Castling, however, does use special notation. Kingside castling (With the h-file Rook) is written as ‘O-O’, and Queenside castling (With the a-file Rook) is written as ‘O-O-O’\n\nPress Enter to Return to Main Menu.\n")
    mainMenu()
def settings():
    global ASCIIart
    global boardFlip
    global playerCase
    selection=int(input("  SETTINGS\n  --------\n1|Rendering Style (USE FONT TEST!):"+("ASCII"if ASCIIart else"PIECES")+"\n2|Board Flips:"+("ON"if boardFlip else"OFF")+"\n3|Capital Letters Represent:"+("BLACK"if playerCase else"WHITE")+"\n4|Font Test\n5|Return to Main Menu\n"))
    while selection<1 or selection>5:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  SETTINGS\n  --------\n1|ASCII Art:"+("ON"if ASCIIart else"OFF (DEPRECEATED)")+"\n2|Board Flips:"+("ON"if boardFlip else"OFF")+"\n3|Return to Main Menu\n"))
    if selection==1:
        ASCIIart=not ASCIIart
        settings()
    elif selection==2:
        boardFlip=not boardFlip
        settings()
    elif selection==3:
        playerCase=not playerCase
        settings()
    elif selection==4:
        input("♔|\n♕|\n♖|\n♗|\n♘|\n♙|\n♚|\n♛|\n♜|\n♝|\n♞|\n♟|\n■|\n |\nK|\nQ|\nR|\nB|\nN|\nP|\nk|\nq|\nr|\nb|\nn|\np|\n.|\n#|\n\nIf you see one vertical line, your font is compatible with all rendering meathods. If you see two vertical lines, your font is compatible with ASCII rendering only. If you see anything else, your font is not compatible with PyChess.\n\nPress Enter Return to Main Menu.\n")
        settings()
    else:
        mainMenu()
def variantslist():
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        print(str(i+1)+"|"+variantsList[i])
    selection=int(input(str(len(variantsList)+1)+"|Return to Main Menu\n"))
    while selection<1 or selection>len(variantsList)+1:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            print(str(i+1)+"|"+variantsList[i])
        selection=int(input(str(len(variantsList)+1)+"|Return to Main Menu\n"))
    if selection==len(variantsList)+1:
        mainMenu()
    else:
        eval(variantsList[selection-1]+"()")
def learnvariant():
    global variantsList
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        print(str(i+1)+"|"+variantsList[i])
    selection=int(input(str(len(variantsList)+1)+"|Return to Main Menu\n"))
    while selection<1 or selection>len(variantsList)+1:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            print(str(i+1)+"|"+variantsList[i])
        selection=int(input(str(len(variantsList)+1)+"|Return to Main Menu\n"))
    if selection!=len(variantsList)+1:
        input("How to Play "+variantsList[selection-1]+"\n\n"+variantsRules[selection-1]+"\n\nPress Enter to Return to Main Menu.\n")
    mainMenu()
def DEATHMATCH():
    global gameboard
    gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
    global blackToMove
    blackToMove=False
    global WQcastle
    global WKcastle
    global bqcastle
    global bkcastle
    WQcastle=True
    WKcastle=True
    bqcastle=True
    bkcastle=True
    global error
    error=""
    global WKingPos
    global bkingPos
    WKingPos=(4,7)
    bkingPos=(4,0)
    global fiftymoves
    fiftymoves=0
    global eP
    eP=False
    global whiteScoreDEATHMATCH
    global blackScoreDEATHMATCH
    global playerCase
    while True:
        if drawboard(list(gameboard),"DEATHMATCH",[]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreDEATHMATCH)
            b=copy.copy(blackScoreDEATHMATCH)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreDEATHMATCH+=2
                    print("White wins by resignation. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                    break
                else:
                    blackScoreDEATHMATCH+=2
                    print("Black wins by resignation. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreDEATHMATCH+=1
                        blackScoreDEATHMATCH+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreDEATHMATCH+=1
                        blackScoreDEATHMATCH+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreDEATHMATCH//2)if whiteScoreDEATHMATCH!=1 else"")+("½"if whiteScoreDEATHMATCH%2==1 else"")+"-"+(str(blackScoreDEATHMATCH//2)if blackScoreDEATHMATCH!=1 else"")+("½"if blackScoreDEATHMATCH%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                    error=("Bad move format.")
            elif(not playerCase and makemove(move,True,False,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,False,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreDEATHMATCH or b!=blackScoreDEATHMATCH:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        DEATHMATCH()
    else:
        mainMenu()
def CHESS960():
    global gameboard
    while True:
        backrank=['R','N','B','Q','K','B','N','R']
        random.shuffle(backrank)
        if backrank.index('B')%2!="".join(backrank).rindex('B')%2 and backrank.index('R')<backrank.index('K')and backrank.index('K')<"".join(backrank).rindex('R'):
            kingFile=backrank.index('K')
            queenRookFile=backrank.index('R')
            kingRookFile="".join(backrank).rindex('R')
            gameboard=[[backrank[0].lower(),'p',' ',' ',' ',' ','P',backrank[0]],[backrank[1].lower(),'p',' ',' ',' ',' ','P',backrank[1]],[backrank[2].lower(),'p',' ',' ',' ',' ','P',backrank[2]],[backrank[3].lower(),'p',' ',' ',' ',' ','P',backrank[3]],[backrank[4].lower(),'p',' ',' ',' ',' ','P',backrank[4]],[backrank[5].lower(),'p',' ',' ',' ',' ','P',backrank[5]],[backrank[6].lower(),'p',' ',' ',' ',' ','P',backrank[6]],[backrank[7].lower(),'p',' ',' ',' ',' ','P',backrank[7]]]
            break
    global WKingPos
    global bkingPos
    WKingPos=(kingFile,7)
    bkingPos=(kingFile,0)
    global blackToMove
    blackToMove=False
    global WQcastle
    global WKcastle
    global bqcastle
    global bkcastle
    WQcastle=True
    WKcastle=True
    bqcastle=True
    bkcastle=True
    global error
    error=""
    global fiftymoves
    fiftymoves=0
    global eP
    eP=False
    global whiteScoreCHESS960
    global blackScoreCHESS960
    global playerCase
    while True:
        if drawboard(list(gameboard),"CHESS960",[kingFile,queenRookFile,kingRookFile]):
            break
        error=""
        while True:
            w=copy.copy(whiteScoreCHESS960)
            b=copy.copy(blackScoreCHESS960)
            move=input(error)
            if move=="Resign":
                if blackToMove:
                    whiteScoreCHESS960+=2
                    print("White wins by resignation. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                    break
                else:
                    blackScoreCHESS960+=2
                    print("Black wins by resignation. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS960+=1
                        blackScoreCHESS960+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS960+=1
                        blackScoreCHESS960+=1
                        print("Draw by mutual agreement. "+(str(whiteScoreCHESS960//2)if whiteScoreCHESS960!=1 else"")+("½"if whiteScoreCHESS960%2==1 else"")+"-"+(str(blackScoreCHESS960//2)if blackScoreCHESS960!=1 else"")+("½"if blackScoreCHESS960%2==1 else""))
                        break
                    else:
                        error="Black declined a draw."
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                    error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,kingFile,queenRookFile,kingRookFile))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,kingFile,queenRookFile,kingRookFile)):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreCHESS960 or b!=blackScoreCHESS960:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        CHESS960()
    else:
        mainMenu()
def mainMenu():
    selection=int(input("  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n6|QUIT\n"))
    while selection<1 or selection>6:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure game\n3|Play VARIANT\n4|Learn CHESS\n5|Learn VARIANT\n6|QUIT\n"))
    if selection==1:
        CHESS()
    elif selection==2:
        settings()
    elif selection==3:
        variantslist()
    elif selection==4:
        learn()
    elif selection==5:
        learnvariant()
print("  PyChess 1.0")
global ASCIIart
global boardFlip
global playerCase
ASCIIart=True
boardFlip=False
playerCase=False
global variantsList
global variantsRules
variantsList=["DEATHMATCH","CHESS960"]
variantsRules=["    Deathmatch Chess is played exactly the same as standard Chess, but with a different win condition. The objective of deathmatch chess is not to checkmate your opponent's King, but to capture all of your opponent's pieces, with the exception of pawns.","    Chess960 is played exactly like standard Chess, but with a random starting position of the back rank. Starting positions are subject to three restrictions:\n 1. Both bishops may not reside on the same color square.\n 2. The King must be between the two Rooks.\n 3. White and Black must have mirrored starting positions. When castling, both King and Rook move to the spaces that the do in standard Chess. (King to c-file and Rook to d-file for Queenside castling, and King to g-file and Rook to f-file for Kingside castling.)"]
global whiteScoreCHESS
global blackScoreCHESS
whiteScoreCHESS=0
blackScoreCHESS=0
global whiteScoreDEATHMATCH
global blackScoreDEATHMATCH
whiteScoreDEATHMATCH=0
blackScoreDEATHMATCH=0
global whiteScoreCHESS960
global blackScoreCHESS960
whiteScoreCHESS960=0
blackScoreCHESS960=0
mainMenu()