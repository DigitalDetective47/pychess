global filesystem
global browser_ext
import copy
import random
import math
try:
    import webbrowser
    browser_ext=True
except NotImplementedError:
    browser_ext=False
try:
    import os
    filesystem=os.path.dirname(__file__)
except NotImplementedError:
    filesystem=None
    print("This copy of PyChess is not a full copy. Some features such as the User's Guide and Settings saving may not be available.")
def clearscreen():
    global screenClears
    if screenClears:
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
def savegame(variant,*params):
    global gameboard
    global blackToMove
    global fiftymoves
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    board=""
    for i in gameboard:
        board+=','.join(i)+';'
    board=board[:-1]
    file=variant+"~"+board+"~"+('B'if blackToMove else'W')+"~"+str(fiftymoves)+"~"+hex((1 if WQcastle else 0)+(2 if WKcastle else 0)+(4 if BQcastle else 0)+(8 if BKcastle else 0))[2:]+"~"+(str(eP[0])+','+str(eP[1])if eP!=False else"X")+("~"+params[0]if len(params)==1 else"")
    if filesystem==None:
        print("Here is your save string:\n"+file)
    else:
        selection=""
        while selection!="Y"and selection!="N":
            selection=input("Would you like to save this game to a file? ('Y' or 'N')\n"if ASCIIart==0 else"Would you like to save this game to a file? (‘Y’ or ‘N’)\n")
        if selection=="N":
            print("Here is your save string:\n"+file)
        else:
            fileSaved=False
            while not fileSaved:
                selection=input("Please name this file. Press enter to cancel the save operation.")
                if selection=="":
                    fileSaved=True
                else:
                    try:
                        open("saves/"+selection+".sav","x")
                        f=open("saves/"+selection+".sav","w")
                        f.write(file)
                        f.close()
                        fileSaved=True
                    except FileExistsError:
                        f=""
                        while f!="Y"and f!="N":
                            f=input("There's already a saved game named "+selection+". Would you like to overwrite it? ('Y' or 'N')\n"if ASCIIart==0 else"There's already a saved game named "+selection+". Would you like to overwrite it? (‘Y’ or ‘N’)\n")
                        if f=="Y":
                            f=open("saves/"+selection+".sav","w")
                            f.write(file)
                            fileSaved=True
    blackToMove=not blackToMove
    input("\nPress enter to return to the game.")
def loadgame():
    if filesystem==None:
        savedgame=input("Enter the saved game here: ")
    else:
        savefilelist=sorted(os.listdir("./saves"))
        if savefilelist==[]:
            savedgame=input("Enter the saved game here: ")
        else:
            for i in savefilelist:
                if i[-4:]==".sav":
                    i=i[:-4]
                else:
                    del i
            print("  CHOOSE A SAVE FILE\n  ------------------\n")
            for i in range(len(savefilelist)):
                print(str(i+1)+"|"+savefilelist[i])
            print(str(len(savefilelist))+"|Load Game From String")
            selection=int(input(""))
            while selection<1 or selection>len(savefilelist):
                print("Option "+str(selection)+"does not exist.\n\n  CHOOSE A SAVE FILE\n  ------------------\n")
                for i in range(len(savefilelist)):
                    print(str(i+1)+"|"+savefilelist[i])
                print(str(len(savefilelist))+"|Load Game From String")
                selection=int(input(""))
            if selection==len(savefilelist):
                savedgame=input("Enter the saved game here: ")
            else:
                with open("saves/"+savefilelist[selection-1])as f:
                    savedgame=f.read()
    gamesplit=savedgame.split('~')
    global gameboard
    if gamesplit[0]=="SANDBOX":
        gameboard=list(map(lambda x:x.split(','),gamesplit[1].split(';')))
        SANDBOX(False)
    else:
        global blackToMove
        global fiftymoves
        global WQcastle
        global WKcastle
        global BQcastle
        global BKcastle
        global eP
        global WKingPos
        global BKingPos
        blackToMove=gamesplit[2]=='B'
        fiftymoves=int(gamesplit[3])
        WQcastle=int(gamesplit[4],base=16)%2==1
        WKcastle=int(gamesplit[4],base=16)%4//2==1
        BQcastle=int(gamesplit[4],base=16)%8//4==1
        BKcastle=int(gamesplit[4],base=16)//8==1
        gameboard=gamesplit[1].split(';')
        WKingPos=(4,7)
        BKingPos=(4,0)
        for i in range(len(gameboard)):
            gameboard[i]=gameboard[i].split(',')
            if('Z'if gamesplit[0]=="MAHARAJA_SEPOYS"else('N'if gamesplit[0]=="KNIGHTMATE"else'K'))in gameboard[i]:
                WKingPos=(i,gameboard[i].index('Z'if gamesplit[0]=="MAHARAJA_SEPOYS"else('N'if gamesplit[0]=="KNIGHTMATE"else'K')))
            if('n'if gamesplit[0]=="KNIGHTMATE"else'k')in gameboard[i]:
                BKingPos=(i,gameboard[i].index(('n'if gamesplit[0]=="KNIGHTMATE"else'k')))
        eP=(False if gamesplit[5]=='X'else[int(gamesplit[5].split(',')[0]),int(gamesplit[5].split(',')[1])])
        eval(gamesplit[0]+('("'+savedgame.split('~',6)[6]+'")'if len(gamesplit)>6 else"(False)"))
def multireplace(text,replacements):
    string=str(text)
    for i,j in replacements.items():
        string=string.replace(i,j)
    return string
def arraytonotation(array):
    global gameboard
    return chr(array[0]+97)+str(len(gameboard[0])-array[1])
def notationtoarray(notation):
    return[int(notation[0],base=20)-10,len(gameboard[0])-int(notation[1])]
def arraytonotationSHOGI(array):
    return str(array[0]+1)+chr(105-array[1])
def notationtoarraySHOGI(notation):
    return[int(notation[0])-1,18-int(notation[1],base=19)]
def drawboard(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    global invertBoard
    clearscreen()
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','M','m','A','a','K','k','P','p','Z','z')
    piecelist=((('♜','♖','♞','♘','♝','♗','♛','♕','ｍ','Ｍ','ａ','Ａ','♚','♔','♟','♙','ｚ','Ｚ')if playerCase else('♜','♖','♞','♘','♝','♗','♛','♕','Ｍ','ｍ','Ａ','ａ','♚','♔','♟','♙','Ｚ','ｚ'))if darkMode else(('♖','♜','♘','♞','♗','♝','♕','♛','ｍ','Ｍ','ａ','Ａ','♔','♚','♙','♟','ｚ','Ｚ')if playerCase else('♖','♜','♘','♞','♗','♝','♕','♛','Ｍ','ｍ','Ａ','ａ','♔','♚','♙','♟','Ｚ','ｚ')))
    if game=="CHESS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="DEATHMATCH":
        if'r'not in[j for i in board for j in i]and'n'not in[j for i in board for j in i]and'b'not in[j for i in board for j in i]and'q'not in[j for i in board for j in i]and'k'not in[j for i in board for j in i]:
            print("Black is eliminated. White wins. 1‐0"if ASCIIart==2 else"Black is eliminated. White wins. 1-0")
            gameOver=True
        elif'R'not in[j for i in board for j in i]and'N'not in[j for i in board for j in i]and'B'not in[j for i in board for j in i]and'Q'not in[j for i in board for j in i]and'K'not in[j for i in board for j in i]:
            print("White is eliminated. Black wins. 0‐1"if ASCIIart==2 else"White is eliminated. Black wins. 0-1")
            gameOver=True
        elif stalemate(blackToMove,list(board),False,4,0,7):
            print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        elif fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
    elif game=="CHESS960":
        if stalemate(blackToMove,list(board),True,gameparams[0],gameparams[1],gameparams[2]):
            if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2]):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,gameparams[0],gameparams[1],gameparams[2])and not gameOver:
            print("Check!")
    elif game=="ROOKS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="KNIGHTS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="BISHOPS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="QUEENS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="ROOKS_CASTLING":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="NO_CASTLING":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="THREECHECK":
        global whiteCheckCount
        global blackCheckCount
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            if blackToMove and blackCheckCount>=2:
                print("White wins by triple check. 1‐0"if ASCIIart==2 else"White wins by triple check. 1-0")
                blackCheckCount+=1
                gameover=True
            elif not blackToMove and whiteCheckCount>=2:
                print("Black wins by triple check. 0‐1"if ASCIIart==2 else"White wins by triple check. 0-1")
                whiteCheckCount+=1
            else:
                print("Check!")
                if(blackToMove):
                    blackCheckCount+=1
                else:
                    whiteCheckCount+=1
    elif game=="CHOSECOMPOUND":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="KING_OF_THE_HILL":
        global WKingPos
        global BKingPos
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if WKingPos in[(3,3),(3,4),(4,3),(4,4)]:
            print("White wins by central King. 1‐0"if ASCIIart==2 else"White wins by central King. 1-0")
            gameOver=True
        if BKingPos in[(3,3),(3,4),(4,3),(4,4)]:
            print("Black wins by central King. 0‐1"if ASCIIart==2 else"Black wins by central King. 0-1")
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="ANTICHESS":
        if'p'not in[j for i in board for j in i]and'r'not in[j for i in board for j in i]and'n'not in[j for i in board for j in i]and'b'not in[j for i in board for j in i]and'q'not in[j for i in board for j in i]and'k'not in[j for i in board for j in i]:
            print("Black is eliminated. Black wins. 0‐1"if ASCIIart==2 else"Black is eliminated. Black wins. 0-1")
            gameOver=True
        elif'P'not in[j for i in board for j in i]and'R'not in[j for i in board for j in i] and'N'not in[j for i in board for j in i]and'B'not in[j for i in board for j in i]and'Q'not in[j for i in board for j in i]and'K'not in[j for i in board for j in i]:
            print("White is eliminated. White wins. 1‐0"if ASCIIart==2 else"White is eliminated. White wins. 1-0")
            gameOver=True
        elif stalemateanti(blackToMove,list(board),False,4,0,7):
            if blackToMove:
                print("Black wins by stalemate. 0‐1"if ASCIIart==2 else"Black wins by stalemate. 0-1")
            else:
                print("White wins by stalemate. 1‐0"if ASCIIart==2 else"White wins by stalemate. 1-0")
            gameOver=True
        elif fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
    elif game=="MAHARAJA_SEPOYS":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="KNIGHTMATE":
        if stalemate(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    elif game=="MYSTERYROYAL":
        if board[WKingPos[0]][WKingPos[1]].islower():
            print("White's royal has been captured. Black wins. 0‐1"if ASCIIart==2 else"White's royal has been captured. Black wins. 0-1")
            gameOver=True
        elif board[BKingPos[0]][BKingPos[1]].isupper():
            print("Black's royal has been captured. White wins. 1‐0"if ASCIIart==2 else"Black's royal has been captured. White wins. 1-0")
            gameOver=True
        elif stalemate(blackToMove,list(board),False,4,0,7):
            print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
    if boardFlip and blackToMove:
        if game=="THREECHECK":
            for i in range(blackCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("\n\n")
        print("  hgfedcba\n  --------"if ASCIIart==0 else"　　ｈｇｆｅｄｃｂａ\n　　－－－－－－－－")
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  hgfedcba"if ASCIIart==0 else"　　－－－－－－－－\n　　ｈｇｆｅｄｃｂａ")
        if game=="THREECHECK":
            print("\n")
            for i in range(whiteCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("")
    else:
        if game=="THREECHECK":
            for i in range(whiteCheckCount):
                print("+"if ASCIIare else"＋",end="")
            print("\n\n")
        print("  abcdefgh\n  --------"if ASCIIart==0 else"　　ａｂｃｄｅｆｇｈ\n　　－－－－－－－－")
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  abcdefgh\n"if ASCIIart==0 else"　　－－－－－－－－\n　　ａｂｃｄｅｆｇｈ\n")
        if game=="THREECHECK":
            print("\n")
            for i in range(blackCheckCount):
                print("+"if ASCIIart==0 else"＋",end="")
            print("")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboardCRAZYHOUSE(board,whiteHold,blackHold):
    global ASCIIart
    global boardFlip
    global playerCase
    global darkMode
    global invertBoard
    clearscreen()
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','K','k','P','p')
    piecelist=(('♜','♖','♞','♘','♝','♗','♛','♕','♚','♔','♟','♙')if darkMode else('♖','♜','♘','♞','♗','♝','♕','♛','♔','♚','♙','♟'))
    if stalemateCRAZYHOUSE(blackToMove,list(board),True,4,0,7,whiteHold,blackHold):
        if check(list(board),blackToMove,False,4,0,7):
            if blackToMove:
                print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
            else:
                print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
        else:
            print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
        gameOver=True
    if fiftymoves>=100:
        print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
        gameOver=True
    if check(list(board),blackToMove,False,4,0,7)and not gameOver:
        print("Check!")
    if boardFlip and blackToMove:
        print((("  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------")if playerCase else("  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------"))if ASCIIart==0 else("　　－－－－－\n　｜"+("♟♜♞♝♛"if darkMode else"♙♖♘♗♕")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),whiteHold)))+"｜\n　　－－－－－\n\n　　ｈｇｆｅｄｃｂａ\n　　－－－－－－－－"))
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  hgfedcba\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----")if playerCase else("  --------\n  hgfedcba\n\n  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----"))if ASCIIart==0 else("　　－－－－－－－－\n　　ｈｇｆｅｄｃｂａ\n\n　　－－－－－\n　｜"+("♙♖♘♗♕"if darkMode else"♟♜♞♝♛")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),blackHold)))+"｜\n　　－－－－－"))
    else:
        print((("  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------")if playerCase else("  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------"))if ASCIIart==0 else("　　－－－－－\n　｜"+("♙♖♘♗♕"if darkMode else"♟♜♞♝♛")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),blackHold)))+"｜\n　　－－－－－\n\n　　ａｂｃｄｅｆｇｈ\n　　－－－－－－－－"))
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  abcdefgh\n\n  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----")if playerCase else("  --------\n  abcdefgh\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----"))if ASCIIart==0 else("　　－－－－－－－－\n　　ａｂｃｄｅｆｇｈ\n\n　　－－－－－\n　｜"+("♟♜♞♝♛"if darkMode else"♙♖♘♗♕")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),whiteHold)))+"｜\n　　－－－－－"))
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboard10x8(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    global darkMode
    global invertBoard
    clearscreen()
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','M','m','A','a','K','k','P','p')
    piecelist=((('♜','♖','♞','♘','♝','♗','♛','♕','ｍ','Ｍ','ａ','Ａ','♚','♔','♟','♙')if playerCase else('♜','♖','♞','♘','♝','♗','♛','♕','Ｍ','ｍ','Ａ','ａ','♚','♔','♟','♙'))if darkMode else(('♖','♜','♘','♞','♗','♝','♕','♛','ｍ','Ｍ','ａ','Ａ','♔','♚','♙','♟')if playerCase else('♖','♜','♘','♞','♗','♝','♕','♛','Ｍ','ｍ','Ａ','ａ','♔','♚','♙','♟')))
    if game=="CAPABLANCA":
        if stalemate10x8(blackToMove,list(board),True,4,0,7):
            if check10x8(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check10x8(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    if boardFlip and blackToMove:
        print("  jihgfedcba\n  ----------"if ASCIIart==0 else"　　ｊｉｈｇｆｅｄｃｂａ\n　　－－－－－－－－－－")
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(9,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  ----------\n  jihgfedcba"if ASCIIart==0 else"　　－－－－－－－－－－\n　　ｊｉｈｇｆｅｄｃｂａ")
    else:
        print("  abcdefghij\n  ----------"if ASCIIart==0 else"　　ａｂｃｄｅｆｇｈｉｊ\n　　－－－－－－－－－－")
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(10):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  ----------\n  abcdefghij"if ASCIIart==0 else"　　－－－－－－－－－－\n　　ａｂｃｄｅｆｇｈｉｊ")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboardSHOGI():
    global blackToMove
    global SHOGIchecksWhite
    global SHOGIchecksBlack
    global gameboard
    global ASCIIart
    global playerCase
    global boardFlip
    global darkMode
    global invertBoard
    global SHOGIkanji
    global WKingPos
    global BKingPos
    global whiteHold
    global blackHold
    clearscreen()
    gameOver=False
    notationlist=('K','k','R','r','D','d','B','b','H','h','G','g','S','s','E','e','N','n','C','c','L','l','I','i','P','p','T','t')
    piecelist=(('ｋ','王','ｒ','飛','ｄ','龍','ｂ','角','ｈ','馬','ｇ','金','ｓ','銀','ｅ','全','ｎ','桂','ｃ','圭','ｌ','香','ｉ','杏','ｐ','歩','ｔ','と')if playerCase else('王','ｋ','飛','ｒ','龍','ｄ','角','ｂ','馬','ｈ','金','ｇ','銀','ｓ','全','ｅ','桂','ｎ','圭','ｃ','香','ｌ','杏','ｉ','歩','ｐ','と','ｔ')if SHOGIkanji else('ｋ','Ｋ','ｒ','Ｒ','ｄ','Ｄ','ｂ','Ｂ','ｈ','Ｈ','ｇ','Ｇ','ｓ','Ｓ','ｅ','Ｅ','ｎ','Ｎ','ｃ','Ｃ','ｌ','Ｌ','ｉ','Ｉ','ｐ','Ｐ','ｔ','Ｔ')if playerCase else('Ｋ','ｋ','Ｒ','ｒ','Ｄ','ｄ','Ｂ','ｂ','Ｈ','ｈ','Ｇ','ｇ','Ｓ','ｓ','Ｅ','ｅ','Ｎ','ｎ','Ｃ','ｃ','Ｌ','ｌ','Ｉ','ｉ','Ｐ','ｐ','Ｔ','ｔ'))
    if stalemateSHOGI(blackToMove,list(gameboard),True,whiteHold,blackHold):
        if checkSHOGI(list(gameboard),blackToMove,(BKingPos if blackToMove else WKingPos),False):
            if blackToMove:
                print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
            else:
                print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
        else:
            if blackToMove:
                print("White wins by stalemate. 1‐0"if ASCIIart==2 else"White wins by stalemate. 1-0")
            else:
                print("Black wins by stalemate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
        gameOver=True
    elif checkSHOGI(list(gameboard),blackToMove,(BKingPos if blackToMove else WKingPos),False)and not gameOver:
        print("Check!")
        if blackToMove:
            SHOGIchecksBlack+=1
        else:
            SHOGIchecksWhite+=1
    else:
        if blackToMove:
            SHOGIchecksWhite=0
        else:
            SHOGIchecksBlack=0
    if boardFlip and not blackToMove:
        if SHOGIchecksBlack>0:
            for i in range(SHOGIchecksBlack):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
        if len(blackHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"　　－\n　｜　｜\n　　－\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
                print("\n |"+"".join(blackHold)+"|\n  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
            else:
                print("　　",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
                print("\n　｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n　　",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
            print("\n")
        print("  123456789\n  ---------"if ASCIIart==0 else"　　１２３４５６７８９\n　　－－－－－－－－－")
        for rank in range(9):
            print((chr((105 if ASCIIart==0 else 65353)-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(9):
                if gameboard[file][rank]==' ':
                    print(('.'if ASCIIart==0 else'．')if darkMode^invertBoard else('#'if ASCIIart==0 else'＃'),end="")
                else:
                    if ASCIIart==0:
                        print(gameboard[file][rank].swapcase()if playerCase else gameboard[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(gameboard[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(chr((105 if ASCIIart==0 else 65353)-rank)))
        print("  ---------\n  123456789\n"if ASCIIart==0 else"　　－－－－－－－－－\n　　１２３４５６７８９\n")
        if len(whiteHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"　　－\n　｜　｜\n　　－\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
                print("\n |"+"".join(whiteHold)+"|\n  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
            else:
                print("　　",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
                print("\n　｜",end="")
                for i in whiteHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n　　",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
            print("\n")
        if SHOGIchecksWhite>0:
            for i in range(SHOGIchecksWhite):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
    else:
        if SHOGIchecksWhite>0:
            for i in range(SHOGIchecksWhite):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
        if len(whiteHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"　　－\n　｜　｜\n　　－\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
                print("\n |"+"".join(whiteHold)+"|\n  ",end="")
                for i in range(len(whiteHold)):
                    print("-",end="")
            else:
                print("　　",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
                print("\n　｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n　　",end="")
                for i in range(len(whiteHold)):
                    print("－",end="")
            print("\n")
        print("  987654321\n  ---------"if ASCIIart==0 else"　　９８７６５４３２１\n　　－－－－－－－－－")
        for rank in range(8,-1,-1):
            print((chr((105 if ASCIIart==0 else 65353)-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8,-1,-1):
                if gameboard[file][rank]==' ':
                    print(('.'if ASCIIart==0 else'．')if darkMode^invertBoard else('#'if ASCIIart==0 else'＃'),end="")
                else:
                    if ASCIIart==0:
                        print(gameboard[file][rank].swapcase()if playerCase else gameboard[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(gameboard[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(chr((105 if ASCIIart==0 else 65353)-rank)))
        print("  ---------\n  987654321\n"if ASCIIart==0 else"　　－－－－－－－－－\n　　９８７６５４３２１\n")
        if len(blackHold)==0:
            print("  -\n | |\n  -\n"if ASCIIart==0 else"　　－\n　｜　｜\n　　－\n")
        else:
            if ASCIIart==0:
                print("  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
                print("\n |"+"".join(blackHold)+"|\n  ",end="")
                for i in range(len(blackHold)):
                    print("-",end="")
            else:
                print("　　",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
                print("\n　｜",end="")
                for i in blackHold:
                    print(piecelist[notationlist.index(i)],end="")
                print("｜\n　　",end="")
                for i in range(len(blackHold)):
                    print("－",end="")
            print("\n")
        if SHOGIchecksBlack>0:
            for i in range(SHOGIchecksBlack):
                print('+'if ASCIIart==0 else'＋',end="")
            print("\n")
    if blackToMove:
        print("Black to Move")
    else:
        print("White to Move")
    return gameOver
def drawboardLOSALAMOS():
    global ASCIIart
    global boardFlip
    global playerCase
    global gameboard
    global invertBoard
    clearscreen()
    board=gameboard
    gameOver=False
    notationlist=('R','r','N','n','Q','q','K','k','P','p')
    piecelist=(('♜','♖','♞','♘','♛','♕','♚','♔','♟','♙')if darkMode else('♖','♜','♘','♞','♕','♛','♔','♚','♙','♟'))
    if stalemate6(blackToMove,list(board),True,4,0,7):
        if check6(list(board),blackToMove,False,4,0,7):
            if blackToMove:
                print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
            else:
                print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
        else:
            print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
        gameOver=True
    if fiftymoves>=100:
        print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
        gameOver=True
    if check6(list(board),blackToMove,False,4,0,7)and not gameOver:
        print("Check!")
    if boardFlip and blackToMove:
        print("  fedcba\n  ------"if ASCIIart==0 else"　　ｆｅｄｃｂａ\n　　－－－－－－")
        for rank in range(5,-1,-1):
            print((str(6-rank)if ASCIIart==0 else chr(65302-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(5,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(6-rank)if ASCIIart==0 else chr(65302-rank)))
        print("  ------\n  fedcba"if ASCIIart==0 else"　　－－－－－－\n　　ｆｅｄｃｂａ")
    else:
        print("  abcdef\n  ------"if ASCIIart==0 else"　　ａｂｃｄｅｆ\n　　－－－－－－")
        for rank in range(6):
            print((str(6-rank)if ASCIIart==0 else chr(65302-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(6):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(6-rank)if ASCIIart==0 else chr(65302-rank)))
        print("  ------\n  abcdef\n"if ASCIIart==0 else"　　－－－－－－\n　　ａｂｃｄｅｆ\n")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboarddarkcontrol(board,game,gameparams):
    global ASCIIart
    global boardFlip
    global playerCase
    global invertBoard
    global controlledSpaces
    clearscreen()
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','M','m','A','a','K','k','P','p','Z','z')
    piecelist=((('♜','♖','♞','♘','♝','♗','♛','♕','ｍ','Ｍ','ａ','Ａ','♚','♔','♟','♙','ｚ','Ｚ')if playerCase else('♜','♖','♞','♘','♝','♗','♛','♕','Ｍ','ｍ','Ａ','ａ','♚','♔','♟','♙','Ｚ','ｚ'))if darkMode else(('♖','♜','♘','♞','♗','♝','♕','♛','ｍ','Ｍ','ａ','Ａ','♔','♚','♙','♟','ｚ','Ｚ')if playerCase else('♖','♜','♘','♞','♗','♝','♕','♛','Ｍ','ｍ','Ａ','ａ','♔','♚','♙','♟','Ｚ','ｚ')))
    print(("Black's turn…\nWhite, please do not view the screen at this time."if blackToMove else"White's turn…\nBlack, please do not view the screen at this time.").replace('…',"..."if ASCIIart==0 else'…'))
    input("")
    clearscreen()
    if game=="DARKCHESS":
        if stalematedarkcontrol(blackToMove,list(board),True,4,0,7):
            if check(list(board),blackToMove,False,4,0,7):
                if blackToMove:
                    print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
                else:
                    print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
            else:
                print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
            gameOver=True
        if fiftymoves>=100:
            print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
            gameOver=True
        if check(list(board),blackToMove,False,4,0,7)and not gameOver:
            print("Check!")
    if boardFlip and blackToMove:
        print("  hgfedcba\n  --------"if ASCIIart==0 else"　　ｈｇｆｅｄｃｂａ\n　　－－－－－－－－")
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if[file,rank]in controlledSpaces or(board[file][rank].islower()and blackToMove)or(board[file][rank].isupper()and not blackToMove):
                    if board[file][rank]==' ':
                        if(rank+file+darkMode+invertBoard)%2==0:
                            if ASCIIart==0:
                                print('.',end="")
                            else:
                                print('．',end="")
                        else:
                            if ASCIIart==0:
                                print('#',end="")
                            else:
                                print('＃',end="")
                    else:
                        if ASCIIart==0:
                            print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                        else:
                            print(piecelist[notationlist.index(board[file][rank])],end="")
                else:
                    print('?'if ASCIIart==0 else'？',end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  hgfedcba"if ASCIIart==0 else"　　－－－－－－－－\n　　ｈｇｆｅｄｃｂａ")
    else:
        print("  abcdefgh\n  --------"if ASCIIart==0 else"　　ａｂｃｄｅｆｇｈ\n　　－－－－－－－－")
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if[file,rank]in controlledSpaces or(board[file][rank].islower()and blackToMove)or(board[file][rank].isupper()and not blackToMove):
                    if board[file][rank]==' ':
                        if(rank+file+darkMode+invertBoard)%2==0:
                            if ASCIIart==0:
                                print('.',end="")
                            else:
                                print('．',end="")
                        else:
                            if ASCIIart==0:
                                print('#',end="")
                            else:
                                print('＃',end="")
                    else:
                        if ASCIIart==0:
                            print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                        else:
                            print(piecelist[notationlist.index(board[file][rank])],end="")
                else:
                    print('?'if ASCIIart==0 else'？',end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print("  --------\n  abcdefgh\n"if ASCIIart==0 else"　　－－－－－－－－\n　　ａｂｃｄｅｆｇｈ\n")
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def drawboardSANDBOX():
    global gameboard
    clearscreen()
    print("  ",end="")
    for i in list(map(lambda x:chr(x+97),range(len(gameboard)))):
        print(i,end="")
    print("\n  ",end="")
    for i in range(len(gameboard)):
        print("-",end="")
    print("")
    for rank in range(len(gameboard[0])):
        print(str(len(gameboard[0])-rank)+"|",end="")
        for file in range(len(gameboard)):
            if gameboard[file][rank]==' ':
                if(rank+file+len(gameboard[0])+darkMode+invertBoard)%2==0:
                    print('.',end="")
                else:
                    print('#',end="")
            else:
                print(gameboard[file][rank],end="")
        print("|"+(str(len(gameboard[0])-rank)))
    print("  ",end="")
    for i in range(len(gameboard)):
        print("-",end="")
    print("\n  ",end="")
    for i in list(map(lambda x:chr(x+97),range(len(gameboard)))):
        print(i,end="")
    print("")
def drawboardHOLD(board,whiteHold,blackHold):
    global ASCIIart
    global boardFlip
    global playerCase
    global darkMode
    global invertBoard
    clearscreen()
    gameOver=False
    notationlist=('R','r','N','n','B','b','Q','q','K','k','P','p')
    piecelist=(('♜','♖','♞','♘','♝','♗','♛','♕','♚','♔','♟','♙')if darkMode else('♖','♜','♘','♞','♗','♝','♕','♛','♔','♚','♙','♟'))
    if stalemate(blackToMove,list(board),True,4,0,7):
        if check(list(board),blackToMove,False,4,0,7):
            if blackToMove:
                print("White wins by checkmate. 1‐0"if ASCIIart==2 else"White wins by checkmate. 1-0")
            else:
                print("Black wins by checkmate. 0‐1"if ASCIIart==2 else"Black wins by checkmate. 0-1")
        else:
            print("Draw by stalemate. ½‐½"if ASCIIart==2 else("Draw by stalemate. ½-½"if ASCIIart==1 else"Draw by stalemate. 1/2-1/2"))
        gameOver=True
    if fiftymoves>=100:
        print("Draw by fifty‐move rule. ½‐½"if ASCIIart==2 else("Draw by fifty-move rule. ½-½"if ASCIIart==1 else"Draw by fifty-move rule. 1/2-1/2"))
        gameOver=True
    if check(list(board),blackToMove,False,4,0,7)and not gameOver:
        print("Check!")
    if boardFlip and blackToMove:
        print((("  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------")if playerCase else("  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----\n\n  hgfedcba\n  --------"))if ASCIIart==0 else("　　－－－－－\n　｜"+("♟♜♞♝♛"if darkMode else"♙♖♘♗♕")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),whiteHold)))+"｜\n　　－－－－－\n\n　　ｈｇｆｅｄｃｂａ\n　　－－－－－－－－"))
        for rank in range(7,-1,-1):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(7,-1,-1):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  hgfedcba\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----")if playerCase else("  --------\n  hgfedcba\n\n  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----"))if ASCIIart==0 else("　　－－－－－－－－\n　　ｈｇｆｅｄｃｂａ\n\n　　－－－－－\n　｜"+("♙♖♘♗♕"if darkMode else"♟♜♞♝♛")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),blackHold)))+"｜\n　　－－－－－"))
    else:
        print((("  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------")if playerCase else("  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"|\n  -----\n\n  abcdefgh\n  --------"))if ASCIIart==0 else("　　－－－－－\n　｜"+("♙♖♘♗♕"if darkMode else"♟♜♞♝♛")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),blackHold)))+"｜\n　　－－－－－\n\n　　ａｂｃｄｅｆｇｈ\n　　－－－－－－－－"))
        for rank in range(8):
            print((str(8-rank)if ASCIIart==0 else chr(65304-rank))+("|"if ASCIIart==0 else"｜"),end="")
            for file in range(8):
                if board[file][rank]==' ':
                    if(rank+file+darkMode+invertBoard)%2==0:
                        if ASCIIart==0:
                            print('.',end="")
                        else:
                            print('．',end="")
                    else:
                        if ASCIIart==0:
                            print('#',end="")
                        else:
                            print('＃',end="")
                else:
                    if ASCIIart==0:
                        print(board[file][rank].swapcase()if playerCase else board[file][rank],end="")
                    else:
                        print(piecelist[notationlist.index(board[file][rank])],end="")
            print(("|"if ASCIIart==0 else"｜")+(str(8-rank)if ASCIIart==0 else chr(65304-rank)))
        print((("  --------\n  abcdefgh\n\n  -----\n |prnbq|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----")if playerCase else("  --------\n  abcdefgh\n\n  -----\n |PRNBQ|\n |"+"".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"|\n  -----"))if ASCIIart==0 else("　　－－－－－－－－\n　　ａｂｃｄｅｆｇｈ\n\n　　－－－－－\n　｜"+("♟♜♞♝♛"if darkMode else"♙♖♘♗♕")+"｜\n　｜"+"".join(list(map(lambda x:chr((65296 if x<10 else 65303)+x),whiteHold)))+"｜\n　　－－－－－"))
    if blackToMove:
        print("\nBlack to Move")
    else:
        print("\nWhite to Move")
    return gameOver
def makemove(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,**keys):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'Ｍ':'M',
        'Ａ':'A',
        'Ｚ':'Z',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'ｍ':'m',
        'ａ':'a',
        'ｚ':'z'
    })if playerCase else({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'ｍ':'m',
        'ａ':'a',
        'ｚ':'z',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'Ｍ':'M',
        'Ａ':'A',
        'Ｚ':'Z'
    })if darkMode else({
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'ｍ':'m',
        'ａ':'a',
        'ｚ':'z',
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'Ｍ':'M',
        'Ａ':'A',
        'Ｚ':'Z'
    })if playerCase else({
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'Ｍ':'M',
        'Ａ':'A',
        'Ｚ':'Z',
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'ｍ':'m',
        'ａ':'a',
        'ｚ':'z'
    }))
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]=='='):
        if(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not WQcastle):
            error="You may not castle right now."
            return False
        elif move=="O-O"or move=="O-O-O":
            ""
        elif not(move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"])or move=="O-O"or move=="O-O-O"or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"])and move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[5]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')):
            error="Move indexed out of bounds."
            return False
        elif(move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif(move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower())or not(move[0].islower()==board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=[int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2]
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if tuple(notationtoarray(move[2:4]))==WKingPos:
                        WKingPos=tuple(notationtoarray(move[5:7]))
                    elif tuple(notationtoarray(move[2:4]))==BKingPos:
                        BKingPos=tuple(notationtoarray(move[5:7]))
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemoveCRAZYHOUSE(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold,**keys):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global promotions
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p'
    })if darkMode^playerCase else({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P'
    }))
    if len(move)==4 and move[1]=='@':
        if not move[0].lower()in('r','n','b','q','k','p'):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')):
            error="Move indexed out of bounds."
            return False
        elif board[int(move[2],base=20)-10][8-int(move[3])]!=' ':
            error="You may not drop pieces onto occupied spaces."
            return False
        elif move[0].islower()!=blackToMove:
            error="You may not drop your opponent's pieces."
            return False
        elif(blackToMove and blackHold["prnbq".index(move[0])]==0)or(not blackToMove and whiteHold["PRNBQ".index(move[0])]==0):
            error="You do not have any "+(move[0].swapcase()if playerCase else move[0])+"s to drop."
            return False
        elif move[0].lower()=='p'and(move[3]=='1'or move[3]=='8'):
            error="You may not drop pawns on the 1ˢᵗ or 8ᵗʰ rank."if ASCIIart==2 else"You may not drop pawns on the 1st or 8th rank."
            return False
        if update:
            board[int(move[2],base=20)-10][8-int(move[3])]=move[0]
            if blackToMove:
                blackHold['prnbq'.index(board[int(move[2],base=20)-10][8-8-int(move[3])])]-=1
            else:
                whiteHold['PRNBQ'.index(board[int(move[2],base=20)-10][8-8-int(move[3])])]-=1
            board[int(move[2],base=20)-10][8-int(move[3])]
            return True
    elif move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]=='='):
        if(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not WQcastle):
            error="You may not castle right now."
            return False
        elif move=="O-O"or move=="O-O-O":
            ""
        elif not(move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"])or move=="O-O"or move=="O-O-O"or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"])and move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h')and move[5]in('a','b','c','d','e','f','g','h')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')or move=="O-O"or move=="O-O-O"):
            error="Move indexed out of bounds."
            return False
        elif (move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif(move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower())or not(move[0].islower()==board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        if board[int(move[5],base=20)-10][-int(move[3])]!=' ':
                            if move[5:7]in promotions:
                                promotions.remove(move[5:7])
                                if blackToMove:
                                    blackHold[0]+=1
                                else:
                                    whiteHold[0]+=1
                            else:
                                if blackToMove:
                                    blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[3])])]+=1
                                else:
                                    whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[3])])]+=1
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    if board[int(move[5],base=20)-10][-int(move[6])]!=' ':
                        if move[5:7]in promotions:
                            promotions.remove(move[5:7])
                            promotions.append(move[2:4])
                            if blackToMove:
                                blackHold[0]+=1
                            else:
                                whiteHold[0]+=1
                        else:
                            if blackToMove:
                                blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                            else:
                                whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=[int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2]
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                        promotions.append(move[5:7])
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    if board[int(move[5],base=20)-10][8-8-int(move[6])]!=' ':
                        if move[5:7]in promotions:
                            promotions.remove(move[5:7])
                            promotions.append(move[2:4])
                            if blackToMove:
                                blackHold[0]+=1
                            else:
                                whiteHold[0]+=1
                        else:
                            if blackToMove:
                                blackHold['PRNBQ'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                            else:
                                whiteHold['prnbq'.index(board[int(move[5],base=20)-10][8-8-int(move[6])])]+=1
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][-int(move[3])]=' '
                    if move[2:4]in promotions:
                        promotions[promotions.index(move[2:4])]=move[5:7]
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemove10x8(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,**keys):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'Ｍ':'M',
        'Ａ':'A',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'ｍ':'m',
        'ａ':'a'
    })if playerCase else({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'ｍ':'m',
        'ａ':'a',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'Ｍ':'M',
        'Ａ':'A'
    })if darkMode else({
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'ｍ':'m',
        'ａ':'a',
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'Ｍ':'M',
        'Ａ':'A'
    })if playerCase else({
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'Ｍ':'M',
        'Ａ':'A',
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'ｍ':'m',
        'ａ':'a'
    }))
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]=='='):
        if(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not WQcastle):
            error="You may not castle right now."
            return False
        elif move=="O-O"or move=="O-O-O":
            ""
        elif not(move[0].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"])or move=="O-O"or move=="O-O-O"or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"])and move[0].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f','g','h','i','j')and move[5]in('a','b','c','d','e','f','g','h','i','j')and move[3]in('1','2','3','4','5','6','7','8')and move[6]in('1','2','3','4','5','6','7','8')or move=="O-O"or move=="O-O-O"):
            error="Move indexed out of bounds."
            return False
        elif (move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='8'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and move[0].lower()=='p'and((move[6]=='8'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif(move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower())or not(move[0].islower()==board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,7),max(kingRookFile,8)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,8):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(8,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[7][0]='r'
                    board[8][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,7),max(kingRookFile,8)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,8):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(8,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[7][7]='R'
                    board[8][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=20)-10][8-int(move[3])]=' '
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][8-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=[int(move[2],base=20)-10,(16-int(move[6])-int(move[3]))//2]
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][8-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    board[int(move[5],base=20)-10][8-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemoveSHOGI(moveIn,update,checkForCheck,board,enemyMove):
    global error
    global playerCase
    global WKingPos
    global BKingPos
    global whiteHold
    global blackHold
    move=multireplace(moveIn,({
        'Ｋ':'k',
        'Ｒ':'r',
        'Ｄ':'d',
        'Ｂ':'b',
        'Ｈ':'h',
        'Ｇ':'g',
        'Ｓ':'s',
        'Ｅ':'e',
        'Ｎ':'n',
        'Ｃ':'c',
        'Ｌ':'l',
        'Ｉ':'i',
        'Ｐ':'p',
        'Ｔ':'t',
        'ｋ':'K',
        'ｒ':'R',
        'ｄ':'D',
        'ｂ':'B',
        'ｈ':'H',
        'ｇ':'G',
        'ｓ':'S',
        'ｅ':'E',
        'ｎ':'N',
        'ｃ':'C',
        'ｌ':'L',
        'ｉ':'I',
        'ｐ':'P',
        'ｔ':'T',
        '王':'K',
        '玉':'K',
        '飛':'R',
        '龍':'D',
        '竜':'D',
        '角':'B',
        '馬':'H',
        '金':'G',
        '銀':'S',
        '全':'E',
        '桂':'N',
        '圭':'C',
        '今':'C',
        '香':'L',
        '杏':'I',
        '仝':'I',
        '歩':'P',
        'と':'T',
        '个':'T'
    }if playerCase else{
        'Ｋ':'K',
        'Ｒ':'R',
        'Ｄ':'D',
        'Ｂ':'B',
        'Ｈ':'H',
        'Ｇ':'G',
        'Ｓ':'S',
        'Ｅ':'E',
        'Ｎ':'N',
        'Ｃ':'C',
        'Ｌ':'L',
        'Ｉ':'I',
        'Ｐ':'P',
        'Ｔ':'T',
        'ｋ':'k',
        'ｒ':'r',
        'ｄ':'d',
        'ｂ':'b',
        'ｈ':'h',
        'ｇ':'g',
        'ｓ':'s',
        'ｅ':'e',
        'ｎ':'n',
        'ｃ':'c',
        'ｌ':'l',
        'ｉ':'i',
        'ｐ':'p',
        'ｔ':'t',
        '王':'K',
        '玉':'K',
        '飛':'R',
        '龍':'D',
        '竜':'D',
        '角':'B',
        '馬':'H',
        '金':'G',
        '銀':'S',
        '全':'E',
        '桂':'N',
        '圭':'C',
        '今':'C',
        '香':'L',
        '杏':'I',
        '仝':'I',
        '歩':'P',
        'と':'T',
        '个':'T'
    }))
    if(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==8 and move[1]==' 'and move[4]=='-'and move[7]=='+')or(len(move)==4 and move[1]=='@'):
        if move[0].lower()not in('k','r','d','b','h','g','s','e','n','c','l','i','p','t'):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not((len(move)>=7 and move[2]in('1','2','3','4','5','6','7','8','9')and move[5]in('1','2','3','4','5','6','7','8','9')and move[3]in('a','b','c','d','e','f','g','h','i')and move[6]in('a','b','c','d','e','f','g','h','i'))or(len(move)==4 and move[2]in('1','2','3','4','5','6','7','8','9')and move[3]in('a','b','c','d','e','f','g','h','i'))):
            error="Move indexed out of bounds."
            return False
        elif (move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==8 and move[0].lower()in('k','g','d','h','e','c','i','t'):
            error="You may not promote a King, Gold, or promoted piece."
            return False
        elif len(move)==8 and move[0].lower()not in('k','g','d','h','e','c','i','t')and((move[6]not in('g','h','i')and not blackToMove)or(move[6]not in('a','b','c')and blackToMove)):
            error="You may only promote a piece within the promotion zone."
            return False
        elif len(move)==7 and(move[0].lower()not in('k','r','b','g','d','h','e','c','i','t','n')and(move[6]=='i'and not blackToMove)or(move[6]=='a'and blackToMove)):
            error="You must specify a promotion when moving a piece to the back rank."
            return False
        elif len(move)==8 and move[0].lower()=='n'and(((move[6]=='h'or move[6]=='i')and not blackToMove)or((move[6]=='a'or move[6]=='b')and blackToMove)):
            error="You must specify a promotion when moving a Knight onto the last or second-to-last rank, you must specify a promotion"
            return False
        elif(move[0].lower()!=board[notationtoarraySHOGI(move[2:4])[0]][notationtoarraySHOGI(move[2:4])[1]].lower())or not(move[0].islower()==board[notationtoarraySHOGI(move[2:4])[0]][notationtoarraySHOGI(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif len(move)>=7 and move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        elif len(move)==4 and (blackHold if blackToMove else whiteHold).count(move[0])==0:
            error="You do not have any "+(move[0].swapcase()if playerCase else move[0])+"'s in your hand."
            return False
        if update:
            if len(move)>=7:
                if checkmoveSHOGI(move,checkForCheck,board,enemyMove)==True:
                    if move[0]=='K':
                        WKingPos=notationtoarraySHOGI(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarraySHOGI(move[5:7])
                    if board[int(move[5])-1][18-int(move[6],base=19)]!=' ':
                        if blackToMove:
                            if board[int(move[5])-1][18-int(move[6],base=19)]in('D','H','E','C','I','T'):
                                unpromotions={
                                    'D':'r',
                                    'H':'b',
                                    'E':'s',
                                    'C':'n',
                                    'I':'l',
                                    'T':'p'
                                }
                                blackHold.append(unpromotions[board[int(move[5])-1][18-int(move[6],base=19)]])
                            else:
                                blackHold.append(board[int(move[5])-1][18-int(move[6],base=19)].lower())
                            blackHold.sort(key=lambda x:('R','r','B','b','G','g','S','s','N','n','L','l','P','p').index(x))
                        else:
                            if board[int(move[5])-1][18-int(move[6],base=19)]in('d','h','e','c','i','t'):
                                unpromotions={
                                    'd':'R',
                                    'h':'B',
                                    'e':'S',
                                    'c':'N',
                                    'i':'L',
                                    't':'P'
                                }
                                whiteHold.append(unpromotions[board[int(move[5])-1][18-int(move[6],base=19)]])
                            else:
                                whiteHold.append(board[int(move[5])-1][18-int(move[6],base=19)].upper())
                            whiteHold.sort(key=lambda x:('R','r','B','b','G','g','S','s','N','n','L','l','P','p').index(x))
                    board[int(move[5])-1][18-int(move[6],base=19)]=move[0]
                    board[int(move[2])-1][18-int(move[3],base=19)]=' '
                else:
                    error=checkmoveSHOGI(move,checkForCheck,board,enemyMove)
                    return False
                return True
            else:
                if checkmoveSHOGI(move,checkForCheck,board,enemyMove)==True:
                    board[int(move[2])-1][18-int(move[3],base=19)]=move[0]
                    if blackToMove:
                        blackHold.remove(move[0])
                    else:
                        whiteHold.remove(move[0])
                else:
                    error=checkmoveSHOGI(move,checkForCheck,board,enemyMove)
                    return False
                return True
        else:
            if checkmoveSHOGI(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmoveSHOGI(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def makemove6(moveIn,update,checkForCheck,board,enemyMove,kingFile,queenRookFile,kingRookFile,**keys):
    global error
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    global playerCase
    global WKingPos
    global BKingPos
    move=multireplace(moveIn,({
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'Ｍ':'M',
        'Ａ':'A',
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'ｍ':'m',
        'ａ':'a'
    })if playerCase else({
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'ｍ':'m',
        'ａ':'a',
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'Ｍ':'M',
        'Ａ':'A'
    })if darkMode else({
        '♔':'k',
        '♕':'q',
        '♖':'r',
        '♗':'b',
        '♘':'n',
        '♙':'p',
        'ｍ':'m',
        'ａ':'a',
        '♚':'K',
        '♛':'Q',
        '♜':'R',
        '♝':'B',
        '♞':'N',
        '♟':'P',
        'Ｍ':'M',
        'Ａ':'A'
    })if playerCase else({
        '♔':'K',
        '♕':'Q',
        '♖':'R',
        '♗':'B',
        '♘':'N',
        '♙':'P',
        'Ｍ':'M',
        'Ａ':'A',
        '♚':'k',
        '♛':'q',
        '♜':'r',
        '♝':'b',
        '♞':'n',
        '♟':'p',
        'ｍ':'m',
        'ａ':'a'
    }))
    if move=="O-O"or move=="O-O-O"or(len(move)==7 and move[1]==' 'and move[4]=='-')or(len(move)==9 and move[1]==' 'and move[4]=='-'and move[7]=='='):
        if(move=="O-O"and not blackToMove and not WKcastle)or(move=="O-O"and blackToMove and not BKcastle)or(move=="O-O-O"and not blackToMove and not WQcastle)or(move=="O-O-O"and blackToMove and not WQcastle):
            error="You may not castle right now."
            return False
        elif move=="O-O"or move=="O-O-O":
            ""
        elif not(move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"])or move=="O-O"or move=="O-O-O"or(len(move)>7 and move[8].lower()in(('r','n','b','q','k','p','m','a')if "pieces"not in keys else keys["pieces"])and move[0].lower()in(('r','n','b','q','k','p')if "pieces"not in keys else keys["pieces"]))):
            error="Piece "+(move[0].swapcase()if playerCase else move[0])+" does not exist."
            return False
        elif not(move[2]in('a','b','c','d','e','f')and move[5]in('a','b','c','d','e','f')and move[3]in('1','2','3','4','5','6')and move[6]in('1','2','3','4','5','6')):
            error="Move indexed out of bounds."
            return False
        elif(move[0].islower()!=blackToMove and not enemyMove)or(move[0].islower()==blackToMove and enemyMove):
            error="You may not move your opponent's pieces."
            return False
        elif len(move)==9 and move[0].lower()!=('p'):
            error="You may not promote a piece that is not a Pawn."
            return False
        elif len(move)==9 and move[0].lower()=='p'and((move[6]!='6'and not blackToMove)or(move[6]!='1'and blackToMove)):
            error="You may only promote a Pawn on the back rank."
            return False
        elif len(move)==9 and move[0].islower()!=move[8].islower():
            error="You may not promote to a piece of the opposite color."
            return False
        elif len(move)==7 and(move[0].lower()=='p'and(move[6]=='6'and not blackToMove)or(move[6]=='1'and blackToMove)):
            error="You must specify what piece to promote to when moving a Pawn to the back rank."
            return False
        elif len(move)==9 and move[8].lower()=='p':
            error="You may not promote to a Pawn."
            return False
        elif len(move)==9 and move[8].lower()=='k':
            error="You may not promote to a King."
            return False
        elif(move[0].lower()!=board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].lower())or not(move[0].islower()==board[notationtoarray(move[2:4])[0]][notationtoarray(move[2:4])[1]].islower()or not update):
            error="There is not a "+(move[0].swapcase()if playerCase else move[0])+" on "+move[2:4]+"."
            return False
        elif move[2:4]==move[5:7]:
            error="You may not move a piece to its own location."
            return False
        if update:
            if move=="O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(6,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[5][0]='r'
                    board[6][0]='k'
                    board[kingRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(min(kingFile+1,5),max(kingRookFile,6)):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile+1,6):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(6,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[5][7]='R'
                    board[6][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif move=="O-O-O":
                if check(board,blackToMove,enemyMove,kingFile,queenRookFile,kingRookFile):
                    error="You may not castle while in check."
                    return False
                if blackToMove:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][0]!=' 'and board[i][0]!='k'and board[i][0]!='r':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        BKingPos=(i,0)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            BKingPos=(kingFile,0)
                            return False
                    BKingPos=(2,0)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,0)
                        return False
                    board[kingFile][0]=' '
                    board[3][0]='r'
                    board[2][0]='k'
                    board[queenRookFile][0]=' '
                    BQcastle=False
                    BKcastle=False
                else:
                    for i in range(max(kingFile-1,3),min(queenRookFile,2),-1):
                        if board[i][7]!=' 'and board[i][7]!='K'and board[i][7]!='R':
                            error="There is a piece blocking your castle."
                            return False
                    for i in range(kingFile-1,2):
                        WKingPos=(i,7)
                        if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                            error="You may not castle through check."
                            WKingPos=(kingFile,7)
                            return False
                    WKingPos=(2,7)
                    if check(board,True,enemyMove,kingFile,queenRookFile,kingRookFile):
                        error="You may not castle into check."
                        BKingPos=(kingFile,7)
                        return False
                    board[kingFile][7]=' '
                    board[3][7]='R'
                    board[2][7]='K'
                    board[kingRookFile][7]=' '
                    WQcastle=False
                    WKcastle=False
                fiftymoves+=1
                eP=False
            elif checkmove6(move,checkForCheck,board,enemyMove)==True:
                if move[0].lower()=='p':
                    if notationtoarray(move[5:7])==eP:
                        board[int(move[5],base=20)-10][6-int(move[3])]=' '
                    board[int(move[5],base=20)-10][6-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][6-int(move[3])]=' '
                    if abs(int(move[3])-int(move[6]))==2:
                        eP=[int(move[2],base=20)-10,(12-int(move[6])-int(move[3]))//2]
                    else:
                        eP=False
                    if len(move)==9:
                        board[int(move[5],base=20)-10][6-int(move[6])]=move[8]
                    fiftymoves=0
                else:
                    if board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                        fiftymoves=-1
                    if move[2:4]==arraytonotation([queenRookFile,7])or move[5:7]==arraytonotation([queenRookFile,7]):
                        WQcastle=False
                    if move[2:4]==arraytonotation([queenRookFile,0])or move[5:7]==arraytonotation([queenRookFile,0]):
                        BQcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,7])or move[5:7]==arraytonotation([kingRookFile,7]):
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingRookFile,0])or move[5:7]==arraytonotation([kingRookFile,0]):
                        BKcastle=False
                    if move[2:4]==arraytonotation([kingFile,7])or move[5:7]==arraytonotation([kingFile,7]):
                        WQcastle=False
                        WKcastle=False
                    if move[2:4]==arraytonotation([kingFile,0])or move[5:7]==arraytonotation([kingFile,0]):
                        BQcastle=False
                        BKcastle=False
                    if move[0]=='K':
                        WKingPos=notationtoarray(move[5:7])
                    elif move[0]=='k':
                        BKingPos=notationtoarray(move[5:7])
                    board[int(move[5],base=20)-10][6-int(move[6])]=move[0]
                    board[int(move[2],base=20)-10][-int(move[3])]=' '
                    fiftymoves+=1
                    eP=False
            else:
                error=checkmove6(move,True,board,enemyMove)
                return False
            return True
        else:
            if checkmove6(move,True,board,enemyMove)==True:
                return True
            else:
                error=checkmove6(move,True,board,enemyMove)
                return False
    else:
        error="Bad move format."
        return False
def checkpawn(move,board):
    global eP
    global playerCase
    if move[0]=='p':
        if move[3]!='7':
            if int(move[3])-int(move[6])==2:
                return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[3])-int(move[6])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][8-int(move[6])].islower():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='7'and int(move[3])-int(move[6])==2 and board[int(move[5],base=20)-10][8-int(move[6])]==' 'and board[int(move[5],base=20)-10][7-int(move[6])]==' ':
            return True
        return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
    else:
        if move[3]!='2':
            if int(move[6])-int(move[3])==2:
                return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[6])-int(move[3])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][8-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][8-int(move[6])].isupper():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='2'and int(move[6])-int(move[3])==2 and board[int(move[5],base=20)-10][8-int(move[6])]==' 'and board[int(move[5],base=20)-10][9-int(move[6])]==' ':
            return True
        return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
def checkmove(move,checkForCheck,board,enemyMove):
    global playerCase
    global WKingPos
    global BKingPos
    if move[0].lower()=='r':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='n':
        if (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='b':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='q':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='m':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='a':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='z':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(9-int(move[3]),8-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(7-int(move[3]),8-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][8-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][9-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='k':
        if abs(int(move[2],base=20)-int(move[5],base=20))>1 or abs(int(move[3])-int(move[6]))>1:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif checkpawn(move,board)!=True:
            return checkpawn(move,board)
    if checkForCheck:
        checkboard=copy.deepcopy(board)
        checkboard[int(move[5],base=20)-10][8-int(move[6])]=move[0]
        checkboard[int(move[2],base=20)-10][8-int(move[3])]=' '
        oldKings=[WKingPos,BKingPos]
        if move[0]=='K':
            WKingPos=notationtoarray(move[5:7])
        elif move[0]=='k':
            BKingPos=notationtoarray(move[5:7])
        if(check(checkboard,blackToMove,enemyMove,4,0,7)and len(board)==8)or(check10x8(checkboard,blackToMove,enemyMove,5,0,9)):
            WKingPos=oldKings[0]
            BKingPos=oldKings[1]
            return"You may not move into check."
        WKingPos=oldKings[0]
        BKingPos=oldKings[1]
    return True
def checkmoveSHOGI(moveIn,checkForCheck,board,enemyMove):
    global blackToMove
    global playerCase
    global WKingPos
    global BKingPos
    global SHOGIchecksWhite
    global SHOGIchecksBlack
    move=((moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-9)+moveIn[4]+chr(int(moveIn[5])+96)+str(int(moveIn[6],base=19)-9)+moveIn[7])if len(moveIn)==8 else((moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-9)+moveIn[4]+chr(int(moveIn[5])+96)+str(int(moveIn[6],base=19)-9))if len(moveIn)==7 else(moveIn[:2]+chr(int(moveIn[2])+96)+str(int(moveIn[3],base=19)-9))))
    if len(move)>=7:
        if move[0].lower()=='r':
            if move[2]==move[5]:
                if int(move[3])>int(move[6]):
                    for i in range(10-int(move[3]),9-int(move[6])):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(8-int(move[3]),9-int(move[6]),-1):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif move[3]==move[6]:
                if int(move[2],base=20)>int(move[5],base=20):
                    for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                        if board[i][9-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='d':
            if move[2]==move[5]:
                if int(move[3])>int(move[6]):
                    for i in range(10-int(move[3]),9-int(move[6])):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(8-int(move[3]),9-int(move[6]),-1):
                        if board[int(move[2],base=20)-10][i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[2],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif move[3]==move[6]:
                if int(move[2],base=20)>int(move[5],base=20):
                    for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                        if board[i][9-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                        if board[i][8-int(move[3])]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif abs(int(move[2],base=19)-int(move[5],base=19))==1 and abs(int(move[3])-int(move[6]))==1:
                if board[int(move[5],base=20)-10][8-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][8-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='b':
            if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
                if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][8-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][8-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][10-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][10-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0].lower()=='h':
            if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
                if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][8-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][8-int(move[3])-i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)-i-11][10-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
                else:
                    for i in range(abs(int(move[3])-int(move[6]))-1):
                        if board[int(move[2],base=20)+i-9][10-int(move[3])+i]!=' ':
                            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                    if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                        return"You may not capture your own pieces."
            elif not(abs(int(move[2],base=19)-int(move[5],base=19))>1 or abs(int(move[3])-int(move[6]))>1):
                if board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0]=='l':
            if move[2]==move[5]and int(move[3])<int(move[6]):
                for i in range(8-int(move[3]),9-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                if board[int(move[2],base=20)-10][9-int(move[6])].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif move[0]=='L':
            if move[2]==move[5]and int(move[3])>int(move[6]):
                for i in range(10-int(move[3]),9-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
                if not board[int(move[2],base=20)-10][9-int(move[6])].islower()and board[int(move[5],base=20)-10][9-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        elif checkleapSHOGI(move,board,moveIn)!=True:
            return checkleapSHOGI(move,board,moveIn)
    else:
        if(move[0].lower()in('p','n','l')and move[3]==('1'if blackToMove else'9'))or(move[0].lower()=='n'and move[3]==('2'if blackToMove else'8')):
            return"You may not drop a "+(move[0].swapcase()if playerCase else move[0])+" there."
        elif move[0].lower()=='p'and move[0]in board[int(move[3],base=19)]:
            return"You may not drop a "+(move[0].swapcase()if playerCase else move[0])+" onto a file containing another "+(move[0].swapcase()if playerCase else move[0])+"."
    if checkForCheck:
        checkboard=copy.deepcopy(board)
        if len(move)>4:
            checkboard[int(move[5],base=20)-10][9-int(move[6])]=move[0]
            checkboard[int(move[2],base=20)-10][9-int(move[3])]=' '
            if checkSHOGI(checkboard,blackToMove,(notationtoarraySHOGI(moveIn[5:7])if move[0].lower()=='k'else(BKingPos if move[0].islower()else WKingPos)),enemyMove):
                return"You may not move into check."
            elif(SHOGIchecksBlack if move[0].islower()else SHOGIchecksWhite)>=3 and checkSHOGI(checkboard,not blackToMove,(WKingPos if move[0].islower()else BKingPos),enemyMove):
                return"It is illegal to give check to your opponent on four consecutive turns."
        else:
            checkboard[int(move[2],base=20)-10][9-int(move[3])]=move[0]
            if checkSHOGI(checkboard,blackToMove,(BKingPos if move[0].islower()else WKingPos),enemyMove):
                return"You may not move into check."
            elif(SHOGIchecksBlack if move[0].islower()else SHOGIchecksWhite)>=3 and checkSHOGI(checkboard,not blackToMove,(WKingPos if move[0].islower()else BKingPos),enemyMove):
                return"It is illegal to give check to your opponent on four consecutive turns."
            blackToMove=not blackToMove
            if move[0].lower()=='p'and checkSHOGI(checkboard,blackToMove,(WKingPos if blackToMove else BKingPos),False)and stalemateSHOGI(blackToMove,checkboard,True,whiteHold,blackHold):
                blackToMove=not blackToMove
                return"It is illegal to deliver checkmate via dropping a Pawn."
            blackToMove=not blackToMove
    return True
def checkleapSHOGI(move,board,moveIn):
    try:
        if board[int(move[5],base=20)-10][9-int(move[6])]!=' 'and board[int(move[5],base=20)-10][9-int(move[6])].islower()==move[0].islower():
            return"You may not capture your own pieces."
        pieces={
            'K':[(1,0),(1,1),(1,-1),(0,1),(0,-1),(-1,0),(-1,1),(-1,-1)],
            'k':[(1,0),(1,1),(1,-1),(0,1),(0,-1),(-1,0),(-1,1),(-1,-1)],
            'G':[(1,0),(-1,0),(-1,1),(-1,-1),(0,1),(0,-1)],
            'g':[(1,0),(-1,0),(1,1),(1,-1),(0,1),(0,-1)],
            'S':[(1,1),(-1,1),(1,-1),(-1,-1),(0,-1)],
            's':[(1,1),(-1,1),(1,-1),(-1,-1),(0,1)],
            'N':[(1,-2),(-1,-2)],
            'n':[(1,2),(-1,2)],
            'P':[(0,-1)],
            'p':[(0,1)],
            'E':[(1,0),(-1,0),(-1,1),(-1,-1),(0,1),(0,-1)],
            'e':[(1,0),(-1,0),(1,1),(1,-1),(0,1),(0,-1)],
            'C':[(1,0),(-1,0),(-1,1),(-1,-1),(0,1),(0,-1)],
            'c':[(1,0),(-1,0),(1,1),(1,-1),(0,1),(0,-1)],
            'I':[(1,0),(-1,0),(-1,1),(-1,-1),(0,1),(0,-1)],
            'i':[(1,0),(-1,0),(1,1),(1,-1),(0,1),(0,-1)],
            'T':[(1,0),(-1,0),(-1,1),(-1,-1),(0,1),(0,-1)],
            't':[(1,0),(-1,0),(1,1),(1,-1),(0,1),(0,-1)]
        }
        if(int(move[5],base=20)-int(move[2],base=20),int(move[3])-int(move[6]))not in pieces[move[0]]:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
        else:
            return True
    except IndexError:
        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+moveIn[2:4]+" to "+moveIn[5:7]+"."
def checkpawn6(move,board):
    global eP
    global playerCase
    if move[0]=='p':
        if int(move[3])-int(move[6])==2:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[3])-int(move[6])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[3])-int(move[6])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][6-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][6-int(move[6])].islower():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='7'and int(move[3])-int(move[6])==2 and board[int(move[5],base=20)-10][6-int(move[6])]==' 'and board[int(move[5],base=20)-10][5-int(move[6])]==' ':
            return True
        return"You may not move a "+("P"if playerCase else"p")+" from "+move[2:4]+" to "+move[5:7]+"."
    else:
        if int(move[6])-int(move[3])==2:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])>2 or abs(int(move[2],base=20)-int(move[5],base=20))>1:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==2 and int(move[2],base=20)-int(move[5],base=20)!=0:
            return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
        if int(move[6])-int(move[3])==1 and move[2]==move[5]:
            if board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            else:
                return True
        if int(move[6])-int(move[3])==1 and abs(int(move[2],base=20)-int(move[5],base=20))==1:
            if board[int(move[5],base=20)-10][6-int(move[6])]==' ':
                if eP==notationtoarray(move[5:7]):
                    return True
                else:
                    return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
            elif board[int(move[5],base=20)-10][6-int(move[6])].isupper():
                return"You may not capture your own pieces."
            else:
                return True
        if move[3]=='2'and int(move[6])-int(move[3])==2 and board[int(move[5],base=20)-10][6-int(move[6])]==' 'and board[int(move[5],base=20)-10][7-int(move[6])]==' ':
            return True
        return"You may not move a "+("p"if playerCase else"P")+" from "+move[2:4]+" to "+move[5:7]+"."
def checkmove6(move,checkForCheck,board,enemyMove):
    global playerCase
    global WKingPos
    global BKingPos
    if move[0].lower()=='r':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(7-int(move[3]),6-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(5-int(move[3]),6-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='n':
        if (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='b':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='q':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(7-int(move[3]),6-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(5-int(move[3]),6-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        else:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
    elif move[0].lower()=='m':
        if move[2]==move[5]:
            if int(move[3])>int(move[6]):
                for i in range(7-int(move[3]),6-int(move[6])):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(5-int(move[3]),6-int(move[6]),-1):
                    if board[int(move[2],base=20)-10][i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[2],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif move[3]==move[6]:
            if int(move[2],base=20)>int(move[5],base=20):
                for i in range(int(move[2],base=20)-11,int(move[5],base=20)-10,-1):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(int(move[2],base=20)-9,int(move[5],base=20)-10):
                    if board[i][6-int(move[3])]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='a':
        if abs(int(move[3])-int(move[6]))==abs(int(move[2],base=20)-int(move[5],base=20))or abs(int(move[2],base=20)-int(move[3]))==abs(int(move[5],base=20)-int(move[6])):
            if int(move[3])<int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])<int(move[6])and int(move[2],base=20)<int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][5-int(move[3])-i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            elif int(move[3])>int(move[6])and int(move[2],base=20)>int(move[5],base=20):
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)-i-11][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
            else:
                for i in range(abs(int(move[3])-int(move[6]))-1):
                    if board[int(move[2],base=20)+i-9][7-int(move[3])+i]!=' ':
                        return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
                if board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
                    return"You may not capture your own pieces."
        elif (abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(1,2)and(abs(notationtoarray(move[2:4])[0]-notationtoarray(move[5:7])[0]),abs(notationtoarray(move[2:4])[1]-notationtoarray(move[5:7])[1]))!=(2,1):
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif move[0].lower()=='k':
        if abs(int(move[2],base=20)-int(move[5],base=20))>1 or abs(int(move[3])-int(move[6]))>1:
            return"You may not move a "+(move[0].swapcase()if playerCase else move[0])+" from "+move[2:4]+" to "+move[5:7]+"."
        elif board[int(move[5],base=20)-10][6-int(move[6])].islower()==move[0].islower()and board[int(move[5],base=20)-10][6-int(move[6])]!=' ':
            return"You may not capture your own pieces."
    elif checkpawn6(move,board)!=True:
            return checkpawn6(move,board)
    if checkForCheck:
        checkboard=copy.deepcopy(board)
        checkboard[int(move[5],base=20)-10][6-int(move[6])]=move[0]
        checkboard[int(move[2],base=20)-10][6-int(move[3])]=' '
        oldKings=[WKingPos,BKingPos]
        if move[0]=='K':
            WKingPos=notationtoarray(move[5:7])
        elif move[0]=='k':
            BKingPos=notationtoarray(move[5:7])
        if check6(checkboard,blackToMove,enemyMove,3,0,5):
            WKingPos=oldKings[0]
            BKingPos=oldKings[1]
            return"You may not move into check."
        WKingPos=oldKings[0]
        BKingPos=oldKings[1]
    return True
def check(board,player,enemyMove,kingFile,queenRookFile,kingRookFile):
    if player:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].isupper()and makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos)+";Q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    else:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].islower()and makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos)+";q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    return False
def check10x8(board,player,enemyMove,kingFile,queenRookFile,kingRookFile):
    if player:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].isupper()and makemove10x8(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos)+";Q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    else:
        for rank in range(8):
            for file in range(len(board)):
                if board[file][rank].islower()and makemove10x8(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos)+";q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    return False
def checkSHOGI(board,player,kingPos,enemyMove):
    if player:
        for rank in range(9):
            for file in range(9):
                if board[file][rank].isupper()and(makemoveSHOGI(board[file][rank]+" "+arraytonotationSHOGI([file,rank])+"-"+arraytonotationSHOGI(kingPos),False,False,board,not enemyMove)or makemoveSHOGI(board[file][rank]+" "+arraytonotationSHOGI([file,rank])+"-"+arraytonotationSHOGI(kingPos)+'+',False,False,board,not enemyMove)):
                    return True
    else:
        for rank in range(9):
            for file in range(9):
                if board[file][rank].islower()and(makemoveSHOGI(board[file][rank]+" "+arraytonotationSHOGI([file,rank])+"-"+arraytonotationSHOGI(kingPos),False,False,board,not enemyMove)or makemoveSHOGI(board[file][rank]+" "+arraytonotationSHOGI([file,rank])+"-"+arraytonotationSHOGI(kingPos)+'+',False,False,board,not enemyMove)):
                    return True
    return False
def check6(board,player,enemyMove,kingFile,queenRookFile,kingRookFile):
    if player:
        for rank in range(6):
            for file in range(6):
                if board[file][rank].isupper()and makemove6(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove6(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(BKingPos)+";Q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    else:
        for rank in range(6):
            for file in range(6):
                if board[file][rank].islower()and makemove6(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos),False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile)or makemove6(board[file][rank]+" "+arraytonotation([file,rank])+"-"+arraytonotation(WKingPos)+";q",False,False,board,not enemyMove,kingFile,queenRookFile,kingRookFile):
                    return True
    return False
def stalemate(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    for rankorigin in range(8):
        for fileorigin in range(len(board)):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(len(board)):
                            if player:
                                if makemove("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                            else:
                                if makemove("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                for rankdest in range(8):
                    for filedest in range(len(board)):
                        if makemove(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            return False
    return True
def stalemateCRAZYHOUSE(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
    for rankorigin in range(8):
        for fileorigin in range(8):
            if board[fileorigin][rankorigin]==' ':
                if player:
                    if makemoveCRAZYHOUSE("p@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("r@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("n@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("b@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("q@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                        return False
                else:
                    if makemoveCRAZYHOUSE("P@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("R@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("N@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("B@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold)or makemoveCRAZYHOUSE("Q@"+arraytonotation([fileorigin,rankorigin]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                        return False
            elif board[fileorigin][rankorigin].islower()==player:
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(8):
                            if player:
                                if makemoveCRAZYHOUSE("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                                    return False
                            else:
                                if makemoveCRAZYHOUSE("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                                    return False
                for rankdest in range(8):
                    for filedest in range(8):
                        if makemoveCRAZYHOUSE(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile,whiteHold,blackHold):
                            return False
    return True
def stalemate10x8(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    for rankorigin in range(8):
        for fileorigin in range(len(board)):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(len(board)):
                            if player:
                                if makemove10x8("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                            else:
                                if makemove10x8("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                for rankdest in range(8):
                    for filedest in range(len(board)):
                        if makemove10x8(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            return False
    return True
def stalemateSHOGI(player,board,checkForCheck,whiteHold,blackHold):
    for rankorigin in range(9):
        for fileorigin in range(9):
            if board[fileorigin][rankorigin]==' ':
                if player:
                    if makemoveSHOGI("p@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("r@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("b@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("g@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("s@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("n@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("l@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False):
                        return False
                else:
                    if makemoveSHOGI("P@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("R@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("B@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("G@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("S@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("N@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False)or makemoveSHOGI("L@"+arraytonotationSHOGI([fileorigin,rankorigin]),False,checkForCheck,board,False):
                        return False
            elif board[fileorigin][rankorigin].islower()==player:
                for rankdest in range(9):
                    for filedest in range(9):
                        if makemoveSHOGI(board[fileorigin][rankorigin]+" "+arraytonotationSHOGI([fileorigin,rankorigin])+"-"+arraytonotationSHOGI([filedest,rankdest]),False,checkForCheck,board,False)or makemoveSHOGI(board[fileorigin][rankorigin]+" "+arraytonotationSHOGI([fileorigin,rankorigin])+"-"+arraytonotationSHOGI([filedest,rankdest])+"+",False,checkForCheck,board,False):
                            return False
    return True
def stalemate6(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    for rankorigin in range(6):
        for fileorigin in range(6):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(6):
                        for filedest in range(6):
                            if player:
                                if makemove6("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                            else:
                                if makemove6("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    return False
                for rankdest in range(6):
                    for filedest in range(6):
                        if makemove6(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            return False
    return True
def stalematedarkcontrol(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    global controlledSpaces
    controlledSpaces=[]
    for rankorigin in range(8):
        for fileorigin in range(len(board)):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(len(board)):
                            if player:
                                if makemove("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    controlledSpaces.append([filedest,rankdest])
                            else:
                                if makemove("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    controlledSpaces.append([filedest,rankdest])
                for rankdest in range(8):
                    for filedest in range(len(board)):
                        if makemove(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            controlledSpaces.append([filedest,rankdest])
    return len(controlledSpaces)==0
def stalemateanti(player,board,checkForCheck,kingFile,queenRookFile,kingRookFile):
    global captures
    move=False
    global eP
    for rankorigin in range(8):
        for fileorigin in range(len(board)):
            if board[fileorigin][rankorigin].islower()==player and board[fileorigin][rankorigin]!=' ':
                if board[fileorigin][rankorigin].lower()=='p':
                    for rankdest in range(8):
                        for filedest in range(len(board)):
                            if player:
                                if makemove("p "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    move=True
                                    if board[filedest][rankdest]!=' 'or[filedest,rankdest]==eP:
                                        captures=True
                            else:
                                if makemove("P "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest])+";Q",False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                                    move=True
                                    if board[filedest][rankdest]!=' 'or[filedest,rankdest]==eP:
                                        captures=True
                for rankdest in range(8):
                    for filedest in range(len(board)):
                        if makemove(board[fileorigin][rankorigin]+" "+arraytonotation([fileorigin,rankorigin])+"-"+arraytonotation([filedest,rankdest]),False,checkForCheck,board,False,kingFile,queenRookFile,kingRookFile):
                            move=True
                            if board[filedest][rankdest]!=' 'or[filedest,rankdest]==eP:
                                captures=True
    return move
def CHESS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"CHESS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHESS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        CHESS()
def settings():
    global ASCIIart
    global boardFlip
    global playerCase
    global darkMode
    global screenClears
    global invertBoard
    global BISHOPSkingPos
    global SHOGIkanji
    clearscreen()
    print("  SETTINGS\n  --------\n1|Unicode Support: "+("ASCII Only"if ASCIIart==0 else("Basic Unicode"if ASCIIart==1 else"Extended Unicode"))+"\n2|Board Flips: "+("ON"if boardFlip else"OFF")+"\n3|Capital Letters Represent: "+("BLACK"if playerCase else"WHITE")+"\n4|Dark Mode: "+("ON"if darkMode else"OFF")+"\n5|Screen Clears: "+("ON"if screenClears else"OFF")+"\n6|Board Color: "+("Inverted"if invertBoard else"Normal")+"\n7|Game-Specific Settings"+("..."if ASCIIart==0 else"…")+"\n8|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>8:
        print("Option "+str(selection)+" does not exist.\n\n  SETTINGS\n  --------\n1|Unicode Support :"+("ASCII Only"if ASCIIart==0 else("Basic Unicode"if ASCIIart==1 else"Extended Unicode"))+"\n2|Board Flips: "+("ON"if boardFlip else"OFF")+"\n3|Capital Letters Represent :"+("BLACK"if playerCase else"WHITE")+"\n4|Dark Mode: "+("ON"if darkMode else"OFF")+"\n5|Screen Clears: "+("ON"if screenClears else"OFF")+"\n6|Board Color: "+("Inverted"if invertBoard else"Normal")+"\n7|Game-Specific Settings"+("..."if ASCIIart==0 else"…")+"\n8|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ASCIIart=(ASCIIart+1)%3
        settings()
    elif selection==2:
        boardFlip=not boardFlip
        settings()
    elif selection==3:
        playerCase=not playerCase
        settings()
    elif selection==4:
        darkMode=not darkMode
        settings()
    elif selection==5:
        screenClears=not screenClears
        settings()
    elif selection==6:
        invertBoard=not invertBoard
        settings()
    elif selection==7:
        gamesettings()
        settings()
    else:
        if filesystem!=False:
            global exSettings
            global settingsBits
            os.remove(os.path.join(filesystem,"Settings.ini"))
            settingsData=ASCIIart+4*boardFlip+8*playerCase+16*darkMode+32*screenClears+64*invertBoard+128*BISHOPSkingPos+256*SHOGIkanji+2**settingsBits*exSettings
            settingsOptions=""
            for i in range(0,math.floor(math.log(settingsData,256))*8+8,8):
                settingsOptions+=chr((settingsData&255*2**i)//2**i)
            settingsFile=open(os.path.join(filesystem,"Settings.ini"),"w+",encoding="latin-1")
            settingsFile.write(settingsOptions)
            settingsFile.close()
        mainMenu()
def gamesettings():
    global BISHOPSkingPos
    global SHOGIkanji
    clearscreen()
    print("  GAME"+("‐"if ASCIIart==2 else"-")+"SPECIFIC SETTINGS\n  ----------------------\n1|BISHOPS: Black King Starts on: "+("e8"if BISHOPSkingPos else"d8")+(""if ASCIIart==0 else"\n2|SHŌGI: Replace Capital Letters with Kanji: "+("ON"if SHOGIkanji else"OFF"))+"\n3|Return to Settings Menu\n")
    selection=int(input(""))
    while selection<1 or selection>3 or(selection==2 and ASCIIart==0):
        print("Option "+str(selection)+" does not exist.\n\n  GAME"+("‐"if ASCIIart==2 else"-")+"SPECIFIC SETTINGS\n  ----------------------\n1|BISHOPS: Black King Starts on: "+("e8"if BISHOPSkingPos else"d8")+(""if ASCIIart==0 else"\n2|SHŌGI: Replace Capital Letters with Kanji: "+("ON"if SHOGIkanji else"OFF"))+"\n3|Return to Settings Menu\n")
        selection=int(input(""))
    if selection==1:
        BISHOPSkingPos=not BISHOPSkingPos
        gamesettings()
    elif selection==2:
        SHOGIkanji=not SHOGIkanji
        gamesettings()
def variantslist():
    global variantsList
    global screenClears
    clearscreen()
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        print(str(i+1).replace("SHOGI","SHOGI"if ASCIIart==0 else"SHŌGI")+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        variantslistsearch(letter)
    elif selection!=len(variantsList)+2:
        if variantsList[selection-1][-1]!='*'or screenClears:
            eval(variantsList[selection-1].replace("*","")+"()")
        else:
            print("This is a hidden information game. These games are not supported if Screen Clearing is disabled.")
            variantslist()
def variantslistsearch(letter):
    global variantsList
    clearscreen()
    print("  CHOOSE VARIANT\n  --------------")
    for i in range(len(variantsList)):
        if variantsList[i][0]==letter:
            print(str(i+1).replace("SHOGI","SHOGI"if ASCIIart==0 else"SHŌGI")+"|"+variantsList[i])
    print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>len(variantsList)+2:
        print("Option "+str(selection)+" does not exist.\n\n  CHOOSE VARIANT\n  --------------")
        for i in range(len(variantsList)):
            if variantsList[i][0]==letter:
                print(str(i+1)+"|"+variantsList[i])
        print(str(len(variantsList)+1)+"|Search Variants by First Letter\n"+str(len(variantsList)+2)+"|Return to Main Menu\n")
        selection=int(input(""))
    if selection==len(variantsList)+1:
        letter=input("Search by letter: ").upper()
        while len(letter)!=1:
            letter=input("Type one letter. Search by letter: ").upper()
        variantslistsearch(letter)
    elif selection<len(variantsList)+1:
        if variantsList[selection-1][-1]!='*'or screenClears:
            eval(variantsList[selection-1].replace("*","")+"()")
        else:
            print("This is a hidden information game. These games are not supported if Screen Clearing is disabled.")
            variantslistsearch(letter)
def DEATHMATCH(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"DEATHMATCH",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("DEATHMATCH")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,False,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,False,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        DEATHMATCH()
def CHESS960(*setup):
    global gameboard
    global WKingPos
    global BKingPos
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        while True:
            backrank=['R','N','B','Q','K','B','N','R']
            random.shuffle(backrank)
            if backrank.index('B')%2!="".join(backrank).rindex('B')%2 and backrank.index('R')<backrank.index('K')and backrank.index('K')<"".join(backrank).rindex('R'):
                kingFile=backrank.index('K')
                queenRookFile=backrank.index('R')
                kingRookFile="".join(backrank).rindex('R')
                gameboard=[[backrank[0].lower(),'p',' ',' ',' ',' ','P',backrank[0]],[backrank[1].lower(),'p',' ',' ',' ',' ','P',backrank[1]],[backrank[2].lower(),'p',' ',' ',' ',' ','P',backrank[2]],[backrank[3].lower(),'p',' ',' ',' ',' ','P',backrank[3]],[backrank[4].lower(),'p',' ',' ',' ',' ','P',backrank[4]],[backrank[5].lower(),'p',' ',' ',' ',' ','P',backrank[5]],[backrank[6].lower(),'p',' ',' ',' ',' ','P',backrank[6]],[backrank[7].lower(),'p',' ',' ',' ',' ','P',backrank[7]]]
                break
        WKingPos=(kingFile,7)
        BKingPos=(kingFile,0)
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        fiftymoves=0
        eP=False
    else:
        queenRookFile=setup[0][0]
        kingFile=setup[0][1]
        kingRookFile=setup[0][2]
    while True:
        if drawboard(list(gameboard),"CHESS960",[kingFile,queenRookFile,kingRookFile]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHESS960",str(queenRookFile)+str(kingFile)+str(kingRookFile))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,kingFile,queenRookFile,kingRookFile))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,kingFile,queenRookFile,kingRookFile)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CHESS960()
def ROOKS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['k','p',' ',' ',' ',' ','P','K'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"ROOKS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("ROOKS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','k','p'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ROOKS()
def CRAZYHOUSE(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    global promotions
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
        whiteHold=[0,0,0,0,0]
        blackHold=[0,0,0,0,0]
        promotions=[]
    else:
        whiteHold=list(map(lambda x:(int(x,base=17)),setup[0][:9].split("-")))
        blackHold=list(map(lambda x:(int(x,base=17)),setup[0][9:18].split("-")))
        promotions=(list(map(tuple,setup[0][18:].split("/")))if len(setup[0])>18 else[])
    while True:
        if drawboardCRAZYHOUSE(list(gameboard),whiteHold,blackHold):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CRAZYHOUSE","-".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),whiteHold)))+"-".join(list(map(lambda x:('G'if x==16 else hex(x)[2].upper()),blackHold)))+"/".join(list(map(lambda x:str(x[0])+str(x[1]),promotions))))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O"and not(len(move)==4 and move[1]=='@'):
                error=("Bad move format.")
            elif(not playerCase and makemoveCRAZYHOUSE(move,True,True,gameboard,False,4,0,7,whiteHold,blackHold))or(playerCase and makemoveCRAZYHOUSE(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,whiteHold,blackHold)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CRAZYHOUSE()
def KNIGHTS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['k','p',' ',' ',' ',' ','P','K'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N'],['n','p',' ',' ',' ',' ','P','N']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"KNIGHTS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("KNIGHTS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('n','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('n','k','p'))):
                break
        blackToMove=not blackToMove
        if w!=whiteScoreKNIGHTS or b!=blackScoreKNIGHTS:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        KNIGHTS()
def BISHOPS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    global BISHOPSkingPos
    if len(setup)==0:
        gameboard=[['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['b'if BISHOPSkingPos else'k','p',' ',' ',' ',' ','P','B'],['k'if BISHOPSkingPos else'b','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B'],['b','p',' ',' ',' ',' ','P','B']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(3,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"BISHOPS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("BISHOPS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('b','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('b','k','p'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        BISHOPS()
def QUEENS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q'],['q','p',' ',' ',' ',' ','P','Q']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"QUEENS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("QUEENS")
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('q','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('q','k','p'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        QUEENS()
def ROOKS_CASTLING(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['k','p',' ',' ',' ',' ','P','K'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"ROOKS_CASTLING",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("ROOKS_CASTLING")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','k','p')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','k','p'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ROOKS_CASTLING()
def NO_CASTLING(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"NO_CASTLING",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("NO_CASTLING")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        NO_CASTLING()
def THREECHECK(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    global whiteCheckCount
    global blackCheckCount
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
        whiteCheckCount=0
        blackCheckCount=0
    else:
        whiteCheckCount=int(setup[0][0])
        blackCheckCount=int(setup[0][1])
    while True:
        if drawboard(list(gameboard),"THREECHECK",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("THREECHECK",str(whiteCheckCount)+str(blackCheckCount))
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        THREECHECK()
def CHOOSECOMPOUND(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],[' ','p',' ',' ',' ',' ','P',' '],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']] 
        x=input("White, which piece would you like to have? (‘Q’, ‘M’, or ‘A’)")
        while x not in['Q','M','A']:
            x=input("White, which piece would you like to have? (‘Q’, ‘M’, or ‘A’)")
        gameboard[3][7]=x
        x=input("Black, which piece would you like to have? (‘q’, ‘m’, or ‘a’)")
        while x not in['q','m','a']:
            x=input("Black, which piece would you like to have? (‘q’, ‘m’, or ‘a’)")
        gameboard[3][0]=x
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"CHOOSECOMPOUND",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CHOOSECOMPOUND")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('r','n','b','q','k','p','m','a')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','n','b','q','k','p','m','a'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CHOOSECOMPOUND()
def CAPABLANCA(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['a','p',' ',' ',' ',' ','P','A'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['m','p',' ',' ',' ',' ','P','M'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard10x8(list(gameboard),"CAPABLANCA",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("CAPABLANCA")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove10x8(move,True,True,gameboard,False,5,0,9))or(playerCase and makemove10x8(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,5,0,9)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        CAPABLANCA()
def SHOGI(*setup):
    global gameboard
    global blackToMove
    global error
    error=""
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global eP
    global fiftymoves
    WQcastle=False
    WKcastle=False
    BQcastle=False
    BKcastle=False
    eP=False
    fiftymoves=0
    global WKingPos
    global BKingPos
    global playerCase
    global whiteHold
    global blackHold
    global SHOGIchecksWhite
    global SHOGIchecksBlack
    if len(setup)==0:
        gameboard=[['l',' ','p',' ',' ',' ','P',' ','L'],['n','r','p',' ',' ',' ','P','B','N'],['s',' ','p',' ',' ',' ','P',' ','S'],['g',' ','p',' ',' ',' ','P',' ','G'],['k',' ','p',' ',' ',' ','P',' ','K'],['g',' ','p',' ',' ',' ','P',' ','G'],['s',' ','p',' ',' ',' ','P',' ','S'],['n','b','p',' ',' ',' ','P','R','N'],['l',' ','p',' ',' ',' ','P',' ','L']]
        blackToMove=True
        whiteHold=[]
        blackHold=[]
        SHOGIchecksWhite=0
        SHOGIchecksBlack=0
        WKingPos=(4,8)
        BKingPos=(4,0)
    else:
        whiteHold=list(setup[0].split('|')[0])
        blackHold=list(setup[0].split(';')[0].split('|')[1])
        SHOGIchecksWhite=int(setup[0].split(';')[1][0])
        SHOGIchecksBlack=int(setup[0].split(';')[1][1])
    while True:
        if drawboardSHOGI():
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"White wins by resignation. 0-1")
                    break
            elif move=="Claim Impasse":
                if blackToMove:
                    move=input("White, do you agree to an impasse? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to an impasse? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to an impasse? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to an impasse? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whitePoints=0
                        blackPoints=0
                        for piece in whiteHold:
                            if piece=='R'or piece=='B':
                                whitePoints+=5
                            else:
                                whitePoints+=1
                        for piece in blackHold:
                            if piece=='r'or piece=='b':
                                blackPoints+=5
                            else:
                                blackPoints+=1
                        for rank in range(9):
                            for file in range(9):
                                if gameboard[file][rank]==' 'or gameboard[file][rank]=='K'or gameboard[file][rank]=='k':
                                    ""
                                elif gameboard[file][rank]=='R'or gameboard[file][rank]=='D'or gameboard[file][rank]=='B'or gameboard[file][rank]=='H':
                                    whitePoints+=5
                                elif gameboard[file][rank]=='r'or gameboard[file][rank]=='d'or gameboard[file][rank]=='b'or gameboard[file][rank]=='h':
                                    blackPoints+=5
                                elif gameboard[file][rank].islower():
                                    blackPoints+=1
                                else:
                                    whitePoints+=1
                        if blackPoints<24:
                            print("White wins by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". 1‐0"if ASCIIart==2 else"White wins by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 1-0")
                        elif whitePoints<24:
                            print("Black wins by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". 0‐1"if ASCIIart==2 else"Black wins by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 0-1")
                        else:
                            print("Draw by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". ½‐½"if ASCIIart==2 else("Draw by impasse "+str(whitePoints)+"-"+str(blackPoints)+". ½-½"if ASCIIart==1 else"Draw by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 1/2-1/2"))
                        break
                    else:
                        error="White declined an impasse."
                else:
                    move=input("Black, do you agree to an impasse? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to an impasse? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to an impasse? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to an impasse? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whitePoints=0
                        blackPoints=0
                        for piece in whiteHold:
                            if piece=='R'or piece=='B':
                                whitePoints+=5
                            else:
                                whitePoints+=1
                        for piece in blackHold:
                            if piece=='r'or piece=='b':
                                blackPoints+=5
                            else:
                                blackPoints+=1
                        for rank in range(9):
                            for file in range(9):
                                if gameboard[file][rank]==' 'or gameboard[file][rank]=='K'or gameboard[file][rank]=='k':
                                    ""
                                elif gameboard[file][rank]=='R'or gameboard[file][rank]=='D'or gameboard[file][rank]=='B'or gameboard[file][rank]=='H':
                                    whitePoints+=5
                                elif gameboard[file][rank]=='r'or gameboard[file][rank]=='d'or gameboard[file][rank]=='b'or gameboard[file][rank]=='h':
                                    blackPoints+=5
                                elif gameboard[file][rank].islower():
                                    blackPoints+=1
                                else:
                                    whitePoints+=1
                        if blackPoints<24:
                            print("White wins by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". 1‐0"if ASCIIart==2 else"White wins by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 1-0")
                        elif whitePoints<24:
                            print("Black wins by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". 0‐1"if ASCIIart==2 else"Black wins by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 0-1")
                        else:
                            print("Draw by impasse "+str(whitePoints)+"‐"+str(blackPoints)+". ½‐½"if ASCIIart==2 else("Draw by impasse "+str(whitePoints)+"-"+str(blackPoints)+". ½-½"if ASCIIart==1 else"Draw by impasse "+str(whitePoints)+"-"+str(blackPoints)+". 1/2-1/2"))
                        break
                    else:
                        error="Black declined an impasse."
            elif move=="Save":
                savegame("SHOGI","".join(whiteHold)+"|"+"".join(blackHold)+";"+str(SHOGIchecksWhite)+str(SHOGIchecksBlack))
                break
            elif(not playerCase and makemoveSHOGI(move,True,True,gameboard,False))or(playerCase and makemoveSHOGI(move if move[0]=='O'else(move[0].swapcase()+move[1:]),True,True,gameboard,False)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        SHOGI()
def LOSALAMOS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ','P','R'],['n','p',' ',' ','P','N'],['q','p',' ',' ','P','Q'],['k','p',' ',' ','P','K'],['n','p',' ',' ','P','N'],['r','p',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(3,5)
        BKingPos=(3,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboardLOSALAMOS():
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("LOSALAMOS")
                break
            elif len(move)<7:
                error=("Bad move format.")
            elif(not playerCase and makemove6(move,True,True,gameboard,False,4,0,7,pieces=('r','n','q','k','p')))or(playerCase and makemove6(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('r','n','q','k','p'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        LOSALAMOS()
def KING_OF_THE_HILL(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"KING_OF_THE_HILL",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("KING_OF_THE_HILL")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        KING_OF_THE_HILL()
def ANTICHESS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    global captures
    captures=False
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"ANTICHESS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("ANTICHESS")
                break
            elif len(move)<7:
                error=("Bad move format.")
            elif captures and board[int(move[5],base=18)-10][8-int(move[6])]==' 'and notationtoarray(move[5:7])!=eP:
                error="There is 1 or more legal capture(s). Capturing is mandatory in ANTICHESS if there is a legal capture."
            elif(not playerCase and makemove(move,True,False,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,False,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    print("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
    selection=int(input(""))
    while selection<1 or selection>2:
        print("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n")
        selection=int(input(""))
    if selection==1:
        ANTICHESS()
def MAHARAJA_SEPOYS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ',' ',' '],['n','p',' ',' ',' ',' ',' ',' '],['b','p',' ',' ',' ',' ',' ',' '],['q','p',' ',' ',' ',' ',' ',' '],['k','p',' ',' ',' ',' ',' ','Z'],['b','p',' ',' ',' ',' ',' ',' '],['n','p',' ',' ',' ',' ',' ',' '],['r','p',' ',' ',' ',' ',' ',' ']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"MAHARAJA_SEPOYS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("MAHARAJA_SEPOYS")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7,pieces=('p','r','n','b','q','k','z')))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7,pieces=('p','r','n','b','q','k','z'))):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        MAHARAJA_SEPOYS()
def KNIGHTMATE(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['k','p',' ',' ',' ',' ','P','K'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=False
        WKcastle=False
        BQcastle=False
        BKcastle=False
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboard(list(gameboard),"KNIGHTMATE",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif move=="Save":
                savegame("KNIGHTMATE")
                break
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        KNIGHTMATE()
def DARKCHESS(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    global standardNotation
    global controlledSpaces
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        WKingPos=(4,7)
        BKingPos=(4,0)
        fiftymoves=0
        eP=False
    while True:
        if drawboarddarkcontrol(list(gameboard),"DARKCHESS",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,True,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,True,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        DARKCHESS()
def MYSTERYROYAL(*setup):
    global gameboard
    global blackToMove
    global WQcastle
    global WKcastle
    global BQcastle
    global BKcastle
    global error
    error=""
    global WKingPos
    global BKingPos
    global fiftymoves
    global eP
    global playerCase
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
        blackToMove=False
        WQcastle=True
        WKcastle=True
        BQcastle=True
        BKcastle=True
        fiftymoves=0
        eP=False
        clearscreen()
        print("White is deciding their royal piece.\nBlack, please do not view the screen at this time.")
        input("")
        clearscreen()
        move=input("White, where would you like your royal piece to be?")
        if move[0]not in('a','b','c','d','e','f','g','h')or move[1]not in('1','2'):
            move=input("You can't put your royal there. You must put it on one of your pieces. ")
        WKingPos=notationtoarray(move)
        clearscreen()
        print("Black is deciding their royal piece.\nWhite, please do not view the screen at this time.")
        input("")
        clearscreen()
        move=input("Black, where would you like your royal piece to be?")
        if move[0]not in('a','b','c','d','e','f','g','h')or move[1]not in('7','8'):
            move=input("You can't put your royal there. You must put it on one of your pieces. ")
        BKingPos=notationtoarray(move)
    while True:
        if drawboard(list(gameboard),"MYSTERYROYAL",[]):
            break
        error=""
        while True:
            breakflag=False
            move=input(error)
            if move=="0-0":
                move="O-O"
            elif move=="0-0-0":
                move="O-O-O"
            if move=="Resign":
                breakflag=True
                if blackToMove:
                    print("White wins by resignation. 1‐0"if ASCIIart==2 else"White wins by resignation. 1-0")
                    break
                else:
                    print("Black wins by resignation. 0‐1"if ASCIIart==2 else"Black wins by resignation. 0-1")
                    break
            elif move=="Propose Draw"or move=="Offer Draw":
                if blackToMove:
                    move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("White, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"White, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="White declined a draw."
                else:
                    move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    while move!='Y'and move!='N':
                        move=input("Black, do you agree to a draw? ('Y' or 'N') "if ASCIIart==0 else"Black, do you agree to a draw? (‘Y’ or ‘N’) ")
                    if move=='Y':
                        whiteScoreCHESS+=1
                        blackScoreCHESS+=1
                        print("Draw by mutual agreement. ½‐½"if ASCIIart==2 else("Draw by mutual agreement. ½-½")if ASCIIart==1 else"Draw by mutual agreement. 1/2-1/2")
                        break
                    else:
                        error="Black declined a draw."
            elif len(move)<7 and move!="O-O"and move!="O-O-O":
                error=("Bad move format.")
            elif(not playerCase and makemove(move,True,False,gameboard,False,4,0,7))or(playerCase and makemove(move if move[0]=='O'else(move[0].swapcase()+move[1:8]+move[8].swapcase()if len(move)==9 else move[0].swapcase()+move[1:]),True,False,gameboard,False,4,0,7)):
                break
        blackToMove=not blackToMove
        if breakflag:
            break
    selection=int(input("  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    while selection<1 or selection>2:
        selection=int(input("Option "+str(selection)+" does not exist.\n\n  GAME OVER\n  ---------\n1|Play again\n2|Return to Main Menu\n"))
    if selection==1:
        MYSTERYROYAL()
def mainMenu():
    clearscreen()
    print("  PyChess "+versionNumber)
    if filesystem==None:
        print("  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n5|Open SANDBOX\n6|Load Game\n7|Report a Bug\n8|QUIT\n")
        selection=int(input(""))
        while selection<1 or selection>8 or selection==4:
            print("Option "+str(selection)+" does not exist.\n\n  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n5|Open SANDBOX\n6|Load Game\n7|Report a Bug\n8|QUIT\n")
            selection=int(input(""))
        if selection==1:
            CHESS()
            mainMenu()
        elif selection==2:
            settings()
        elif selection==3:
            variantslist()
            mainMenu()
        elif selection==5:
            SANDBOX()
            mainMenu()
        elif selection==6:
            loadgame()
        elif selection==7:
            if browser_ext:
                webbrowser.open("https://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            else:
                print("Use this URL:\nhttps://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            mainMenu()
    else:
        print("  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|User's Guide\n5|Open SANDBOX\n6|Load Game\n7|Report a Bug\n8|QUIT\n")
        selection=int(input(""))
        while selection<1 or selection>8:
            print("Option "+str(selection)+" does not exist.\n\n  MAIN MENU\n  ---------\n1|Play CHESS\n2|Configure Game\n3|Play VARIANT\n4|User's Guide\n5|Open SANDBOX\n6|Load Game\n7|Report a Bug\n8|QUIT\n")
            selection=int(input(""))
        if selection==1:
            CHESS()
            mainMenu()
        elif selection==2:
            settings()
        elif selection==3:
            variantslist()
            mainMenu()
        elif selection==4:
            try:
                os.startfile(os.path.join(filesystem,"PyChess Users Guide.docx"))
            except FileNotFoundError:
                print("The PyChess User's Guide couldn't be found. Perhaps it has been deleted or moved?\n")
            mainMenu()
        elif selection==5:
            SANDBOX()
            mainMenu()
        elif selection==6:
            loadgame()
            mainMenu()
        elif selection==7:
            if browser_ext:
                webbrowser.open("https://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            else:
                print("Use this URL:\nhttps://docs.google.com/forms/d/e/1FAIpQLSeUWyCd6QKGxi6AxdztmdKr3M_iewxWAVYXkgvBLs1NKx9ARQ/viewform?usp=sf_link")
            mainMenu()
def SANDBOX(*setup):
    global gameboard
    global error
    error=""
    if len(setup)==0:
        gameboard=[['r','p',' ',' ',' ',' ','P','R'],['n','p',' ',' ',' ',' ','P','N'],['b','p',' ',' ',' ',' ','P','B'],['q','p',' ',' ',' ',' ','P','Q'],['k','p',' ',' ',' ',' ','P','K'],['b','p',' ',' ',' ',' ','P','B'],['n','p',' ',' ',' ',' ','P','N'],['r','p',' ',' ',' ',' ','P','R']]
    while True:
        drawboardSANDBOX()
        error=""
        while True:
            exitcommand=False
            breakFlag=False
            moveRaw=input(error)
            for move in list(map(lambda x:x.strip(),moveRaw.split(';'))):
                for i in range(len(move)-3):
                    if move[i:i+2]=="U+":
                        for j in range(min(i+8,len(move)),i+2,-1):
                            try:
                                if int(move[i+2:j],base=16)<=1114111 and int(move[i+2:j],base=16)>0:
                                    move=move.replace(move[i:j],chr(int(move[i+2:j],base=16)))
                                break
                            except ValueError:
                                ""
                if move=="Quit"or move=="Exit":
                    exitcommand=True
                    breakFlag=True
                elif move=="+FileR":
                    fileinsert=[]
                    for i in range(len(gameboard[0])):
                        fileinsert.append(' ')
                    gameboard.append(fileinsert)
                    breakFlag=True
                elif move=="+FileL":
                    fileinsert=[]
                    for i in range(len(gameboard[0])):
                        fileinsert.append(' ')
                    gameboard=[fileinsert,]+gameboard
                    breakFlag=True
                elif move=="+RankU":
                    if len(gameboard[0])>=9:
                        error="Sorry, you cannot have more than 9 ranks."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i]=[' ',]+gameboard[i]
                        breakFlag=True
                elif move=="+RankD":
                    if len(gameboard[0])>=9:
                        error="Sorry, you cannot have more than 9 ranks."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].append(' ')
                        breakFlag=True
                elif move=="-FileR":
                    if len(gameboard)<=1:
                        error="You cannot remove the only file in a board."
                    else:
                        gameboard.pop()
                        breakFlag=True
                elif move=="-FileL":
                    if len(gameboard)<=1:
                        error="You cannot remove the only file in a board."
                    else:
                        gameboard.pop(0)
                        breakFlag=True
                elif move=="-RankU":
                    if len(gameboard[0])<=1:
                        error="You cannot remove the only rank in a board."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].pop(0)
                        breakFlag=True
                elif move=="-RankD":
                    if len(gameboard[0])<=1:
                        error="You cannot remove the only rank in a board."
                    else:
                        for i in range(len(gameboard)):
                            gameboard[i].pop()
                        breakFlag=True
                elif move=="Save":
                    board=""
                    for i in gameboard:
                        board+=','.join(i)+';'
                    board=board[:-1]
                    print("Here is your save ‘file’:\nSANDBOX~"+board+"\nPress enter to return to the game.")
                    input("")
                    breakFlag=True
                elif len(move)==7 and move[1]==' 'and move[4]=='-':
                    if ord(move[2])-97>=len(gameboard)or ord(move[5])-97>=len(gameboard)or ord(move[2])<97 or ord(move[5])<97 or int(move[3])>len(gameboard[0])or int(move[6])>len(gameboard[0])or int(move[3])<1 or int(move[6])<1:
                        error="Coordinate out of bounds."
                    else:
                        if gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]!=move[0]:
                            error="There is not a "+move[0]+" on "+move[2:4]
                        else:
                            gameboard[int(move[5],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[6])]=move[0]
                            gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]=' '
                            breakFlag=True
                elif len(move)==4 and move[1]=='@':
                    if ord(move[2])-97>len(gameboard)or ord(move[2])<97 or int(move[3])>len(gameboard[0])or int(move[3])<1:
                        error="Coordinate out of bounds."
                    else:
                        gameboard[int(move[2],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[3])]=move[0]
                        breakFlag=True
                elif len(move)==3 and move[0]=='*':
                    if ord(move[1])-97>len(gameboard)or ord(move[1])<97 or int(move[2])>len(gameboard[0])or int(move[2])<1:
                        error="Coordinate out of bounds."
                    else:
                        gameboard[int(move[1],base=(len(gameboard)+10))-10][len(gameboard[0])-int(move[2])]=' '
                        breakFlag=True
                else:
                    error="Invalid Move"
            if breakFlag:
                break
        if exitcommand:
            break
global versionNumber
global settingsBits
versionNumber="1.3-Dev5"
settingsBits=9
global ASCIIart
global boardFlip
global playerCase
global darkMode
global screenClears
global invertBoard
global BISHOPSkingPos
global SHOGIkanji
global exSettings
if filesystem==False:
    ASCIIart=0
    boardFlip=False
    playerCase=False
    darkMode=False
    screenClears=False
    invertBoard=False
    BISHOPSkingPos=False
    SHOGIkanji=False
elif not os.path.isfile(os.path.join(filesystem,"Settings.ini")):
    exSettings=0
    ASCIIart=0
    boardFlip=False
    playerCase=False
    darkMode=False
    screenClears=False
    invertBoard=False
    BISHOPSkingPos=False
    SHOGIkanji=False
    settingsFile=open("Settings.ini","w+",encoding="latin-1")
    settingsFile.write("\x00")
    settingsFile.close()
else:
    exSettings=0
    settingsFile=open("Settings.ini","r",encoding="latin-1")
    settingsData=settingsFile.read()
    settingsFile.close()
    settingsOptions=0
    for i in range(len(settingsData)):
        settingsOptions+=ord(settingsData[i])*2**(8*i)
    if settingsOptions&3==3 or settingsData=="":
        os.remove(os.path.join(filesystem,"Settings.ini"))
        ASCIIart=0
        boardFlip=False
        playerCase=False
        darkMode=False
        screenClears=False
        invertBoard=False
        BISHOPSkingPos=False
        SHOGIkanji=False
        settingsFile=open("Settings.ini","w+",encoding="latin-1")
        settingsFile.write("\x00")
        settingsFile.close()
    else:
        ASCIIart=settingsOptions&3
        boardFlip=settingsOptions&4==4
        playerCase=settingsOptions&8==8
        darkMode=settingsOptions&16==16
        screenClears=settingsOptions&32==32
        invertBoard=settingsOptions&64==64
        BISHOPSkingPos=settingsOptions&128==128
        SHOGIkanji=settingsOptions&256==256
        exSettings=settingsOptions//2**settingsBits
global variantsList
variantsList=["DEATHMATCH","CHESS960","ROOKS","CRAZYHOUSE","KNIGHTS","BISHOPS","QUEENS","ROOKS_CASTLING","NO_CASTLING","THREECHECK","CHOOSECOMPOUND","CAPABLANCA","SHOGI","LOSALAMOS","KING_OF_THE_HILL","ANTICHESS","MAHARAJA_SEPOYS","KNIGHTMATE","DARKCHESS*","MYSTERYROYAL*"]
mainMenu()